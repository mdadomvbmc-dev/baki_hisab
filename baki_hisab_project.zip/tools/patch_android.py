import re, shutil

# Fix: plugin (flutter_timezone etc.) Java(11) vs Kotlin(1.8) JVM target mismatch
with open('android/gradle.properties', 'a') as _f:
    _f.write('\nkotlin.jvm.target.validation.mode=IGNORE\n')
shutil.copy('keystore/release.jks', 'android/app/release.jks')
g = 'android/app/build.gradle.kts'
s = open(g).read()
s = s.replace('minSdk = flutter.minSdkVersion', 'minSdk = 23')
s = s.replace('android {', '''android {
    signingConfigs { create("rel") {
        storeFile = file("release.jks"); storePassword = "bakihisab123"
        keyAlias = "baki"; keyPassword = "bakihisab123" } }''', 1)
s = s.replace('compileOptions {', 'compileOptions {\n        isCoreLibraryDesugaringEnabled = true', 1)
s = s.replace('signingConfigs.getByName("debug")', 'signingConfigs.getByName("rel")')
s += '\ndependencies { coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4") }\n'
open(g, 'w').write(s)
m = 'android/app/src/main/AndroidManifest.xml'
x = open(m).read()
perms = ''.join(f'<uses-permission android:name="android.permission.{p}"/>' for p in
 ['INTERNET','POST_NOTIFICATIONS','SCHEDULE_EXACT_ALARM','USE_EXACT_ALARM','USE_FULL_SCREEN_INTENT','RECEIVE_BOOT_COMPLETED','VIBRATE','WAKE_LOCK','REQUEST_INSTALL_PACKAGES','REQUEST_IGNORE_BATTERY_OPTIMIZATIONS'])
x = x.replace('<application', perms + '<application', 1)
x = re.sub(r'android:label="[^"]*"', 'android:label="বাকি হিসাব"', x, count=1)
rc = '''<receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver"/>
<receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
<intent-filter><action android:name="android.intent.action.BOOT_COMPLETED"/><action android:name="android.intent.action.MY_PACKAGE_REPLACED"/></intent-filter></receiver>'''
wr = '<receiver android:name=".BakiWidget" android:exported="true"><intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE"/></intent-filter><meta-data android:name="android.appwidget.provider" android:resource="@xml/baki_widget_info"/></receiver>'
x = x.replace('</application>', rc + wr + '</application>', 1)
q = ''.join(f'<intent><action android:name="android.intent.action.VIEW"/><data android:scheme="{sc}"/></intent>' for sc in ('https', 'tel', 'sms'))
if '</queries>' in x:
    x = x.replace('</queries>', q + '</queries>', 1)
else:
    x = x.replace('</manifest>', '<queries>' + q + '</queries></manifest>', 1)
open(m, 'w').write(x)

# ---- Android home screen widget ----
import glob, os
ma = glob.glob('android/app/src/main/kotlin/**/MainActivity.kt', recursive=True)[0]
pkg = re.search(r'package\s+([\w.]+)', open(ma).read()).group(1)
open(os.path.dirname(ma) + '/BakiWidget.kt', 'w').write("""package PKG
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.SharedPreferences
import android.widget.RemoteViews
import es.antonborri.home_widget.HomeWidgetLaunchIntent
import es.antonborri.home_widget.HomeWidgetProvider
class BakiWidget : HomeWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray, widgetData: SharedPreferences) {
        appWidgetIds.forEach { id ->
            val v = RemoteViews(context.packageName, R.layout.baki_widget)
            v.setTextViewText(R.id.w_total, widgetData.getString("total", "৳ ০"))
            v.setTextViewText(R.id.w_count, widgetData.getString("count", ""))
            v.setTextViewText(R.id.w_list, widgetData.getString("list", "অ্যাপ খুলুন"))
            v.setOnClickPendingIntent(R.id.w_root, HomeWidgetLaunchIntent.getActivity(context, MainActivity::class.java))
            appWidgetManager.updateAppWidget(id, v)
        }
    }
}
""".replace('PKG', pkg))
res = 'android/app/src/main/res/'
for d in ('layout', 'xml', 'drawable'):
    os.makedirs(res + d, exist_ok=True)
tv = lambda i, sz, extra='': f'<TextView android:id="@+id/{i}" android:layout_width="match_parent" android:layout_height="wrap_content" android:textColor="#FFFFFF" android:textSize="{sz}sp" {extra}/>'
open(res + 'layout/baki_widget.xml', 'w').write('<?xml version="1.0" encoding="utf-8"?><LinearLayout xmlns:android="http://schemas.android.com/apk/res/android" android:id="@+id/w_root" android:layout_width="match_parent" android:layout_height="match_parent" android:orientation="vertical" android:padding="14dp" android:background="@drawable/baki_widget_bg"><TextView android:layout_width="wrap_content" android:layout_height="wrap_content" android:text="বাকি হিসাব • মোট বাকি" android:textColor="#CCFFFFFF" android:textSize="12sp"/>' + tv('w_total', 26, 'android:textStyle="bold"') + tv('w_count', 12, 'android:maxLines=\"1\" android:ellipsize=\"end\"') + tv('w_list', 13, 'android:layout_marginTop="8dp"') + '</LinearLayout>')
open(res + 'drawable/baki_widget_bg.xml', 'w').write('<?xml version="1.0" encoding="utf-8"?><shape xmlns:android="http://schemas.android.com/apk/res/android"><gradient android:startColor="#2E7D32" android:endColor="#00897B" android:angle="315"/><corners android:radius="22dp"/></shape>')
open(res + 'xml/baki_widget_info.xml', 'w').write('<?xml version="1.0" encoding="utf-8"?><appwidget-provider xmlns:android="http://schemas.android.com/apk/res/android" android:minWidth="250dp" android:minHeight="110dp" android:targetCellWidth="4" android:targetCellHeight="2" android:updatePeriodMillis="1800000" android:initialLayout="@layout/baki_widget" android:resizeMode="horizontal|vertical" android:widgetCategory="home_screen"/>')
