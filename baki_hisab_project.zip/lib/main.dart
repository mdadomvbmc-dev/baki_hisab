import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:home_widget/home_widget.dart';
import 'package:http/http.dart' as http;
import 'package:intl/date_symbol_data_local.dart';
import 'package:intl/intl.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:url_launcher/url_launcher.dart';
import 'bazar.dart';
import 'cashbook.dart';
import 'desk_stub.dart' if (dart.library.io) 'desk_io.dart';
import 'more.dart';
import 'notify.dart';
import 'report.dart';

const kRepo = 'OWNER/REPO'; // GitHub Action নিজে বসিয়ে দেয়
const fbOptions = FirebaseOptions(
  apiKey: 'AIzaSyDCYJ5_WxhGXebRjOqfFu9oG6EWgMQuo38',
  authDomain: 'baki-hisab-a32ba.firebaseapp.com',
  projectId: 'baki-hisab-a32ba',
  storageBucket: 'baki-hisab-a32ba.firebasestorage.app',
  messagingSenderId: '548966518518',
  appId: '1:548966518518:web:8b96d240aeba2f4ad226d7',
);

const defShop = 'ধার দেনা';
const defSeed = 0xFF2E7D32;
const themeSeeds = <int>[0xFF2E7D32, 0xFF00796B, 0xFF1565C0, 0xFF3949AB, 0xFF6A1B9A, 0xFFC2185B, 0xFFC62828, 0xFFEF6C00, 0xFF6D4C41, 0xFF455A64, 0xFF558B2F, 0xFF00838F];
const bgColors = <Color>[Color(0xFFF4F7F4), Color(0xFFF2F4F8), Color(0xFFFBF6EE)];
const bgNames = <String>['হালকা সবুজ', 'ঠান্ডা ধূসর', 'ক্রিম'];
final seed = ValueNotifier<int>(defSeed);
final bgIdx = ValueNotifier<int>(0);
final shop = ValueNotifier<String>(defShop);
final owner = ValueNotifier<String>('');
final shopPhone = ValueNotifier<String>('');
final shopAddr = ValueNotifier<String>('');
final shopLogo = ValueNotifier<Uint8List?>(null);
final loopAlarm = ValueNotifier<bool>(true);
final dailyOn = ValueNotifier<bool>(false);
final dailyH = ValueNotifier<int>(21);
final dailyM = ValueNotifier<int>(0);
final pinHash = ValueNotifier<int?>(null);
final favs = ValueNotifier<List<String>>(<String>[]);
final monthBudget = ValueNotifier<num>(0); // মাসিক খরচের বাজেট (০ = বন্ধ)
final custPending = ValueNotifier<bool>(false);
final notif = FlutterLocalNotificationsPlugin();
final navKey = GlobalKey<NavigatorState>();
bool get isAndroid => !kIsWeb && Platform.isAndroid;
bool get isIOS => !kIsWeb && Platform.isIOS;
bool get isWindows => !kIsWeb && Platform.isWindows;
bool get mobile => isAndroid || isIOS;
final db = FirebaseFirestore.instance;
String get uid => FirebaseAuth.instance.currentUser!.uid;
DocumentReference<Map<String, dynamic>> get me => db.collection('users').doc(uid);
CollectionReference<Map<String, dynamic>> get cust => me.collection('customers');
CollectionReference<Map<String, dynamic>> get tasks => me.collection('tasks');
CollectionReference<Map<String, dynamic>> get ledger => me.collection('ledger');
CollectionReference<Map<String, dynamic>> get bazar => me.collection('bazar');
CollectionReference<Map<String, dynamic>> get cashbook => me.collection('cashbook');
CollectionReference<Map<String, dynamic>> get promptsCol => me.collection('prompts');

typedef Doc = QueryDocumentSnapshot<Map<String, dynamic>>;

// সব কাস্টমারের ডাটা একটাই লিসেনার থেকে (খরচ ও গোলমাল কম)
final custDocs = ValueNotifier<List<Doc>>([]);
final bazarDocs = ValueNotifier<List<Doc>>(<Doc>[]);
final custReady = ValueNotifier<bool>(false);
final custError = ValueNotifier<String?>(null);

// ───────── Helpers ─────────
final _nf = NumberFormat('#,##,##0.##', 'bn');
String nbn(num n) => _nf.format(n); // বাংলা অঙ্ক
String tk(num n) => '${n < 0 ? '-' : ''}৳ ${_nf.format(n.abs())}';
String dt(DateTime d) => DateFormat('d MMM yyyy, h:mm a', 'bn').format(d);
String dOnly(DateTime d) => DateFormat('d MMM yyyy', 'bn').format(d);
String timeOnly(DateTime d) => DateFormat('h:mm a', 'bn').format(d);
String monthName(DateTime d) => DateFormat('MMMM yyyy', 'bn').format(d);
String dayTitle(DateTime d) {
  final t = DateTime.now();
  final today = DateTime(t.year, t.month, t.day);
  final x = DateTime(d.year, d.month, d.day);
  if (x == today) return 'আজ — ${dOnly(x)}';
  if (x == today.subtract(const Duration(days: 1))) return 'গতকাল — ${dOnly(x)}';
  return DateFormat('EEEE, d MMMM yyyy', 'bn').format(x);
}

Future<void> openFileLocal(String p) => openLocalFile(p);

int intOf(Map<String, dynamic> m, String k, int d) {
  final v = m[k];
  return v is int ? v : d;
}

void savePrefs(Map<String, dynamic> m) => fire(me.collection('meta').doc('settings').set(m, SetOptions(merge: true)));

void applyPrefs(Map<String, dynamic>? m) {
  if (m == null) return;
  final sh = str(m, 'shop');
  if (sh.isNotEmpty) shop.value = sh;
  owner.value = str(m, 'owner');
  shopPhone.value = str(m, 'phone');
  shopAddr.value = str(m, 'address');
  seed.value = intOf(m, 'seed', defSeed);
  final bg = intOf(m, 'bg', 0);
  bgIdx.value = (bg >= 0 && bg < bgColors.length) ? bg : 0;
  monthBudget.value = numOf(m, 'budget');
  loopAlarm.value = m['loop'] != false;
  dailyOn.value = m['daily'] == true;
  dailyH.value = intOf(m, 'dh', 21);
  dailyM.value = intOf(m, 'dm', 0);
  final pn = m['pin'];
  pinHash.value = pn is int ? pn : null;
  final fv = m['favs'];
  favs.value = fv is List ? fv.map((e) => '$e').toList() : <String>[];
  final lg = m['logo'];
  if (lg is String && lg.isNotEmpty) {
    try {
      final b = base64Decode(lg);
      final old = shopLogo.value;
      if (old == null || old.length != b.length) shopLogo.value = b;
    } catch (_) {}
  } else {
    shopLogo.value = null;
  }
  reschedule();
}

void resetPrefs() {
  shop.value = defShop;
  owner.value = '';
  shopPhone.value = '';
  shopAddr.value = '';
  seed.value = defSeed;
  bgIdx.value = 0;
  monthBudget.value = 0;
  loopAlarm.value = true;
  dailyOn.value = false;
  dailyH.value = 21;
  dailyM.value = 0;
  pinHash.value = null;
  favs.value = <String>[];
  shopLogo.value = null;
  custDocs.value = <Doc>[];
  bazarDocs.value = <Doc>[];
  custReady.value = false;
  custError.value = null;
  custPending.value = false;
}
String toEn(String s) {
  const b = '০১২৩৪৫৬৭৮৯';
  return s.split('').map((x) {
    final i = b.indexOf(x);
    return i < 0 ? x : '$i';
  }).join();
}

String str(Map<String, dynamic> m, String k) {
  final v = m[k];
  return v == null ? '' : '$v'.trim();
}

num numOf(Map<String, dynamic> m, String k) {
  final v = m[k];
  return v is num ? v : 0;
}

DateTime? dtOf(Map<String, dynamic> m, String k) {
  final v = m[k];
  return v is Timestamp ? v.toDate() : null;
}

num? parseAmt(String s) {
  final t = toEn(s).replaceAll(RegExp(r'[^0-9.]'), '');
  if (t.isEmpty) return null;
  final v = num.tryParse(t);
  if (v == null) return null;
  return v == v.truncate() ? v.toInt() : v;
}

String plain(num n) => n == n.truncate() ? '${n.truncate()}' : '$n';

String phoneRaw(String s) => toEn(s).replaceAll(RegExp(r'[^0-9+]'), '');
String phoneIntl(String raw) {
  final d = toEn(raw).replaceAll(RegExp(r'[^0-9]'), '');
  if (d.isEmpty) return '';
  if (d.startsWith('880')) return d;
  if (d.startsWith('0')) return '88$d';
  if (d.length == 10) return '880$d';
  return d;
}

String dueMsg(Map<String, dynamic> m) =>
    'আসসালামু আলাইকুম ${str(m, 'name')}, ${shop.value} এ আপনার মোট বাকি ${tk(numOf(m, 'balance'))}। অনুগ্রহ করে সুবিধামতো পরিশোধ করবেন। ধন্যবাদ।';

String waUrl(String phone, String msg) => 'https://wa.me/${phoneIntl(phone)}?text=${Uri.encodeComponent(msg)}';
String smsUrl(String phone, String msg) => 'sms:${phoneRaw(phone)}?body=${Uri.encodeComponent(msg)}';

void toast(BuildContext c, String s) {
  final m = ScaffoldMessenger.maybeOf(c);
  m?.hideCurrentSnackBar();
  m?.showSnackBar(SnackBar(content: Text(s)));
}

Future<void> openUrl(BuildContext c, String url) async {
  try {
    final ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    if (!ok && c.mounted) toast(c, 'খোলা যায়নি');
  } catch (_) {
    if (c.mounted) toast(c, 'খোলা যায়নি');
  }
}

InputDecoration deco({String? label, String? hint, Widget? prefix, Widget? suffix, bool filled = false, String? err, String? helper}) => InputDecoration(
    labelText: label,
    hintText: hint,
    prefixIcon: prefix,
    suffixIcon: suffix,
    filled: filled,
    fillColor: filled ? Colors.white : null,
    errorText: err,
    errorMaxLines: 3,
    helperText: helper,
    helperMaxLines: 2,
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)));

final amtFmt = <TextInputFormatter>[FilteringTextInputFormatter.allow(RegExp('[0-9\u09E6-\u09EF.,]'))];
const numKb = TextInputType.numberWithOptions(decimal: true);

Widget card(Widget child, {EdgeInsets margin = const EdgeInsets.symmetric(horizontal: 14, vertical: 5)}) => Card(
    elevation: 0,
    color: Colors.white,
    surfaceTintColor: Colors.transparent,
    margin: margin,
    clipBehavior: Clip.antiAlias,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
    child: child);

void openDetail(BuildContext c, String id) => Navigator.push(c, MaterialPageRoute(builder: (_) => Detail(id)));

DateTime startOfToday() {
  final n = DateTime.now();
  return DateTime(n.year, n.month, n.day);
}

int overdueCount(List<Doc> docs) {
  final now = DateTime.now();
  return docs.where((d) {
    final due = dtOf(d.data(), 'due');
    return due != null && due.isBefore(now) && numOf(d.data(), 'balance') > 0;
  }).length;
}

// ডাটা লোড/এরর অবস্থা সামলে বিল্ডার চালায়
Widget withCust(Widget Function(BuildContext, List<Doc>) b) => ValueListenableBuilder<bool>(
    valueListenable: custReady,
    builder: (c, ready, _) => ValueListenableBuilder<List<Doc>>(
        valueListenable: custDocs,
        builder: (c, docs, _) {
          if (!ready) {
            return ValueListenableBuilder<String?>(
                valueListenable: custError,
                builder: (c, e, _) => Center(
                    child: e == null
                        ? const LogoLoader(size: 120)
                        : Padding(padding: const EdgeInsets.all(24), child: Text('ডাটা লোড করা যায়নি।\nইন্টারনেট ও Firestore rules দেখুন।\n$e', textAlign: TextAlign.center))));
          }
          return b(c, docs);
        }));

// ───────── ডাটা অপারেশন ─────────
Map<String, dynamic> newCust(String name, String phone, String village, String note) =>
    {'name': name, 'phone': phone, 'village': village, 'note': note, 'balance': 0, 'due': null, 'createdAt': Timestamp.now()};

void fire(Future<void> f) {
  f.catchError((_) {});
}

void addEntry(String id, num amt, String note, {String name = ''}) {
  HapticFeedback.mediumImpact();
  final r = cust.doc(id);
  final e = r.collection('entries').doc();
  final now = Timestamp.now();
  final b = db.batch();
  b.set(e, {'amount': amt, 'note': note, 'date': now});
  b.update(r, {'balance': FieldValue.increment(amt)});
  b.set(ledger.doc(e.id), {'cid': id, 'name': name, 'amount': amt, 'note': note, 'date': now});
  fire(b.commit());
}

void deleteEntry(String cid, DocumentSnapshot<Map<String, dynamic>> e) {
  final amt = numOf(e.data() ?? {}, 'amount');
  final b = db.batch();
  b.delete(e.reference);
  b.update(cust.doc(cid), {'balance': FieldValue.increment(-amt)});
  b.delete(ledger.doc(e.id));
  fire(b.commit());
}

Future<void> deleteCustomer(String id) async {
  final refs = <DocumentReference>[];
  final es = await cust.doc(id).collection('entries').get();
  refs.addAll(es.docs.map((d) => d.reference));
  final ls = await ledger.where('cid', isEqualTo: id).get();
  refs.addAll(ls.docs.map((d) => d.reference));
  refs.add(cust.doc(id));
  for (var i = 0; i < refs.length; i += 400) {
    final b = db.batch();
    for (final r in refs.skip(i).take(400)) {
      b.delete(r);
    }
    await b.commit();
  }
}

// দ্রুত পুরনো বাকি: প্রতি লাইনে "নাম, গ্রাম, টাকা"
Future<(int, int)> quickAdd(String text) async {
  final byName = <String, String>{};
  for (final d in custDocs.value) {
    byName[str(d.data(), 'name').toLowerCase()] = d.id;
  }
  var ok = 0, bad = 0;
  for (final line in text.split('\n')) {
    if (line.trim().isEmpty) continue;
    final p = line.split(RegExp('[,\u060C]')).map((e) => e.trim()).toList();
    final amt = p.length < 2 ? null : parseAmt(p.last);
    if (p.first.isEmpty || amt == null || amt <= 0) {
      bad++;
      continue;
    }
    final name = p.first;
    final key = name.toLowerCase();
    final id = byName[key];
    if (id != null) {
      addEntry(id, amt, 'পুরনো বাকি', name: name);
    } else {
      final r = cust.doc();
      final e = r.collection('entries').doc();
      final now = Timestamp.now();
      final b = db.batch();
      b.set(r, {...newCust(name, '', p.length > 2 ? p[1] : '', ''), 'balance': amt});
      b.set(e, {'amount': amt, 'note': 'পুরনো বাকি', 'date': now});
      b.set(ledger.doc(e.id), {'cid': r.id, 'name': name, 'amount': amt, 'note': 'পুরনো বাকি', 'date': now});
      fire(b.commit());
      byName[key] = r.id;
    }
    ok++;
  }
  return (ok, bad);
}

// অনুমতি (Android): আগে নোটিফিকেশন, বাকিগুলো ব্যবহারকারী চাইলে
Future<void> askAlarmPerms() async {
  try {
    await Permission.scheduleExactAlarm.request();
  } catch (_) {}
  try {
    await Permission.ignoreBatteryOptimizations.request();
  } catch (_) {}
}

Future<void> askPermissions(BuildContext c, {bool force = false}) async {
  if (!isAndroid) return;
  File? f;
  try {
    f = File('${(await getApplicationSupportDirectory()).path}/perm_done');
    if (!force && await f.exists()) return;
  } catch (_) {}
  if (!c.mounted) return;
  final all = await showDialog<bool>(
      context: c,
      barrierDismissible: false,
      builder: (x) => AlertDialog(
          title: const Text('তাগাদার অ্যালার্মের অনুমতি'),
          content: const SingleChildScrollView(child: Text('তাগাদা ঠিক সময়ে বাজাতে নোটিফিকেশনের অনুমতি লাগবে।\n\n"সব অনুমতি দিন" চাপলে অ্যালার্ম ও ব্যাটারির সেটিংস পেজ খুলবে — সেখানে অ্যাপটি বেছে অনুমতি দিয়ে ব্যাক করুন।\n\nপরে চাইলে সেটিংস থেকেও দেওয়া যাবে।')),
          actions: [
            TextButton(onPressed: () => Navigator.pop(x, false), child: const Text('শুধু নোটিফিকেশন')),
            FilledButton(onPressed: () => Navigator.pop(x, true), child: const Text('সব অনুমতি দিন')),
          ]));
  try {
    await Permission.notification.request();
    if (all == true) await askAlarmPerms();
    await f?.writeAsString('1');
  } catch (_) {}
}

// হোম স্ক্রিন উইজেটের ডাটা আপডেট
Future<void> pushWidget(List<Doc> docs) async {
  if (!isAndroid) return;
  try {
    final l = docs.where((d) => numOf(d.data(), 'balance') > 0).toList();
    final total = l.fold<num>(0, (a, d) => a + numOf(d.data(), 'balance'));
    final due = l.where((d) => dtOf(d.data(), 'due') != null).toList()
      ..sort((a, b) => dtOf(a.data(), 'due')!.compareTo(dtOf(b.data(), 'due')!));
    final lines = due.take(3).map((d) => '⏰ ${str(d.data(), 'name')} • ${tk(numOf(d.data(), 'balance'))}').join('\n');
    await HomeWidget.saveWidgetData<String>('total', tk(total));
    await HomeWidget.saveWidgetData<String>('count', '${l.length} জন বাকি');
    await HomeWidget.saveWidgetData<String>('list', lines.isEmpty ? 'কোনো তাগাদা সেট নেই' : lines);
    await HomeWidget.updateWidget(name: 'BakiWidget', androidName: 'BakiWidget');
  } catch (_) {}
}

Future<void> doLogout(BuildContext c) async {
  final ok = await showDialog<bool>(
      context: c,
      builder: (x) => AlertDialog(title: const Text('লগআউট করবেন?'), content: const Text('আপনার ডাটা নিরাপদ থাকবে। আবার লগইন করলেই পাবেন।'), actions: [
            TextButton(onPressed: () => Navigator.pop(x, false), child: const Text('না')),
            FilledButton(onPressed: () => Navigator.pop(x, true), child: const Text('লগআউট')),
          ]));
  if (ok != true || !c.mounted) return;
  Navigator.of(c).popUntil((r) => r.isFirst);
  await cancelAllAlarms();
  await FirebaseAuth.instance.signOut();
  resetPrefs();
}

// প্লাগিন ছাড়াই ফোনের টাইমজোন ঠিক করা: অফসেট মিললে সেই লোকেশন নেওয়া হয়
void setLocalTz() {
  try {
    final off = DateTime.now().timeZoneOffset;
    final pref = ['Asia/Dhaka', 'Asia/Kolkata', 'Asia/Dubai', 'Asia/Riyadh', 'Asia/Kuala_Lumpur', 'Asia/Singapore'];
    for (final n in pref) {
      final l = tz.getLocation(n);
      if (tz.TZDateTime.now(l).timeZoneOffset == off) {
        tz.setLocalLocation(l);
        return;
      }
    }
    for (final l in tz.timeZoneDatabase.locations.values) {
      if (tz.TZDateTime.now(l).timeZoneOffset == off) {
        tz.setLocalLocation(l);
        return;
      }
    }
  } catch (_) {}
  tz.setLocalLocation(tz.getLocation('Asia/Dhaka'));
}

// ───────── নিরাপদ স্টার্টআপ + ক্র্যাশ লগ ─────────
late Future<void> bootFuture;
String? bootError;

String webLog = '';
Future<File> crashFile() async => File('${(await getApplicationSupportDirectory()).path}/crash_log.txt');

Future<void> logCrash(Object e, StackTrace? st) async {
  if (kIsWeb) {
    webLog += '[${DateTime.now()}] $e\n${st ?? ''}\n\n';
    if (webLog.length > 30000) webLog = webLog.substring(webLog.length - 20000);
    return;
  }
  try {
    final f = await crashFile();
    await f.writeAsString('[${DateTime.now()}] $e\n${st ?? ''}\n\n', mode: FileMode.append);
    if (await f.length() > 60000) {
      final all = await f.readAsString();
      await f.writeAsString(all.substring(all.length - 30000));
    }
  } catch (_) {}
}

Future<void> boot() async {
  bootError = null;
  try {
    await initializeDateFormatting('bn');
  } catch (e, st) {
    logCrash(e, st);
  }
  try {
    if (Firebase.apps.isEmpty) await Firebase.initializeApp(options: fbOptions);
    if (!kIsWeb) {
      try {
        db.settings = const Settings(persistenceEnabled: true, cacheSizeBytes: Settings.CACHE_SIZE_UNLIMITED);
      } catch (_) {}
    }
  } catch (e, st) {
    bootError = 'Firebase চালু করা যায়নি:\n$e';
    logCrash(e, st);
    return;
  }
  if (isWindows) {
    try {
      await deskInit();
    } catch (e, st) {
      logCrash(e, st);
    }
  }
  if (mobile) {
    try {
      await initNotifications();
    } catch (e, st) {
      logCrash(e, st);
    }
  }
}

void main() {
  runZonedGuarded(() {
    WidgetsFlutterBinding.ensureInitialized();
    FlutterError.onError = (d) {
      FlutterError.presentError(d);
      logCrash(d.exception, d.stack);
    };
    ui.PlatformDispatcher.instance.onError = (e, st) {
      logCrash(e, st);
      return true;
    };
    bootFuture = boot();
    runApp(const App());
  }, (e, st) => logCrash(e, st));
}

class BootErrorPage extends StatelessWidget {
  const BootErrorPage({super.key});
  @override
  Widget build(BuildContext c) => Scaffold(
      body: SafeArea(
          child: Center(
              child: SingleChildScrollView(
                  padding: const EdgeInsets.all(24),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.error_outline, size: 56, color: Colors.red),
                    const SizedBox(height: 12),
                    const Text('অ্যাপ চালু করা যায়নি', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 10),
                    SelectableText(bootError ?? '', textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54)),
                    const SizedBox(height: 20),
                    FilledButton(
                        onPressed: () async {
                          bootFuture = boot();
                          await bootFuture;
                          if (!c.mounted) return;
                          Navigator.pushReplacement(c, MaterialPageRoute(builder: (_) => bootError == null ? const Gate() : const BootErrorPage()));
                        },
                        child: const Text('আবার চেষ্টা করুন')),
                  ])))));
}

class CrashLogPage extends StatefulWidget {
  const CrashLogPage({super.key});
  @override
  State<CrashLogPage> createState() => _CLPState();
}

class _CLPState extends State<CrashLogPage> {
  String txt = '...';
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    String t;
    try {
      if (kIsWeb) {
        t = webLog;
      } else {
        final f = await crashFile();
        t = await f.exists() ? await f.readAsString() : '';
      }
    } catch (e) {
      t = 'পড়া যায়নি: $e';
    }
    if (mounted) setState(() => txt = t.trim().isEmpty ? 'কোনো ত্রুটি নেই ✅' : t);
  }

  @override
  Widget build(BuildContext c) => Scaffold(
      appBar: AppBar(title: const Text('ত্রুটির লগ'), actions: [
        IconButton(icon: const Icon(Icons.copy), tooltip: 'কপি', onPressed: () {
          Clipboard.setData(ClipboardData(text: txt));
          toast(c, 'কপি হয়েছে');
        }),
        IconButton(icon: const Icon(Icons.delete_outline), tooltip: 'মুছুন', onPressed: () async {
          try {
            if (kIsWeb) {
              webLog = '';
            } else {
              final f = await crashFile();
              if (await f.exists()) await f.delete();
            }
          } catch (_) {}
          load();
        }),
      ]),
      body: SingleChildScrollView(padding: const EdgeInsets.all(14), child: SelectableText(txt, style: const TextStyle(fontSize: 12))));
}

// ───────── App & Splash ─────────
class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext c) => ValueListenableBuilder<int>(
      valueListenable: seed,
      builder: (_, sd, __) => ValueListenableBuilder<int>(
          valueListenable: bgIdx,
          builder: (_, bg, ___) => MaterialApp(
              navigatorKey: navKey,
              title: 'Dhar Dena',
              debugShowCheckedModeBanner: false,
              scrollBehavior: const MaterialScrollBehavior().copyWith(dragDevices: {ui.PointerDeviceKind.touch, ui.PointerDeviceKind.mouse, ui.PointerDeviceKind.trackpad, ui.PointerDeviceKind.stylus}),
              theme: ThemeData(useMaterial3: true, colorSchemeSeed: Color(sd), scaffoldBackgroundColor: bgColors[bg]),
              // সিস্টেমের ফন্ট খুব বড় করা থাকলেও যেন লেখা উপচে না যায়
              builder: (ctx, child) {
                final mq = MediaQuery.of(ctx);
                final sc = mq.textScaler.scale(10) / 10;
                final body = child ?? const SizedBox();
                return MediaQuery(
                    data: mq.copyWith(textScaler: TextScaler.linear(sc.clamp(0.85, 1.2).toDouble())),
                    child: mq.size.width > 900 ? ColoredBox(color: const Color(0xFFE3EAE3), child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 760), child: body))) : body);
              },
              home: const Splash())));
}

class Splash extends StatefulWidget {
  const Splash({super.key});
  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> with SingleTickerProviderStateMixin {
  late final ac = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))..forward();
  @override
  void initState() {
    super.initState();
    go();
  }

  Future<void> go() async {
    await Future.wait([Future.delayed(const Duration(milliseconds: 2200)), bootFuture]);
    if (!mounted) return;
    Navigator.pushReplacement(
        context,
        PageRouteBuilder(
            transitionDuration: const Duration(milliseconds: 500),
            pageBuilder: (_, __, ___) => bootError == null ? const Gate() : const BootErrorPage(),
            transitionsBuilder: (_, a, __, w) => FadeTransition(opacity: a, child: w)));
  }

  @override
  void dispose() {
    ac.dispose();
    super.dispose();
  }

  Animation<double> iv(double a, double b, [Curve k = Curves.easeOut]) => CurvedAnimation(parent: ac, curve: Interval(a, b, curve: k));
  @override
  Widget build(BuildContext c) => Scaffold(
      body: Center(
          child: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
        ScaleTransition(scale: iv(0, .6, Curves.elasticOut), child: FadeTransition(opacity: iv(0, .3), child: Image.asset('assets/logo.png', width: 230))),
        const SizedBox(height: 24),
        FadeTransition(
            opacity: iv(.5, .85),
            child: SlideTransition(
                position: Tween<Offset>(begin: const Offset(0, .5), end: Offset.zero).animate(iv(.5, .85)),
                child: const Padding(padding: EdgeInsets.symmetric(horizontal: 20), child: Text('বাকি • খাতা • বাজার • হিসাব — সব এক জায়গায়', textAlign: TextAlign.center, style: TextStyle(fontSize: 14, color: Colors.black54))))),
        const SizedBox(height: 32),
        SizedBox(
            width: 140,
            child: AnimatedBuilder(
                animation: ac,
                builder: (_, __) => LinearProgressIndicator(value: ac.value, minHeight: 5, borderRadius: BorderRadius.circular(9), color: const Color(0xFF2E7D32)))),
      ]))));
}

// লোডিংয়ের সময় লোগোসহ প্রগ্রেস (স্প্ল্যাশ/গেট/ডাটা লোড — সব জায়গায় একই)
class LogoLoader extends StatelessWidget {
  final double size;
  const LogoLoader({super.key, this.size = 170});
  @override
  Widget build(BuildContext c) => Center(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Image.asset('assets/logo.png', width: size),
        const SizedBox(height: 20),
        SizedBox(width: 120, child: LinearProgressIndicator(minHeight: 4, borderRadius: BorderRadius.circular(9))),
      ]));
}

class Gate extends StatelessWidget {
  const Gate({super.key});
  @override
  Widget build(BuildContext c) => StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (c, s) {
        if (s.connectionState == ConnectionState.waiting) return const Scaffold(body: LogoLoader());
        return s.data == null ? const Login() : const Home();
      });
}

// ───────── Login ─────────
String authMsg(FirebaseAuthException x) {
  switch (x.code) {
    case 'invalid-email':
      return 'ইমেইল ঠিকভাবে লিখুন';
    case 'user-not-found':
    case 'wrong-password':
    case 'invalid-credential':
      return 'ইমেইল বা পাসওয়ার্ড ভুল';
    case 'email-already-in-use':
      return 'এই ইমেইলে আগেই একাউন্ট আছে, লগইন করুন';
    case 'weak-password':
      return 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের দিন';
    case 'network-request-failed':
      return 'ইন্টারনেট সংযোগ নেই';
    case 'too-many-requests':
      return 'অনেকবার চেষ্টা হয়েছে, একটু পরে আবার চেষ্টা করুন';
    case 'operation-not-allowed':
      return 'Firebase এ Email/Password লগইন চালু করা নেই (Console → Authentication → Sign-in method)';
    case 'configuration-not-found':
      return 'Firebase Authentication চালু করা হয়নি (Console → Authentication → Get started)';
    case 'invalid-api-key':
    case 'app-not-authorized':
      return 'Firebase কনফিগারেশনে সমস্যা আছে (API key / অ্যাপ অনুমতি)';
    default:
      return 'সমস্যা হয়েছে (${x.code})';
  }
}

class Login extends StatefulWidget {
  const Login({super.key});
  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final e = TextEditingController(), p = TextEditingController();
  bool busy = false, hide = true;
  String? err, info;
  Future<void> go(bool signup) async {
    if (e.text.trim().isEmpty || p.text.isEmpty) {
      setState(() {
        err = 'ইমেইল ও পাসওয়ার্ড দিন';
        info = null;
      });
      return;
    }
    setState(() {
      busy = true;
      err = null;
      info = null;
    });
    try {
      final a = FirebaseAuth.instance;
      if (signup) {
        await a.createUserWithEmailAndPassword(email: e.text.trim(), password: p.text);
      } else {
        await a.signInWithEmailAndPassword(email: e.text.trim(), password: p.text);
      }
    } on FirebaseAuthException catch (x) {
      err = authMsg(x);
    } catch (_) {
      err = 'সমস্যা হয়েছে, আবার চেষ্টা করুন';
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> forgot() async {
    if (e.text.trim().isEmpty) {
      setState(() {
        err = 'আগে ইমেইল লিখুন';
        info = null;
      });
      return;
    }
    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: e.text.trim());
      if (mounted) {
        setState(() {
          info = 'পাসওয়ার্ড রিসেটের লিংক ইমেইলে পাঠানো হয়েছে';
          err = null;
        });
      }
    } on FirebaseAuthException catch (x) {
      if (mounted) {
        setState(() {
          err = authMsg(x);
          info = null;
        });
      }
    } catch (_) {
      if (mounted) setState(() => err = 'সমস্যা হয়েছে, আবার চেষ্টা করুন');
    }
  }

  @override
  void dispose() {
    e.dispose();
    p.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext c) => Scaffold(
      body: Center(
          child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 400),
                  child: Column(children: [
                    Image.asset('assets/logo.png', width: 170),
                    const SizedBox(height: 6),
                    const Text('আপনার ডিজিটাল হিসাবের খাতা', style: TextStyle(color: Colors.black54)),
                    const SizedBox(height: 22),
                    TextField(controller: e, keyboardType: TextInputType.emailAddress, decoration: deco(label: 'ইমেইল', prefix: const Icon(Icons.mail_outline))),
                    const SizedBox(height: 12),
                    TextField(
                        controller: p,
                        obscureText: hide,
                        onSubmitted: (_) => busy ? null : go(false),
                        decoration: deco(label: 'পাসওয়ার্ড', prefix: const Icon(Icons.lock_outline), suffix: IconButton(icon: Icon(hide ? Icons.visibility_off : Icons.visibility), onPressed: () => setState(() => hide = !hide)))),
                    if (err != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(err!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.red))),
                    if (info != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(info!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.green))),
                    const SizedBox(height: 18),
                    SizedBox(width: double.infinity, height: 50, child: FilledButton(onPressed: busy ? null : () => go(false), child: busy ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5)) : const Text('লগইন'))),
                    TextButton(onPressed: busy ? null : forgot, child: const Text('পাসওয়ার্ড ভুলে গেছেন?')),
                    TextButton(onPressed: busy ? null : () => go(true), child: const Text('নতুন একাউন্ট খুলুন (প্রথমবার)', textAlign: TextAlign.center)),
                  ])))));
}

// ───────── Home ─────────
class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> with WidgetsBindingObserver {
  int tab = 0;
  StreamSubscription? s1, s2, s3;
  Timer? tm, pt;
  final shown = <String>{};
  bool unlocked = false, asked = false;
  DateTime? pausedAt;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    s1 = me.collection('meta').doc('settings').snapshots().listen((d) {
      final m = d.data();
      applyPrefs(m);
      // নতুন ইউজার হলে প্রথমবার দোকানের নাম/লোগো সেট করতে বলা
      if (!asked && !d.metadata.isFromCache) {
        asked = true;
        if (m == null || str(m, 'shop').isEmpty) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfilePage(first: true)));
          });
        }
      }
    }, onError: (_) {});
    s2 = cust.snapshots(includeMetadataChanges: true).listen((q) {
      custDocs.value = q.docs;
      custError.value = null;
      custReady.value = true;
      setPending(q.metadata.hasPendingWrites);
      reschedule();
      pushWidget(q.docs);
    }, onError: (e) {
      final t = '$e';
      custError.value = t.length > 140 ? t.substring(0, 140) : t;
    });
    s3 = bazar.orderBy('createdAt', descending: true).snapshots().listen((q) {
      bazarDocs.value = q.docs;
      reschedule();
    }, onError: (_) {});
    if (isWindows || kIsWeb) tm = Timer.periodic(const Duration(seconds: 20), (_) => desktopAlarm());
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await handleLaunch();
      if (!mounted) return;
      await askPermissions(context);
      reschedule();
      if (mounted) checkUpdate(context, silent: true);
    });
  }

  // ৪ সেকেন্ডের বেশি লেখা সিংক না হলেই "অফলাইন" ব্যানার দেখানো
  void setPending(bool p) {
    pt?.cancel();
    if (p) {
      pt = Timer(const Duration(seconds: 4), () => custPending.value = true);
    } else {
      custPending.value = false;
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState st) {
    if (st == AppLifecycleState.paused) pausedAt = DateTime.now();
    if (st == AppLifecycleState.resumed && pausedAt != null) {
      if (pinHash.value != null && DateTime.now().difference(pausedAt!).inSeconds > 45) setState(() => unlocked = false);
      pausedAt = null;
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    s1?.cancel();
    s2?.cancel();
    s3?.cancel();
    tm?.cancel();
    pt?.cancel();
    super.dispose();
  }

  // Windows / Web: অ্যাপ খোলা থাকলে সময় হলে পপআপ
  Future<void> desktopAlarm() async {
    final now = DateTime.now();
    for (final d in custDocs.value) {
      final m = d.data();
      final due = dtOf(m, 'due');
      if (due == null || numOf(m, 'balance') <= 0 || due.isAfter(now) || now.difference(due).inHours > 12) continue;
      if (!shown.add('${d.id}${due.millisecondsSinceEpoch}')) continue;
      try {
        if (isWindows) {
          Process.run('powershell', ['-NoProfile', '-c', '1..3|%{[console]::beep(1200,400)}']);
          deskShow();
        }
      } catch (_) {}
      if (!mounted) return;
      await showDialog(
          context: context,
          builder: (x) => AlertDialog(
                  title: const Text('⏰ তাগাদার সময় হয়েছে!'),
                  content: Text('${str(m, 'name')}\n${str(m, 'village')} ${str(m, 'phone')}\nবাকি: ${tk(numOf(m, 'balance'))}', style: const TextStyle(fontSize: 18)),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(x), child: const Text('পরে')),
                    FilledButton(
                        onPressed: () {
                          Navigator.pop(x);
                          openDetail(context, d.id);
                        },
                        child: const Text('খুলুন'))
                  ]));
    }
  }

  @override
  Widget build(BuildContext c) => ValueListenableBuilder<int?>(
      valueListenable: pinHash,
      builder: (c, pin, _) {
        if (pin != null && !unlocked) return PinScreen(hash: pin, onOk: () => setState(() => unlocked = true));
        return body(c);
      });

  Widget body(BuildContext c) {
    final pages = <Widget>[const CustomerList(), const DuePage(), const CashbookPage(), const BazarPage(), const MorePage()];
    return Scaffold(
      appBar: AppBar(
          titleSpacing: 12,
          title: Row(children: [
            shopAvatar(r: 15),
            const SizedBox(width: 10),
            Expanded(
                child: ValueListenableBuilder<String>(
                    valueListenable: shop,
                    builder: (_, s, __) => FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(s, style: const TextStyle(fontWeight: FontWeight.w700))))),
          ]),
          actions: [
            if (tab == 0) IconButton(icon: const Icon(Icons.bolt), tooltip: 'দ্রুত পুরনো বাকি লিখুন', onPressed: () => quickEntry(c)),
            if (isWindows) IconButton(icon: const Icon(Icons.picture_in_picture_alt), tooltip: 'ছোট উইজেট', onPressed: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const MiniPage()))),
          ]),
      body: Column(children: [
        ValueListenableBuilder<bool>(
            valueListenable: custPending,
            builder: (_, p, __) => p
                ? Container(
                    width: double.infinity,
                    color: Colors.amber.shade100,
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    child: Row(children: [
                      const Icon(Icons.cloud_off, size: 16),
                      const SizedBox(width: 8),
                      Expanded(child: Text('অফলাইনে সেভ হয়েছে — ইন্টারনেট এলে নিজে সিংক হবে', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12.5, color: Colors.brown.shade800))),
                    ]))
                : const SizedBox.shrink()),
        Expanded(child: pages[tab]),
      ]),
      floatingActionButton: tab == 0 ? FloatingActionButton.extended(onPressed: () => customerForm(c), icon: const Icon(Icons.person_add), label: const Text('নতুন কাস্টমার')) : null,
      bottomNavigationBar: ValueListenableBuilder<List<Doc>>(
          valueListenable: custDocs,
          builder: (_, docs, __) {
            final n = overdueCount(docs);
            return NavigationBar(selectedIndex: tab, onDestinationSelected: (i) => setState(() => tab = i), destinations: [
              const NavigationDestination(icon: Icon(Icons.people_alt_outlined), selectedIcon: Icon(Icons.people_alt), label: 'বাকি'),
              NavigationDestination(
                  icon: Badge(isLabelVisible: n > 0, label: Text('$n'), child: const Icon(Icons.alarm_outlined)),
                  selectedIcon: Badge(isLabelVisible: n > 0, label: Text('$n'), child: const Icon(Icons.alarm)),
                  label: 'তাগাদা'),
              const NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'খাতা'),
              const NavigationDestination(icon: Icon(Icons.shopping_cart_outlined), selectedIcon: Icon(Icons.shopping_cart), label: 'বাজার'),
              const NavigationDestination(icon: Icon(Icons.apps_outlined), selectedIcon: Icon(Icons.apps), label: 'আরও'),
            ]);
          }),
    );
  }
}

void quickEntry(BuildContext c) {
  final t = TextEditingController();
  showModalBottomSheet(
      context: c,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (ctx) => Padding(
          padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 20),
          child: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('⚡ দ্রুত পুরনো বাকি লিখুন', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            const Text('প্রতি লাইনে একজন:  নাম, গ্রাম, টাকা\nযেমন:  রহিম, কুমিল্লা, ৫০০\nগ্রাম না থাকলে:  করিম, ২০০\nএকই নাম থাকলে তার সাথে যোগ হবে।', style: TextStyle(color: Colors.black54)),
            const SizedBox(height: 12),
            TextField(controller: t, maxLines: 6, minLines: 3, autofocus: true, decoration: deco(hint: 'রহিম, কুমিল্লা, ৫০০\nকরিম, ২০০')),
            const SizedBox(height: 12),
            SizedBox(
                width: double.infinity,
                height: 50,
                child: FilledButton(
                    onPressed: () async {
                      final r = await quickAdd(t.text);
                      if (ctx.mounted) Navigator.pop(ctx);
                      if (c.mounted) toast(c, r.$2 == 0 ? '${r.$1} টি বাকি যোগ হয়েছে' : '${r.$1} টি যোগ হয়েছে, ${r.$2} লাইন ঠিক ফরম্যাটে ছিল না');
                    },
                    child: const Text('যোগ করুন'))),
          ]))));
}

// ───────── কাস্টমার তালিকা ─────────
String greeting() {
  final h = DateTime.now().hour;
  if (h >= 5 && h < 12) return 'শুভ সকাল';
  if (h >= 12 && h < 15) return 'শুভ দুপুর';
  if (h >= 15 && h < 18) return 'শুভ বিকেল';
  if (h >= 18 && h < 20) return 'শুভ সন্ধ্যা';
  return 'শুভ রাত্রি';
}

// নাম অনুযায়ী প্রতিটি কাস্টমারের নিজস্ব রঙের অ্যাভাটার
const _avatarPal = <MaterialColor>[Colors.green, Colors.teal, Colors.blue, Colors.indigo, Colors.purple, Colors.pink, Colors.orange, Colors.brown];
MaterialColor avatarColor(String n) => _avatarPal[n.codeUnits.fold<int>(0, (a, b) => a + b) % _avatarPal.length];

Widget tile(BuildContext c, Doc d) {
  final m = d.data();
  final bal = numOf(m, 'balance');
  final due = dtOf(m, 'due');
  final overdue = due != null && bal > 0 && due.isBefore(DateTime.now());
  final name = str(m, 'name');
  final sub = [str(m, 'village'), str(m, 'phone')].where((x) => x.isNotEmpty).join(' • ');
  final lateDays = (overdue && due != null) ? DateTime.now().difference(due).inDays : 0;
  final dueLine = due != null && bal > 0 ? '⏰ ${dt(due)}${lateDays > 0 ? ' • ${_nf.format(lateDays)} দিন দেরি' : ''}' : '';
  final lines = [if (sub.isNotEmpty) sub, if (dueLine.isNotEmpty) dueLine];
  return card(ListTile(
    onTap: () => openDetail(c, d.id),
    leading: CircleAvatar(backgroundColor: avatarColor(name).shade100, child: Text(name.isEmpty ? '?' : name.characters.first, style: TextStyle(fontWeight: FontWeight.bold, color: avatarColor(name).shade800))),
    title: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
    subtitle: lines.isEmpty ? null : Text(lines.join('\n'), maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: overdue ? Colors.red : null)),
    trailing: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 110),
        child: FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerRight,
            child: Text(bal < 0 ? 'অগ্রিম ${tk(-bal)}' : tk(bal), style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: overdue ? Colors.red : bal > 0 ? Colors.deepOrange : Colors.green)))),
  ));
}

Widget statBox(String l, String v) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(l, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white70, fontSize: 12)),
      FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(v, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w800))),
    ]);

class TodayStats extends StatefulWidget {
  const TodayStats({super.key});
  @override
  State<TodayStats> createState() => _TSState();
}

class _TSState extends State<TodayStats> {
  late final Stream<QuerySnapshot<Map<String, dynamic>>> st = ledger.where('date', isGreaterThanOrEqualTo: Timestamp.fromDate(startOfToday())).snapshots();
  @override
  Widget build(BuildContext c) => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: st,
      builder: (c, s) {
        num given = 0, got = 0;
        for (final d in s.data?.docs ?? <QueryDocumentSnapshot<Map<String, dynamic>>>[]) {
          final m = d.data();
          if (str(m, 'note') == 'পুরনো বাকি') continue;
          final a = numOf(m, 'amount');
          if (a > 0) {
            given += a;
          } else {
            got += -a;
          }
        }
        return Row(children: [Expanded(child: statBox('আজ বাকি দিয়েছি', tk(given))), const SizedBox(width: 10), Expanded(child: statBox('আজ জমা পেয়েছি', tk(got)))]);
      });
}

class CustomerList extends StatefulWidget {
  const CustomerList({super.key});
  @override
  State<CustomerList> createState() => _CLState();
}

class _CLState extends State<CustomerList> {
  final qc = TextEditingController();
  String q = '';
  int filter = 0, sort = 0;
  static const filters = ['সব', 'বাকি আছে', 'দেরি', 'পরিশোধিত'];
  @override
  void dispose() {
    qc.dispose();
    super.dispose();
  }

  List<Doc> apply(List<Doc> all) {
    final now = DateTime.now();
    final key = toEn(q).toLowerCase().trim();
    final l = all.where((d) {
      final m = d.data();
      final bal = numOf(m, 'balance');
      final due = dtOf(m, 'due');
      if (filter == 1 && bal <= 0) return false;
      if (filter == 2 && !(bal > 0 && due != null && due.isBefore(now))) return false;
      if (filter == 3 && bal > 0) return false;
      if (key.isEmpty) return true;
      return toEn('${str(m, 'name')} ${str(m, 'village')} ${str(m, 'phone')}').toLowerCase().contains(key);
    }).toList();
    l.sort((a, b) {
      final x = a.data(), y = b.data();
      if (sort == 1) return numOf(y, 'balance').compareTo(numOf(x, 'balance'));
      if (sort == 2) {
        final p = dtOf(x, 'due'), r = dtOf(y, 'due');
        if (p == null && r == null) return 0;
        if (p == null) return 1;
        if (r == null) return -1;
        return p.compareTo(r);
      }
      return str(x, 'name').toLowerCase().compareTo(str(y, 'name').toLowerCase());
    });
    return l;
  }

  @override
  Widget build(BuildContext c) => withCust((c, all) {
        final list = apply(all);
        final total = all.fold<num>(0, (a, d) => a + numOf(d.data(), 'balance'));
        final count = all.where((d) => numOf(d.data(), 'balance') > 0).length;
        final counts = <int>[all.length, count, overdueCount(all), all.length - count];
        final paidPct = all.isEmpty ? 0 : ((all.length - count) * 100 / all.length).round();
        Doc? top;
        for (final d in all) {
          final b = numOf(d.data(), 'balance');
          if (b > 0 && (top == null || b > numOf(top.data(), 'balance'))) top = d;
        }
        final topLine = top == null ? '' : 'সর্বোচ্চ বাকি: ${str(top.data(), 'name')} • ${tk(numOf(top.data(), 'balance'))}';
        final header = Column(children: [
          Container(
              margin: const EdgeInsets.all(14),
              padding: const EdgeInsets.all(18),
              width: double.infinity,
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), gradient: LinearGradient(colors: [Theme.of(c).colorScheme.primary, Theme.of(c).colorScheme.tertiary])),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${greeting()}${owner.value.trim().isEmpty ? '' : ', ${owner.value.trim()}'} 👋', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                const SizedBox(height: 6),
                const Text('মোট বাকি', style: TextStyle(color: Colors.white70)),
                TweenAnimationBuilder<double>(
                    tween: Tween<double>(end: total.toDouble()),
                    duration: const Duration(milliseconds: 800),
                    curve: Curves.easeOutCubic,
                    builder: (_, v, __) => FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(tk(v), style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w800)))),
                Text('$count জন বাকি আছে • মোট ${all.length} জন কাস্টমার', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white70)),
                if (topLine.isNotEmpty) Text(topLine, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white70, fontSize: 12.5)),
                if (all.isNotEmpty) ...[
                  const SizedBox(height: 10),
                  Row(children: [
                    Expanded(child: LinearProgressIndicator(value: paidPct / 100, minHeight: 6, borderRadius: BorderRadius.circular(9), backgroundColor: Colors.white24, color: Colors.white)),
                    const SizedBox(width: 10),
                    Text('${_nf.format(paidPct)}% পরিশোধিত', style: const TextStyle(color: Colors.white, fontSize: 12.5, fontWeight: FontWeight.w600)),
                  ]),
                ],
                const Divider(color: Colors.white24, height: 22),
                const TodayStats(),
              ])),
          Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              child: Row(children: [
                Expanded(
                    child: TextField(
                        controller: qc,
                        onChanged: (v) => setState(() => q = v),
                        decoration: deco(hint: 'নাম / গ্রাম / মোবাইল দিয়ে খুঁজুন', prefix: const Icon(Icons.search), filled: true, suffix: q.isEmpty ? null : IconButton(icon: const Icon(Icons.close), onPressed: () => setState(() { qc.clear(); q = ''; }))))),
                PopupMenuButton<int>(
                    icon: const Icon(Icons.sort),
                    tooltip: 'সাজান',
                    onSelected: (v) => setState(() => sort = v),
                    itemBuilder: (_) => const [
                          PopupMenuItem(value: 0, child: Text('নাম অনুযায়ী')),
                          PopupMenuItem(value: 1, child: Text('বেশি বাকি আগে')),
                          PopupMenuItem(value: 2, child: Text('তাগাদার সময় অনুযায়ী')),
                        ]),
              ])),
          SizedBox(
              height: 50,
              child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12), children: [
                for (var i = 0; i < filters.length; i++)
                  Padding(padding: const EdgeInsets.only(right: 8, top: 8, bottom: 6), child: ChoiceChip(label: Text('${filters[i]} ${_nf.format(counts[i])}'), selected: filter == i, onSelected: (_) => setState(() => filter = i))),
              ])),
        ]);
        return ListView.builder(
            padding: const EdgeInsets.only(bottom: 96),
            itemCount: list.length + 1 + (list.isEmpty ? 1 : 0),
            itemBuilder: (c, i) {
              if (i == 0) return header;
              if (list.isEmpty) {
                return Padding(
                    padding: const EdgeInsets.all(40),
                    child: Column(children: [
                      if (all.isEmpty) ...[Image.asset('assets/logo.png', width: 150), const SizedBox(height: 16)],
                      Text(all.isEmpty ? 'কোনো কাস্টমার নেই।\nনিচের "নতুন কাস্টমার" বা ⚡ চাপুন।' : 'কিছু পাওয়া যায়নি', textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54)),
                    ]));
              }
              return tile(c, list[i - 1]);
            });
      });
}

// ───────── তাগাদা ─────────
void snooze(BuildContext c, Doc d) {
  final due = dtOf(d.data(), 'due');
  if (due == null) return;
  final n = DateTime.now();
  var next = due.add(const Duration(days: 1));
  if (!next.isAfter(n)) next = DateTime(n.year, n.month, n.day + 1, due.hour, due.minute);
  d.reference.update({'due': Timestamp.fromDate(next)});
  toast(c, 'তাগাদা পরের দিনে সরানো হয়েছে');
}

Widget dueCard(BuildContext c, Doc d) {
  final m = d.data();
  final bal = numOf(m, 'balance');
  final due = dtOf(m, 'due')!;
  final over = due.isBefore(DateTime.now());
  final ph = phoneRaw(str(m, 'phone'));
  final sub = [str(m, 'village'), str(m, 'phone')].where((x) => x.isNotEmpty).join(' • ');
  final msg = dueMsg(m);
  return card(Padding(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        InkWell(
            onTap: () => openDetail(c, d.id),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(str(m, 'name'), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                if (sub.isNotEmpty) Text(sub, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.black54)),
                Text('⏰ ${dt(due)}', style: TextStyle(color: over ? Colors.red : Colors.black87, fontWeight: FontWeight.w600)),
              ])),
              const SizedBox(width: 8),
              ConstrainedBox(constraints: const BoxConstraints(maxWidth: 120), child: FittedBox(fit: BoxFit.scaleDown, child: Text(tk(bal), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Colors.deepOrange)))),
            ])),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 0, children: [
          if (mobile && ph.isNotEmpty) ActionChip(avatar: const Icon(Icons.call, size: 18), label: const Text('কল'), onPressed: () => openUrl(c, 'tel:$ph')),
          if (phoneIntl(ph).isNotEmpty) ActionChip(avatar: const Icon(Icons.chat, size: 18), label: const Text('WhatsApp'), onPressed: () => openUrl(c, waUrl(ph, msg))),
          if (mobile && ph.isNotEmpty) ActionChip(avatar: const Icon(Icons.sms, size: 18), label: const Text('SMS'), onPressed: () => openUrl(c, smsUrl(ph, msg))),
          ActionChip(avatar: const Icon(Icons.update, size: 18), label: const Text('+১ দিন'), onPressed: () => snooze(c, d)),
          ActionChip(avatar: const Icon(Icons.check, size: 18), label: const Text('তাগাদা শেষ'), onPressed: () => d.reference.update({'due': null})),
        ]),
      ])));
}

class DuePage extends StatelessWidget {
  const DuePage({super.key});
  @override
  Widget build(BuildContext c) => withCust((c, docs) {
        final now = DateTime.now();
        final tomorrow = DateTime(now.year, now.month, now.day + 1);
        final l = docs.where((d) => dtOf(d.data(), 'due') != null && numOf(d.data(), 'balance') > 0).toList()
          ..sort((a, b) => dtOf(a.data(), 'due')!.compareTo(dtOf(b.data(), 'due')!));
        if (l.isEmpty) {
          return const Center(child: Padding(padding: EdgeInsets.all(24), child: Text('কোনো তাগাদা সেট করা নেই\nকাস্টমার খুলে "তাগাদা সেট" করুন', textAlign: TextAlign.center)));
        }
        final overdue = l.where((d) => dtOf(d.data(), 'due')!.isBefore(now)).toList();
        final today = l.where((d) {
          final x = dtOf(d.data(), 'due')!;
          return !x.isBefore(now) && x.isBefore(tomorrow);
        }).toList();
        final later = l.where((d) => !dtOf(d.data(), 'due')!.isBefore(tomorrow)).toList();
        final items = <Object>[];
        void sec(String t, List<Doc> x) {
          if (x.isNotEmpty) {
            items.add(t);
            items.addAll(x);
          }
        }

        sec('⚠ সময় পার হয়েছে (${overdue.length})', overdue);
        sec('📅 আজ (${today.length})', today);
        sec('🗓 আসছে (${later.length})', later);
        return ListView.builder(
            padding: const EdgeInsets.only(top: 6, bottom: 24),
            itemCount: items.length,
            itemBuilder: (c, i) {
              final x = items[i];
              if (x is String) return Padding(padding: const EdgeInsets.fromLTRB(18, 12, 18, 4), child: Text(x, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)));
              return dueCard(c, x as Doc);
            });
      });
}

// ───────── কাস্টমার যোগ / এডিট ─────────
void customerForm(BuildContext c, {String? editId, Map<String, dynamic>? data}) {
  final m = data ?? <String, dynamic>{};
  final n = TextEditingController(text: str(m, 'name'));
  final p = TextEditingController(text: str(m, 'phone'));
  final v = TextEditingController(text: str(m, 'village'));
  final nt = TextEditingController(text: str(m, 'note'));
  final o = TextEditingController();
  String? err;
  var warned = false;
  Widget f(TextEditingController t, String l, {TextInputType? kb, List<TextInputFormatter>? fmt}) =>
      Padding(padding: const EdgeInsets.only(bottom: 10), child: TextField(controller: t, keyboardType: kb, inputFormatters: fmt, decoration: deco(label: l)));
  showModalBottomSheet(
      context: c,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (ctx) => StatefulBuilder(
          builder: (ctx, setS) => Padding(
              padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 20),
              child: SingleChildScrollView(
                  child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(editId == null ? 'নতুন কাস্টমার' : 'কাস্টমার এডিট', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                const SizedBox(height: 14),
                f(n, 'নাম *'),
                f(p, 'মোবাইল (ঐচ্ছিক)', kb: TextInputType.phone),
                f(v, 'গ্রাম / ভাগ (ঐচ্ছিক)'),
                if (editId == null) f(o, 'পুরনো বাকি (ঐচ্ছিক)', kb: numKb, fmt: amtFmt),
                f(nt, 'নোট (ঐচ্ছিক)'),
                if (err != null) Padding(padding: const EdgeInsets.only(bottom: 10), child: Text(err!, style: const TextStyle(color: Colors.red))),
                SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: FilledButton(
                        onPressed: () {
                          final name = n.text.trim();
                          if (name.isEmpty) {
                            setS(() => err = 'নাম লিখুন');
                            return;
                          }
                          final dup = custDocs.value.any((d) => d.id != editId && str(d.data(), 'name').toLowerCase() == name.toLowerCase() && str(d.data(), 'village').toLowerCase() == v.text.trim().toLowerCase());
                          if (dup && !warned) {
                            warned = true;
                            setS(() => err = 'এই নাম ও গ্রামের কাস্টমার আগে থেকেই আছে। তবুও সংরক্ষণ করতে আবার চাপুন।');
                            return;
                          }
                          if (editId != null) {
                            fire(cust.doc(editId).update({'name': name, 'phone': p.text.trim(), 'village': v.text.trim(), 'note': nt.text.trim()}));
                          } else {
                            final r = cust.doc();
                            fire(r.set(newCust(name, p.text.trim(), v.text.trim(), nt.text.trim())));
                            final amt = parseAmt(o.text);
                            if (amt != null && amt > 0) addEntry(r.id, amt, 'পুরনো বাকি', name: name);
                          }
                          Navigator.pop(ctx);
                        },
                        child: const Text('সংরক্ষণ'))),
              ])))));
}

// ───────── লেনদেন এন্ট্রি ─────────
Future<void> entryDialog(BuildContext c, String id, bool baki, {num bal = 0, String name = ''}) async {
  final a = TextEditingController(), n = TextEditingController();
  String? err;
  final ok = await showDialog<bool>(
      context: c,
      builder: (x) => StatefulBuilder(
          builder: (x, setS) => AlertDialog(
                title: Text(baki ? 'বাকি দিলাম' : 'জমা নিলাম'),
                content: SingleChildScrollView(
                    child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                  TextField(controller: a, autofocus: true, keyboardType: numKb, inputFormatters: amtFmt, decoration: deco(label: 'টাকার পরিমাণ', err: err)),
                  if (!baki && bal > 0) Align(alignment: Alignment.centerLeft, child: TextButton(onPressed: () => a.text = plain(bal), child: Text('পুরো বাকি ${tk(bal)}'))),
                  const SizedBox(height: 8),
                  TextField(controller: n, decoration: deco(label: 'নোট (ঐচ্ছিক)')),
                ])),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(x, false), child: const Text('বাতিল')),
                  FilledButton(
                      onPressed: () {
                        final v = parseAmt(a.text);
                        if (v == null || v <= 0) {
                          setS(() => err = 'সঠিক টাকার পরিমাণ লিখুন');
                          return;
                        }
                        Navigator.pop(x, true);
                      },
                      child: const Text('সংরক্ষণ')),
                ],
              )));
  final v = parseAmt(a.text);
  if (ok == true && v != null && v > 0) addEntry(id, baki ? v : -v, n.text.trim(), name: name);
}

// ───────── কাস্টমারের বিস্তারিত ─────────
class Detail extends StatefulWidget {
  final String id;
  const Detail(this.id, {super.key});
  @override
  State<Detail> createState() => _DetailState();
}

class _DetailState extends State<Detail> {
  String get id => widget.id;
  late final Stream<DocumentSnapshot<Map<String, dynamic>>> st = cust.doc(widget.id).snapshots();
  late final Stream<QuerySnapshot<Map<String, dynamic>>> es = cust.doc(widget.id).collection('entries').orderBy('date', descending: true).limit(300).snapshots();

  Future<void> setDue(DateTime? cur) async {
    final now = DateTime.now();
    final init = (cur != null && cur.isAfter(now)) ? cur : now;
    final d = await showDatePicker(context: context, firstDate: DateTime(now.year, now.month, now.day), lastDate: now.add(const Duration(days: 730)), initialDate: init);
    if (d == null || !mounted) return;
    final t = await showTimePicker(context: context, initialTime: TimeOfDay(hour: cur?.hour ?? 17, minute: cur?.minute ?? 0));
    if (t == null || !mounted) return;
    final due = DateTime(d.year, d.month, d.day, t.hour, t.minute);
    if (due.isBefore(DateTime.now())) {
      toast(context, 'এই সময় পার হয়ে গেছে, ভবিষ্যতের সময় দিন');
      return;
    }
    cust.doc(id).update({'due': Timestamp.fromDate(due)});
  }

  Future<void> del(String name) async {
    final ok = await showDialog<bool>(
        context: context,
        builder: (x) => AlertDialog(
                title: const Text('কাস্টমার মুছবেন?'),
                content: Text('$name এবং তার সব হিসাব মুছে যাবে। এটা আর ফেরানো যাবে না।'),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(x, false), child: const Text('না')),
                  FilledButton(style: FilledButton.styleFrom(backgroundColor: Colors.red), onPressed: () => Navigator.pop(x, true), child: const Text('হ্যাঁ, মুছুন')),
                ]));
    if (ok == true && mounted) {
      final nav = Navigator.of(context);
      unawaited(deleteCustomer(id));
      nav.pop();
    }
  }

  Future<void> delEntry(DocumentSnapshot<Map<String, dynamic>> e) async {
    final ok = await showDialog<bool>(
        context: context,
        builder: (x) => AlertDialog(
                title: const Text('এই লেনদেন মুছবেন?'),
                content: const Text('মুছলে বাকির হিসাব আগের অবস্থায় ফিরে যাবে।'),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(x, false), child: const Text('না')),
                  FilledButton(onPressed: () => Navigator.pop(x, true), child: const Text('মুছুন')),
                ]));
    if (ok == true) deleteEntry(id, e);
  }

  Widget info(IconData i, String t) => Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(i, size: 18, color: Colors.black54),
        const SizedBox(width: 8),
        Expanded(child: Text(t)),
      ]));

  @override
  Widget build(BuildContext c) => StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: st,
      builder: (c, s) {
        if (s.hasError) return Scaffold(appBar: AppBar(), body: const Center(child: Text('লোড করা যায়নি')));
        final m = s.data?.data();
        if (m == null) {
          return Scaffold(appBar: AppBar(), body: Center(child: s.connectionState == ConnectionState.waiting ? const CircularProgressIndicator() : const Text('কাস্টমার পাওয়া যায়নি')));
        }
        final name = str(m, 'name');
        final bal = numOf(m, 'balance');
        final due = dtOf(m, 'due');
        final phone = str(m, 'phone');
        final village = str(m, 'village');
        final note = str(m, 'note');
        final ph = phoneRaw(phone);
        final msg = dueMsg(m);
        return Scaffold(
          appBar: AppBar(title: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis), actions: [
            IconButton(icon: const Icon(Icons.edit_outlined), tooltip: 'এডিট', onPressed: () => customerForm(context, editId: id, data: m)),
            IconButton(icon: const Icon(Icons.delete_outline), tooltip: 'মুছুন', onPressed: () => del(name)),
          ]),
          body: ListView(padding: const EdgeInsets.only(bottom: 30), children: [
            card(Padding(
                padding: const EdgeInsets.all(18),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(bal < 0 ? 'অগ্রিম জমা আছে' : 'বর্তমান বাকি', style: TextStyle(color: Colors.grey.shade600)),
                  FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(tk(bal.abs()), style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800, color: bal > 0 ? Colors.deepOrange : Colors.green))),
                  const SizedBox(height: 6),
                  if (village.isNotEmpty) info(Icons.place_outlined, village),
                  if (phone.isNotEmpty) info(Icons.phone_outlined, phone),
                  if (note.isNotEmpty) info(Icons.notes, note),
                  Padding(
                        padding: const EdgeInsets.only(top: 6),
                        child: Wrap(spacing: 8, runSpacing: 4, children: [
                          OutlinedButton.icon(onPressed: () => openStatement(context, id, m), icon: const Icon(Icons.picture_as_pdf, size: 18), label: const Text('বিবরণী PDF')),
                          if (mobile && phone.isNotEmpty) OutlinedButton.icon(onPressed: () => openUrl(context, 'tel:$ph'), icon: const Icon(Icons.call, size: 18), label: const Text('কল')),
                          if (mobile && phone.isNotEmpty) OutlinedButton.icon(onPressed: () => openUrl(context, smsUrl(ph, msg)), icon: const Icon(Icons.sms, size: 18), label: const Text('SMS')),
                          if (phoneIntl(ph).isNotEmpty) OutlinedButton.icon(onPressed: () => openUrl(context, waUrl(ph, msg)), icon: const Icon(Icons.chat, size: 18), label: const Text('WhatsApp')),
                        ])),
                  const Divider(height: 24),
                  Text(due == null ? 'তাগাদার সময় সেট নেই' : '⏰ ${dt(due)}', style: const TextStyle(fontWeight: FontWeight.w600)),
                  Wrap(spacing: 8, children: [
                    TextButton.icon(onPressed: () => setDue(due), icon: const Icon(Icons.alarm_add), label: Text(due == null ? 'তাগাদা সেট' : 'সময় বদলান')),
                    if (due != null) TextButton.icon(onPressed: () => cust.doc(id).update({'due': null}), icon: const Icon(Icons.close), label: const Text('তাগাদা মুছুন')),
                  ]),
                ]))),
            Padding(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                child: Row(children: [
                  Expanded(child: FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: Colors.deepOrange, minimumSize: const Size(0, 50)), onPressed: () => entryDialog(context, id, true, bal: bal, name: name), icon: const Icon(Icons.add), label: const Text('বাকি দিলাম'))),
                  const SizedBox(width: 10),
                  Expanded(child: FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: Colors.green, minimumSize: const Size(0, 50)), onPressed: () => entryDialog(context, id, false, bal: bal, name: name), icon: const Icon(Icons.remove), label: const Text('জমা নিলাম'))),
                ])),
            const Padding(padding: EdgeInsets.fromLTRB(18, 14, 18, 4), child: Text('লেনদেনের ইতিহাস', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
            StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                stream: es,
                builder: (c, e) {
                  final docs = e.data?.docs ?? <QueryDocumentSnapshot<Map<String, dynamic>>>[];
                  if (e.connectionState == ConnectionState.waiting && docs.isEmpty) return const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator()));
                  if (docs.isEmpty) return const Padding(padding: EdgeInsets.all(24), child: Center(child: Text('এখনো কোনো লেনদেন নেই', style: TextStyle(color: Colors.black54))));
                  num given = 0, got = 0;
                  for (final x in docs) {
                    final a = numOf(x.data(), 'amount');
                    if (a > 0) {
                      given += a;
                    } else {
                      got += -a;
                    }
                  }
                  return Column(children: [
                    Padding(padding: const EdgeInsets.fromLTRB(18, 0, 18, 6), child: Align(alignment: Alignment.centerLeft, child: Text('মোট বাকি দিয়েছি ${tk(given)} • মোট জমা নিয়েছি ${tk(got)}', style: const TextStyle(color: Colors.black54, fontSize: 13)))),
                    for (final x in docs) entryTile(x),
                  ]);
                }),
          ]),
        );
      });

  Widget entryTile(QueryDocumentSnapshot<Map<String, dynamic>> x) {
    final m = x.data();
    final a = numOf(m, 'amount');
    final d = dtOf(m, 'date');
    final nt = str(m, 'note');
    return card(ListTile(
      leading: Icon(a > 0 ? Icons.north_east : Icons.south_west, color: a > 0 ? Colors.deepOrange : Colors.green),
      title: Text('${a > 0 ? 'বাকি' : 'জমা'}  ${tk(a.abs())}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Text([if (d != null) dt(d), if (nt.isNotEmpty) nt].join('\n'), maxLines: 3, overflow: TextOverflow.ellipsis),
      trailing: IconButton(icon: const Icon(Icons.delete_outline, size: 20), tooltip: 'মুছুন', onPressed: () => delEntry(x)),
    ));
  }
}

// ───────── In-app updater (GitHub Releases) ─────────
bool newer(String a, String b) {
  final x = a.split('.').map((e) => int.tryParse(e) ?? 0).toList(), y = b.split('.').map((e) => int.tryParse(e) ?? 0).toList();
  for (var i = 0; i < 3; i++) {
    final p = i < x.length ? x[i] : 0, q = i < y.length ? y[i] : 0;
    if (p != q) return p > q;
  }
  return false;
}

Future<void> checkUpdate(BuildContext c, {bool silent = false}) async {
  void snack(String s) {
    if (!silent && c.mounted) toast(c, s);
  }

  if (kIsWeb) {
    snack('ওয়েব ভার্সন নিজে আপডেট হয় — নতুন ভার্সনের জন্য পেজ রিফ্রেশ (Ctrl+F5) করুন');
    return;
  }
  if (isIOS) {
    snack('iPhone এ আপডেট নিজে ইনস্টল করতে হবে');
    return;
  }
  var dialogOpen = false;
  final client = http.Client();
  try {
    final r = await client.get(Uri.parse('https://api.github.com/repos/$kRepo/releases/latest')).timeout(const Duration(seconds: 15));
    if (r.statusCode != 200) {
      snack('আপডেটের তথ্য পাওয়া যায়নি');
      return;
    }
    final j = jsonDecode(r.body);
    final tag = '${j['tag_name']}'.replaceFirst('v', '');
    final cur = (await PackageInfo.fromPlatform()).version;
    if (!newer(tag, cur)) {
      snack('আপনার অ্যাপ আপ-টু-ডেট ($cur)');
      return;
    }
    final assets = ((j['assets'] as List?) ?? []).cast<Map>();
    final asset = assets.firstWhere((a) {
      final n = '${a['name']}'.toLowerCase();
      return isAndroid ? n.endsWith('.apk') : (n.endsWith('.zip') && n.contains('windows'));
    }, orElse: () => {});
    if (asset.isEmpty) {
      snack('নতুন ভার্সন তৈরি হচ্ছে, একটু পরে চেষ্টা করুন');
      return;
    }
    if (!c.mounted) return;
    final ok = await showDialog<bool>(
        context: c,
        builder: (x) => AlertDialog(title: Text('নতুন আপডেট $tag'), content: const Text('আপডেট ডাউনলোড করে ইনস্টল করবেন?'), actions: [
              TextButton(onPressed: () => Navigator.pop(x, false), child: const Text('পরে')),
              FilledButton(onPressed: () => Navigator.pop(x, true), child: const Text('আপডেট করুন')),
            ]));
    if (ok != true || !c.mounted) return;
    final prog = ValueNotifier<double>(0);
    dialogOpen = true;
    showDialog(
        context: c,
        barrierDismissible: false,
        builder: (_) => AlertDialog(
            title: const Text('ডাউনলোড হচ্ছে...'),
            content: ValueListenableBuilder<double>(valueListenable: prog, builder: (_, v, __) => LinearProgressIndicator(value: v > 0 ? v : null))));
    final res = await client.send(http.Request('GET', Uri.parse('${asset['browser_download_url']}')));
    final f = File('${(await getTemporaryDirectory()).path}/${asset['name']}');
    final sink = f.openWrite();
    var got = 0;
    final total = res.contentLength ?? 0;
    await for (final ch in res.stream) {
      sink.add(ch);
      got += ch.length;
      if (total > 0) prog.value = got / total;
    }
    await sink.close();
    if (dialogOpen && c.mounted) Navigator.of(c).pop();
    dialogOpen = false;
    if (isAndroid) await Permission.requestInstallPackages.request();
    await openLocalFile(f.path);
  } catch (_) {
    if (dialogOpen && c.mounted) {
      Navigator.of(c).pop();
      dialogOpen = false;
    }
    snack('আপডেট চেক করা যায়নি (ইন্টারনেট দেখুন)');
  } finally {
    client.close();
  }
}

// ───────── Daily tasks ─────────
class TasksPage extends StatefulWidget {
  const TasksPage({super.key});
  @override
  State<TasksPage> createState() => _TPState();
}

class _TPState extends State<TasksPage> {
  final t = TextEditingController();
  late final Stream<QuerySnapshot<Map<String, dynamic>>> st = tasks.orderBy('createdAt', descending: true).snapshots();
  @override
  void dispose() {
    t.dispose();
    super.dispose();
  }

  void add([String? s]) {
    final v = (s ?? t.text).trim();
    if (v.isEmpty) return;
    fire(tasks.add({'title': v, 'done': false, 'createdAt': Timestamp.now()}).then((_) {}));
    t.clear();
  }

  @override
  Widget build(BuildContext c) => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: st,
      builder: (c, s) {
        final l = [...?s.data?.docs]..sort((a, b) {
            final x = a.data()['done'] == true, y = b.data()['done'] == true;
            return x == y ? 0 : (x ? 1 : -1);
          });
        return ListView(padding: const EdgeInsets.only(bottom: 24), children: [
          Padding(
              padding: const EdgeInsets.fromLTRB(14, 14, 14, 6),
              child: TextField(controller: t, onSubmitted: (_) => add(), decoration: deco(hint: 'আজকের কাজ লিখুন...', filled: true, suffix: IconButton(icon: const Icon(Icons.add_circle), onPressed: () => add())))),
          SizedBox(
              height: 46,
              child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12), children: [
                for (final x in ['তাগাদা করা', 'মাল অর্ডার', 'দোকানের বিল', 'ব্যাংকে জমা', 'ফটোকপি/প্রিন্টের হিসাব'])
                  Padding(padding: const EdgeInsets.only(right: 8), child: ActionChip(label: Text(x), onPressed: () => add(x)))
              ])),
          if (l.isEmpty) const Padding(padding: EdgeInsets.all(40), child: Center(child: Text('কোনো কাজ নেই', style: TextStyle(color: Colors.black54)))),
          for (final d in l)
            Dismissible(
                key: ValueKey(d.id),
                onDismissed: (_) {
                  final data = d.data();
                  d.reference.delete();
                  final m = ScaffoldMessenger.of(c);
                  m.hideCurrentSnackBar();
                  m.showSnackBar(SnackBar(content: const Text('কাজ মুছে গেছে'), action: SnackBarAction(label: 'ফিরিয়ে আনুন', onPressed: () => d.reference.set(data))));
                },
                background: Container(color: Colors.red.shade100, alignment: Alignment.centerLeft, padding: const EdgeInsets.only(left: 20), child: const Icon(Icons.delete_outline)),
                secondaryBackground: Container(color: Colors.red.shade100, alignment: Alignment.centerRight, padding: const EdgeInsets.only(right: 20), child: const Icon(Icons.delete_outline)),
                child: card(CheckboxListTile(
                    value: d.data()['done'] == true,
                    onChanged: (v) => d.reference.update({'done': v ?? false}),
                    title: Text(str(d.data(), 'title'), style: TextStyle(decoration: d.data()['done'] == true ? TextDecoration.lineThrough : null))))),
        ]);
      });
}

// ───────── Windows ছোট উইজেট ─────────
class MiniPage extends StatefulWidget {
  const MiniPage({super.key});
  @override
  State<MiniPage> createState() => _MPState();
}

class _MPState extends State<MiniPage> {
  @override
  void initState() {
    super.initState();
    deskSize(340, 520);
    deskOnTop(true);
  }

  @override
  void dispose() {
    deskOnTop(false);
    deskSize(1100, 760);
    super.dispose();
  }

  @override
  Widget build(BuildContext c) => Scaffold(
      appBar: AppBar(title: const Text('বাকি উইজেট'), toolbarHeight: 46),
      body: withCust((c, docs) {
        final l = docs.where((d) => numOf(d.data(), 'balance') > 0).toList()..sort((a, b) => numOf(b.data(), 'balance').compareTo(numOf(a.data(), 'balance')));
        final total = l.fold<num>(0, (a, d) => a + numOf(d.data(), 'balance'));
        return Column(children: [
          Container(
              width: double.infinity,
              margin: const EdgeInsets.all(10),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), gradient: LinearGradient(colors: [Theme.of(c).colorScheme.primary, Theme.of(c).colorScheme.tertiary])),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('মোট বাকি', style: TextStyle(color: Colors.white70)),
                FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(tk(total), style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w800))),
                Text('${l.length} জন', style: const TextStyle(color: Colors.white70)),
              ])),
          Expanded(
              child: ListView.builder(
                  itemCount: l.length,
                  itemBuilder: (c, i) {
                    final m = l[i].data();
                    final due = dtOf(m, 'due');
                    return ListTile(
                        dense: true,
                        onTap: () => openDetail(c, l[i].id),
                        title: Text(str(m, 'name'), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
                        subtitle: due == null ? null : Text('⏰ ${dt(due)}', maxLines: 1, overflow: TextOverflow.ellipsis),
                        trailing: Text(tk(numOf(m, 'balance')), style: const TextStyle(fontWeight: FontWeight.w800, color: Colors.deepOrange)));
                  })),
        ]);
      }));
}
