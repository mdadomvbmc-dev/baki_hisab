import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui' as ui;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:home_widget/home_widget.dart';
import 'package:http/http.dart' as http;
import 'package:intl/date_symbol_data_local.dart';
import 'package:intl/intl.dart';
import 'package:open_filex/open_filex.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:permission_handler/permission_handler.dart';
import 'package:printing/printing.dart';
import 'package:timezone/data/latest.dart' as tzd;
import 'package:timezone/timezone.dart' as tz;
import 'package:window_manager/window_manager.dart';

const kRepo = 'OWNER/REPO'; // GitHub Action নিজে বসিয়ে দেয়
const fbOptions = FirebaseOptions(
  apiKey: 'AIzaSyDCYJ5_WxhGXebRjOqfFu9oG6EWgMQuo38',
  authDomain: 'baki-hisab-a32ba.firebaseapp.com',
  projectId: 'baki-hisab-a32ba',
  storageBucket: 'baki-hisab-a32ba.firebasestorage.app',
  messagingSenderId: '548966518518',
  appId: '1:548966518518:web:8b96d240aeba2f4ad226d7',
);

final seed = ValueNotifier<int>(0xFF2E7D32);
final shop = ValueNotifier<String>('সবুজ কম্পিউটার বুক ক্যাম্পাস');
final notif = FlutterLocalNotificationsPlugin();
bool get mobile => Platform.isAndroid || Platform.isIOS;
final db = FirebaseFirestore.instance;
String get uid => FirebaseAuth.instance.currentUser!.uid;
DocumentReference<Map<String, dynamic>> get me => db.collection('users').doc(uid);
CollectionReference<Map<String, dynamic>> get cust => me.collection('customers');
CollectionReference<Map<String, dynamic>> get tasks => me.collection('tasks');
List<QueryDocumentSnapshot<Map<String, dynamic>>> latest = [];

String tk(num n) => '৳ ${NumberFormat('#,##0.##', 'bn').format(n)}';
String dt(DateTime d) => DateFormat('d MMM yyyy, h:mm a', 'bn').format(d);
String toEn(String s) {
  const b = '০১২৩৪৫৬৭৮৯';
  return s.split('').map((x) { final i = b.indexOf(x); return i < 0 ? x : '$i'; }).join();
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('bn');
  await Firebase.initializeApp(options: fbOptions);
  if (Platform.isWindows) { await windowManager.ensureInitialized(); await windowManager.setTitle('বাকি হিসাব'); }
  if (mobile) {
    tzd.initializeTimeZones();
    tz.setLocalLocation(tz.getLocation(await FlutterTimezone.getLocalTimezone()));
    await notif.initialize(const InitializationSettings(
        android: AndroidInitializationSettings('@mipmap/ic_launcher'), iOS: DarwinInitializationSettings()));
  }
  runApp(const App());
}

Future<void> reschedule(List<QueryDocumentSnapshot<Map<String, dynamic>>> docs) async {
  if (!mobile) return;
  await notif.cancelAll();
  var i = 1;
  for (final d in docs) {
    final m = d.data();
    final due = (m['due'] as Timestamp?)?.toDate();
    if (due == null || ((m['balance'] ?? 0) as num) <= 0 || due.isBefore(DateTime.now())) continue;
    try { await notif.zonedSchedule(i++, '💰 তাগাদা: ${m['name']}', '${tk(m['balance'])} আদায় করতে হবে',
        tz.TZDateTime.from(due, tz.local),
        const NotificationDetails(
            android: AndroidNotificationDetails('due', 'বাকি তাগাদা অ্যালার্ম',
                importance: Importance.max, priority: Priority.high, fullScreenIntent: true,
                category: AndroidNotificationCategory.alarm, audioAttributesUsage: AudioAttributesUsage.alarm)),
        androidScheduleMode: AndroidScheduleMode.alarmClock,
        uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime); } catch (_) {}
  }
}

// প্রথমবার অনুমতি চাওয়া (Android)
Future<void> askPermissions(BuildContext c, {bool force = false}) async {
  if (!Platform.isAndroid) return;
  final f = File('${(await getApplicationSupportDirectory()).path}/perm_done');
  if (!force && await f.exists()) return;
  if (!c.mounted) return;
  await showDialog(context: c, barrierDismissible: false, builder: (_) => AlertDialog(
      title: const Text('কিছু অনুমতি দরকার'),
      content: const Text('তাগাদার অ্যালার্ম ঠিক সময়ে বাজাতে এই অনুমতিগুলো লাগবে:\n\n🔔 নোটিফিকেশন\n⏰ সঠিক সময়ের অ্যালার্ম\n🔋 ব্যাটারি সেভার থেকে ছাড়\n📲 অ্যাপ থেকে আপডেট ইনস্টল\n\nপরের ধাপগুলোতে "Allow / অনুমতি দিন" চাপুন।'),
      actions: [FilledButton(onPressed: () => Navigator.pop(c), child: const Text('ঠিক আছে, শুরু করুন'))]));
  await Permission.notification.request();
  await Permission.scheduleExactAlarm.request();
  await Permission.ignoreBatteryOptimizations.request();
  await Permission.requestInstallPackages.request();
  await f.writeAsString('1');
}

// হোম স্ক্রিন উইজেটের ডাটা আপডেট
Future<void> pushWidget(List<QueryDocumentSnapshot<Map<String, dynamic>>> docs) async {
  if (!Platform.isAndroid) return;
  try {
    final l = docs.where((d) => ((d['balance'] ?? 0) as num) > 0).toList();
    final total = l.fold<num>(0, (a, d) => a + (d['balance'] as num));
    final due = l.where((d) => d['due'] != null).toList()..sort((a, b) => (a['due'] as Timestamp).compareTo(b['due'] as Timestamp));
    final lines = due.take(3).map((d) => '⏰ ${d['name']} • ${tk(d['balance'])}').join('\n');
    await HomeWidget.saveWidgetData<String>('total', tk(total));
    await HomeWidget.saveWidgetData<String>('count', '${l.length} জন বাকি');
    await HomeWidget.saveWidgetData<String>('list', lines.isEmpty ? 'কোনো তাগাদা সেট নেই' : lines);
    await HomeWidget.updateWidget(name: 'BakiWidget', androidName: 'BakiWidget');
  } catch (_) {}
}

// দ্রুত পুরনো বাকি: প্রতি লাইনে "নাম, গ্রাম, টাকা"
Future<int> quickAdd(String text) async {
  final snap = await cust.get();
  final byName = <String, String>{for (final d in snap.docs) '${d['name']}'.trim(): d.id};
  var n = 0;
  for (final line in text.split('\n')) {
    final p = toEn(line).split(',').map((e) => e.trim()).toList();
    if (p.length < 2 || p.first.isEmpty) continue;
    final amt = num.tryParse(p.last.replaceAll(RegExp(r'[^0-9.]'), ''));
    if (amt == null || amt <= 0) continue;
    var id = byName[p.first];
    if (id == null) {
      final r = cust.doc();
      r.set({'name': p.first, 'phone': '', 'village': p.length > 2 ? p[1] : '', 'note': '', 'balance': 0, 'due': null, 'createdAt': Timestamp.now()});
      id = r.id;
      byName[p.first] = id;
    }
    addEntry(id, amt, 'পুরনো বাকি');
    n++;
  }
  return n;
}

void quickEntry(BuildContext c) {
  final t = TextEditingController();
  showModalBottomSheet(context: c, isScrollControlled: true, builder: (_) => Padding(
      padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(c).viewInsets.bottom + 20),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('⚡ দ্রুত পুরনো বাকি লিখুন', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
        const SizedBox(height: 6),
        const Text('প্রতি লাইনে একজন:  নাম, গ্রাম, টাকা\nযেমন:  রহিম, কুমিল্লা, ৫০০\nগ্রাম না থাকলে:  করিম, ২০০\nএকই নাম থাকলে তার সাথে যোগ হবে।', style: TextStyle(color: Colors.black54)),
        const SizedBox(height: 12),
        TextField(controller: t, maxLines: 8, autofocus: true, decoration: const InputDecoration(hintText: 'রহিম, কুমিল্লা, ৫০০\nকরিম, ২০০')),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, height: 50, child: FilledButton(onPressed: () async {
          final n = await quickAdd(t.text);
          if (c.mounted) { Navigator.pop(c); ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text('$n টি বাকি যোগ হয়েছে'))); }
        }, child: const Text('যোগ করুন'))),
      ])));
}

void addEntry(String id, num amt, String note) {
  final r = cust.doc(id);
  r.collection('entries').add({'amount': amt, 'note': note, 'date': Timestamp.now()});
  r.update({'balance': FieldValue.increment(amt)});
}

// ───────── App & Splash ─────────
class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext c) => ValueListenableBuilder<int>(
      valueListenable: seed,
      builder: (_, s, __) => MaterialApp(
          title: 'বাকি হিসাব',
          debugShowCheckedModeBanner: false,
          theme: ThemeData(
              useMaterial3: true,
              colorSchemeSeed: Color(s),
              scaffoldBackgroundColor: const Color(0xFFF4F7F4),
              cardTheme: CardTheme(elevation: 0, color: Colors.white, margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
              inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(14))))),
          home: const Splash()));
}

class Splash extends StatefulWidget {
  const Splash({super.key});
  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> with SingleTickerProviderStateMixin {
  late final ac = AnimationController(vsync: this, duration: const Duration(milliseconds: 2400))..forward();
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 3000), () {
      if (mounted) {
        Navigator.pushReplacement(context, PageRouteBuilder(
            transitionDuration: const Duration(milliseconds: 600),
            pageBuilder: (_, __, ___) => const Gate(),
            transitionsBuilder: (_, a, __, w) => FadeTransition(opacity: a, child: w)));
      }
    });
  }
  @override
  void dispose() { ac.dispose(); super.dispose(); }
  Animation<double> iv(double a, double b, [Curve k = Curves.easeOut]) => CurvedAnimation(parent: ac, curve: Interval(a, b, curve: k));
  @override
  Widget build(BuildContext c) => Scaffold(
      backgroundColor: Colors.white,
      body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        ScaleTransition(scale: iv(0, .6, Curves.elasticOut),
            child: FadeTransition(opacity: iv(0, .3), child: Image.asset('assets/logo.png', width: 170))),
        const SizedBox(height: 28),
        FadeTransition(opacity: iv(.5, .85),
            child: SlideTransition(position: Tween<Offset>(begin: const Offset(0, .5), end: Offset.zero).animate(iv(.5, .85)),
                child: const Column(children: [
                  Text('বাকি হিসাব', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800, color: Color(0xFF2E7D32))),
                  SizedBox(height: 4),
                  Text('সবুজ কম্পিউটার বুক ক্যাম্পাস', style: TextStyle(fontSize: 15, color: Colors.black54)),
                ]))),
        const SizedBox(height: 36),
        SizedBox(width: 140, child: AnimatedBuilder(animation: ac,
            builder: (_, __) => LinearProgressIndicator(value: ac.value, minHeight: 5, borderRadius: BorderRadius.circular(9), color: const Color(0xFF2E7D32)))),
      ])));
}

class Gate extends StatelessWidget {
  const Gate({super.key});
  @override
  Widget build(BuildContext c) => StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (c, s) {
        if (s.connectionState == ConnectionState.waiting) return const Scaffold(body: Center(child: CircularProgressIndicator()));
        return s.data == null ? const Login() : const Home();
      });
}

class Login extends StatefulWidget {
  const Login({super.key});
  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final e = TextEditingController(), p = TextEditingController();
  bool busy = false;
  String? err;
  Future<void> go(bool signup) async {
    setState(() { busy = true; err = null; });
    try {
      final a = FirebaseAuth.instance;
      signup ? await a.createUserWithEmailAndPassword(email: e.text.trim(), password: p.text)
             : await a.signInWithEmailAndPassword(email: e.text.trim(), password: p.text);
    } on FirebaseAuthException catch (x) { err = x.message; }
    if (mounted) setState(() => busy = false);
  }
  @override
  Widget build(BuildContext c) => Scaffold(
      body: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 400),
          child: Column(children: [
            Image.asset('assets/logo.png', width: 110),
            const SizedBox(height: 14),
            const Text('বাকি হিসাব', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
            const SizedBox(height: 22),
            TextField(controller: e, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'ইমেইল', prefixIcon: Icon(Icons.mail_outline))),
            const SizedBox(height: 12),
            TextField(controller: p, obscureText: true, decoration: const InputDecoration(labelText: 'পাসওয়ার্ড', prefixIcon: Icon(Icons.lock_outline))),
            if (err != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(err!, style: const TextStyle(color: Colors.red))),
            const SizedBox(height: 18),
            SizedBox(width: double.infinity, height: 50, child: FilledButton(onPressed: busy ? null : () => go(false), child: const Text('লগইন'))),
            TextButton(onPressed: busy ? null : () => go(true), child: const Text('নতুন একাউন্ট খুলুন (প্রথমবার)')),
          ])))));
}

// ───────── Home ─────────
class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int tab = 0;
  StreamSubscription? s1, s2;
  Timer? tm;
  final shown = <String>{};
  @override
  void initState() {
    super.initState();
    s1 = me.collection('meta').doc('settings').snapshots().listen((d) {
      final m = d.data();
      if (m == null) return;
      shop.value = m['shop'] ?? shop.value;
      seed.value = m['seed'] ?? seed.value;
    });
    s2 = cust.snapshots().listen((q) { latest = q.docs; reschedule(q.docs); pushWidget(q.docs); });
    if (Platform.isWindows) tm = Timer.periodic(const Duration(seconds: 20), (_) => desktopAlarm());
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await askPermissions(context);
      reschedule(latest);
      if (mounted) checkUpdate(context, silent: true);
    });
  }
  @override
  void dispose() { s1?.cancel(); s2?.cancel(); tm?.cancel(); super.dispose(); }
  // Windows: অ্যাপ খোলা থাকলে সময় হলে পপআপ + বিপ
  Future<void> desktopAlarm() async {
    final now = DateTime.now();
    for (final d in latest) {
      final due = (d['due'] as Timestamp?)?.toDate();
      if (due == null || ((d['balance'] ?? 0) as num) <= 0 || due.isAfter(now) || now.difference(due).inHours > 12) continue;
      if (!shown.add('${d.id}${due.millisecondsSinceEpoch}')) continue;
      Process.run('powershell', ['-NoProfile', '-c', '1..3|%{[console]::beep(1200,400)}']);
      windowManager.show();
      windowManager.focus();
      if (!mounted) return;
      await showDialog(context: context, builder: (x) => AlertDialog(
          title: const Text('⏰ তাগাদার সময় হয়েছে!'),
          content: Text('${d['name']}\n${d['village'] ?? ''} ${d['phone'] ?? ''}\nবাকি: ${tk(d['balance'])}', style: const TextStyle(fontSize: 18)),
          actions: [TextButton(onPressed: () => Navigator.pop(x), child: const Text('পরে')),
            FilledButton(onPressed: () { Navigator.pop(x); Navigator.push(context, MaterialPageRoute(builder: (_) => Detail(d.id))); }, child: const Text('খুলুন'))]));
    }
  }
  @override
  Widget build(BuildContext c) {
    const pages = [CustomerList(), DuePage(), TasksPage(), ReportPage()];
    return Scaffold(
      appBar: AppBar(
          title: ValueListenableBuilder<String>(valueListenable: shop, builder: (_, s, __) => Text(s, style: const TextStyle(fontWeight: FontWeight.w700))),
          actions: [IconButton(icon: const Icon(Icons.bolt), tooltip: 'দ্রুত পুরনো বাকি লিখুন', onPressed: () => quickEntry(c)),
            if (Platform.isWindows) IconButton(icon: const Icon(Icons.picture_in_picture_alt), tooltip: 'ছোট উইজেট', onPressed: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const MiniPage()))),
            IconButton(icon: const Icon(Icons.system_update_alt), tooltip: 'আপডেট', onPressed: () => checkUpdate(c)),
            IconButton(icon: const Icon(Icons.settings), onPressed: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const SettingsPage())))]),
      body: pages[tab],
      floatingActionButton: tab == 0 ? FloatingActionButton.extended(onPressed: () => addCustomer(c), icon: const Icon(Icons.person_add), label: const Text('নতুন কাস্টমার')) : null,
      bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (i) => setState(() => tab = i), destinations: const [
        NavigationDestination(icon: Icon(Icons.people_alt_outlined), selectedIcon: Icon(Icons.people_alt), label: 'বাকি তালিকা'),
        NavigationDestination(icon: Icon(Icons.alarm_outlined), selectedIcon: Icon(Icons.alarm), label: 'তাগাদা'),
        NavigationDestination(icon: Icon(Icons.checklist_outlined), selectedIcon: Icon(Icons.checklist), label: 'দৈনিক কাজ'),
        NavigationDestination(icon: Icon(Icons.picture_as_pdf_outlined), selectedIcon: Icon(Icons.picture_as_pdf), label: 'রিপোর্ট'),
      ]),
    );
  }
}

Widget tile(BuildContext c, QueryDocumentSnapshot<Map<String, dynamic>> d) {
  final m = d.data();
  final bal = (m['balance'] ?? 0) as num;
  final due = (m['due'] as Timestamp?)?.toDate();
  final late = due != null && bal > 0 && due.isBefore(DateTime.now());
  final sub = [m['village'], m['phone']].where((x) => x != null && '$x'.isNotEmpty).join(' • ');
  return Card(child: ListTile(
    onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => Detail(d.id))),
    leading: CircleAvatar(backgroundColor: Theme.of(c).colorScheme.primaryContainer, child: Text('${m['name']}'.characters.first, style: const TextStyle(fontWeight: FontWeight.bold))),
    title: Text(m['name'], style: const TextStyle(fontWeight: FontWeight.w700)),
    subtitle: Text([if (sub.isNotEmpty) sub, if (due != null && bal > 0) '⏰ ${dt(due)}'].join('\n')),
    trailing: Text(tk(bal), style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: late ? Colors.red : bal > 0 ? Colors.deepOrange : Colors.green)),
  ));
}

class CustomerList extends StatefulWidget {
  const CustomerList({super.key});
  @override
  State<CustomerList> createState() => _CLState();
}

class _CLState extends State<CustomerList> {
  String q = '';
  @override
  Widget build(BuildContext c) => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: cust.orderBy('name').snapshots(),
      builder: (c, s) {
        final all = s.data?.docs ?? [];
        final list = all.where((d) => '${d['name']} ${d['village']} ${d['phone']}'.toLowerCase().contains(q.toLowerCase())).toList();
        final total = all.fold<num>(0, (a, d) => a + ((d['balance'] ?? 0) as num));
        return Column(children: [
          Container(margin: const EdgeInsets.all(14), padding: const EdgeInsets.all(20), width: double.infinity,
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), gradient: LinearGradient(colors: [Theme.of(c).colorScheme.primary, Theme.of(c).colorScheme.tertiary])),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('মোট বাকি', style: TextStyle(color: Colors.white70)),
                Text(tk(total), style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w800)),
                Text('${all.where((d) => ((d['balance'] ?? 0) as num) > 0).length} জন বাকি আছে', style: const TextStyle(color: Colors.white70)),
              ])),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 14), child: TextField(onChanged: (v) => setState(() => q = v),
              decoration: const InputDecoration(hintText: 'নাম / গ্রাম / মোবাইল দিয়ে খুঁজুন', prefixIcon: Icon(Icons.search), filled: true, fillColor: Colors.white))),
          const SizedBox(height: 8),
          Expanded(child: list.isEmpty ? const Center(child: Text('কোনো কাস্টমার নেই')) : ListView(padding: const EdgeInsets.only(bottom: 90), children: [for (final d in list) tile(c, d)])),
        ]);
      });
}

class DuePage extends StatelessWidget {
  const DuePage({super.key});
  @override
  Widget build(BuildContext c) => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: cust.snapshots(),
      builder: (c, s) {
        final l = (s.data?.docs ?? []).where((d) => d['due'] != null && ((d['balance'] ?? 0) as num) > 0).toList()
          ..sort((a, b) => (a['due'] as Timestamp).compareTo(b['due'] as Timestamp));
        if (l.isEmpty) return const Center(child: Text('কোনো তাগাদা সেট করা নেই\nকাস্টমার খুলে "তাগাদা সেট" করুন', textAlign: TextAlign.center));
        return ListView(padding: const EdgeInsets.only(top: 10), children: [for (final d in l) tile(c, d)]);
      });
}

// ───────── Add customer / Entry ─────────
void addCustomer(BuildContext c) {
  final n = TextEditingController(), p = TextEditingController(), v = TextEditingController(), o = TextEditingController(), nt = TextEditingController();
  Widget f(TextEditingController t, String l, {bool num = false}) => Padding(padding: const EdgeInsets.only(bottom: 10),
      child: TextField(controller: t, keyboardType: num ? TextInputType.number : null, decoration: InputDecoration(labelText: l)));
  showModalBottomSheet(context: c, isScrollControlled: true, builder: (_) => Padding(
      padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(c).viewInsets.bottom + 20),
      child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('নতুন কাস্টমার', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)), const SizedBox(height: 14),
        f(n, 'নাম *'), f(p, 'মোবাইল (ঐচ্ছিক)', num: true), f(v, 'গ্রাম / ভাগ (ঐচ্ছিক)'), f(o, 'পুরনো বাকি (ঐচ্ছিক)', num: true), f(nt, 'নোট (ঐচ্ছিক)'),
        SizedBox(width: double.infinity, height: 50, child: FilledButton(onPressed: () {
          if (n.text.trim().isEmpty) return;
          final r = cust.doc();
          r.set({'name': n.text.trim(), 'phone': p.text.trim(), 'village': v.text.trim(), 'note': nt.text.trim(), 'balance': 0, 'due': null, 'createdAt': Timestamp.now()});
          final amt = num.tryParse(toEn(o.text));
          if (amt != null && amt > 0) addEntry(r.id, amt, 'পুরনো বাকি');
          Navigator.pop(c);
        }, child: const Text('সংরক্ষণ'))),
      ]))));
}

Future<void> entryDialog(BuildContext c, String id, bool baki) async {
  final a = TextEditingController(), n = TextEditingController();
  final ok = await showDialog<bool>(context: c, builder: (_) => AlertDialog(
      title: Text(baki ? 'বাকি দিলাম' : 'জমা নিলাম'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: a, autofocus: true, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'টাকার পরিমাণ')),
        const SizedBox(height: 10),
        TextField(controller: n, decoration: const InputDecoration(labelText: 'নোট (ঐচ্ছিক)')),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('বাতিল')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('সংরক্ষণ'))]));
  final v = num.tryParse(toEn(a.text));
  if (ok == true && v != null && v > 0) addEntry(id, baki ? v : -v, n.text.trim());
}

// ───────── Detail ─────────
class Detail extends StatelessWidget {
  final String id;
  const Detail(this.id, {super.key});
  Future<void> setDue(BuildContext c) async {
    final d = await showDatePicker(context: c, firstDate: DateTime.now().subtract(const Duration(days: 1)), lastDate: DateTime.now().add(const Duration(days: 730)), initialDate: DateTime.now());
    if (d == null || !c.mounted) return;
    final t = await showTimePicker(context: c, initialTime: const TimeOfDay(hour: 17, minute: 0));
    if (t == null) return;
    cust.doc(id).update({'due': Timestamp.fromDate(DateTime(d.year, d.month, d.day, t.hour, t.minute))});
  }
  @override
  Widget build(BuildContext c) => StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: cust.doc(id).snapshots(),
      builder: (c, s) {
        final m = s.data?.data();
        if (m == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));
        final bal = (m['balance'] ?? 0) as num;
        final due = (m['due'] as Timestamp?)?.toDate();
        return Scaffold(
          appBar: AppBar(title: Text(m['name']), actions: [
            IconButton(icon: const Icon(Icons.edit_note), onPressed: () async {
              final t = TextEditingController(text: m['note']);
              final ok = await showDialog<bool>(context: c, builder: (_) => AlertDialog(title: const Text('নোট'), content: TextField(controller: t, maxLines: 4, autofocus: true),
                  actions: [FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('সংরক্ষণ'))]));
              if (ok == true) cust.doc(id).update({'note': t.text.trim()});
            }),
            IconButton(icon: const Icon(Icons.delete_outline), onPressed: () async {
              final ok = await showDialog<bool>(context: c, builder: (_) => AlertDialog(title: const Text('কাস্টমার মুছবেন?'), content: const Text('সব হিসাবসহ মুছে যাবে।'),
                  actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('না')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('হ্যাঁ, মুছুন'))]));
              if (ok == true) { cust.doc(id).delete(); if (c.mounted) Navigator.pop(c); }
            }),
          ]),
          body: ListView(padding: const EdgeInsets.only(bottom: 30), children: [
            Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('বর্তমান বাকি', style: TextStyle(color: Colors.grey.shade600)),
              Text(tk(bal), style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800, color: bal > 0 ? Colors.deepOrange : Colors.green)),
              const SizedBox(height: 6),
              if ('${m['village']}'.isNotEmpty) Text('📍 ${m['village']}'),
              if ('${m['phone']}'.isNotEmpty) Text('📞 ${m['phone']}'),
              if ('${m['note']}'.isNotEmpty) Text('📝 ${m['note']}'),
              const Divider(height: 24),
              Row(children: [
                Expanded(child: Text(due == null ? 'তাগাদার সময় সেট নেই' : '⏰ ${dt(due)}', style: const TextStyle(fontWeight: FontWeight.w600))),
                TextButton.icon(onPressed: () => setDue(c), icon: const Icon(Icons.alarm_add), label: const Text('তাগাদা সেট')),
                if (due != null) IconButton(onPressed: () => cust.doc(id).update({'due': null}), icon: const Icon(Icons.close)),
              ]),
            ]))),
            Padding(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6), child: Row(children: [
              Expanded(child: FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: Colors.deepOrange, minimumSize: const Size(0, 50)), onPressed: () => entryDialog(c, id, true), icon: const Icon(Icons.add), label: const Text('বাকি দিলাম'))),
              const SizedBox(width: 10),
              Expanded(child: FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: Colors.green, minimumSize: const Size(0, 50)), onPressed: () => entryDialog(c, id, false), icon: const Icon(Icons.remove), label: const Text('জমা নিলাম'))),
            ])),
            const Padding(padding: EdgeInsets.fromLTRB(18, 14, 18, 4), child: Text('লেনদেনের ইতিহাস', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
            StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                stream: cust.doc(id).collection('entries').orderBy('date', descending: true).snapshots(),
                builder: (c, e) => Column(children: [
                  for (final x in e.data?.docs ?? <QueryDocumentSnapshot<Map<String, dynamic>>>[])
                    Card(child: ListTile(
                      leading: Icon(x['amount'] > 0 ? Icons.north_east : Icons.south_west, color: x['amount'] > 0 ? Colors.deepOrange : Colors.green),
                      title: Text('${x['amount'] > 0 ? 'বাকি' : 'জমা'}  ${tk((x['amount'] as num).abs())}', style: const TextStyle(fontWeight: FontWeight.w700)),
                      subtitle: Text([dt((x['date'] as Timestamp).toDate()), if ('${x['note']}'.isNotEmpty) x['note']].join('\n')),
                    )),
                ])),
          ]),
        );
      });
}

// ───────── Report PDF ─────────
class ReportPage extends StatefulWidget {
  const ReportPage({super.key});
  @override
  State<ReportPage> createState() => _RPState();
}

class _RPState extends State<ReportPage> {
  final key = GlobalKey();
  Future<void> pdf() async {
    final b = key.currentContext!.findRenderObject() as RenderRepaintBoundary;
    final img = await b.toImage(pixelRatio: 2.5);
    final bytes = (await img.toByteData(format: ui.ImageByteFormat.png))!.buffer.asUint8List();
    final h = 595.0 * img.height / img.width;
    final doc = pw.Document()
      ..addPage(pw.Page(pageFormat: PdfPageFormat(595, h), margin: pw.EdgeInsets.zero, build: (_) => pw.Image(pw.MemoryImage(bytes), fit: pw.BoxFit.fill)));
    await Printing.sharePdf(bytes: await doc.save(), filename: 'baki-report.pdf');
  }
  @override
  Widget build(BuildContext c) => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: cust.snapshots(),
      builder: (c, s) {
        final l = (s.data?.docs ?? []).where((d) => ((d['balance'] ?? 0) as num) > 0).toList();
        final g = <String, List<QueryDocumentSnapshot<Map<String, dynamic>>>>{};
        for (final d in l) { g.putIfAbsent('${d['village']}'.isEmpty ? 'অন্যান্য' : d['village'], () => []).add(d); }
        final total = l.fold<num>(0, (a, d) => a + (d['balance'] as num));
        final now = DateTime.now();
        return Column(children: [
          Expanded(child: SingleChildScrollView(child: RepaintBoundary(key: key, child: Container(color: Colors.white, padding: const EdgeInsets.all(18),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [Image.asset('assets/logo.png', width: 54), const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    ValueListenableBuilder<String>(valueListenable: shop, builder: (_, s, __) => Text(s, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
                    Text('বাকির রিপোর্ট • ${dt(now)}', style: const TextStyle(color: Colors.black54)),
                  ]))]),
                const Divider(height: 26),
                for (final e in g.entries) ...[
                  Container(width: double.infinity, padding: const EdgeInsets.all(8), margin: const EdgeInsets.only(top: 8), color: const Color(0xFFE8F5E9),
                      child: Text('${e.key}  (${tk(e.value.fold<num>(0, (a, d) => a + (d['balance'] as num)))})', style: const TextStyle(fontWeight: FontWeight.w800))),
                  for (final d in e.value) Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(d['name'], style: const TextStyle(fontWeight: FontWeight.w700)),
                      if ('${d['phone']}'.isNotEmpty) Text(d['phone'], style: const TextStyle(fontSize: 12, color: Colors.black54)),
                      if (d['due'] != null) Text((d['due'] as Timestamp).toDate().isBefore(now) ? '⚠ সময় পার হয়েছে: ${dt((d['due'] as Timestamp).toDate())}' : 'দেওয়ার কথা: ${dt((d['due'] as Timestamp).toDate())}',
                          style: TextStyle(fontSize: 12, color: (d['due'] as Timestamp).toDate().isBefore(now) ? Colors.red : Colors.black54)),
                    ])),
                    Text(tk(d['balance']), style: const TextStyle(fontWeight: FontWeight.w800)),
                  ])),
                ],
                const Divider(height: 26),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('সর্বমোট বাকি', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)), Text(tk(total), style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: Colors.deepOrange))]),
              ]))))),
          Padding(padding: const EdgeInsets.all(12), child: SizedBox(width: double.infinity, height: 50, child: FilledButton.icon(onPressed: l.isEmpty ? null : pdf, icon: const Icon(Icons.picture_as_pdf), label: const Text('PDF তৈরি / শেয়ার করুন')))),
        ]);
      });
}

// ───────── Settings ─────────
class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SPState();
}

class _SPState extends State<SettingsPage> {
  late final n = TextEditingController(text: shop.value);
  static const colors = [0xFF2E7D32, 0xFF1565C0, 0xFF6A1B9A, 0xFFC62828, 0xFFEF6C00, 0xFF00695C];
  void save(Map<String, dynamic> m) => me.collection('meta').doc('settings').set(m, SetOptions(merge: true));
  @override
  Widget build(BuildContext c) => Scaffold(
      appBar: AppBar(title: const Text('সেটিংস')),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        TextField(controller: n, decoration: InputDecoration(labelText: 'দোকানের নাম', suffixIcon: IconButton(icon: const Icon(Icons.check), onPressed: () { save({'shop': n.text.trim()}); shop.value = n.text.trim(); }))),
        const SizedBox(height: 22),
        const Text('থিমের রঙ', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 10),
        Wrap(spacing: 12, children: [for (final k in colors) GestureDetector(onTap: () { seed.value = k; save({'seed': k}); },
            child: CircleAvatar(radius: 22, backgroundColor: Color(k), child: seed.value == k ? const Icon(Icons.check, color: Colors.white) : null))]),
        const SizedBox(height: 22),
        if (Platform.isAndroid) ListTile(leading: const Icon(Icons.verified_user_outlined), title: const Text('অনুমতি ঠিক করুন (অ্যালার্ম/নোটিফিকেশন)'), onTap: () async { await askPermissions(c, force: true); reschedule(latest); }),
        ListTile(leading: const Icon(Icons.system_update_alt), title: const Text('নতুন আপডেট খুঁজুন'), onTap: () => checkUpdate(c)),
        ListTile(leading: const Icon(Icons.logout, color: Colors.red), title: const Text('লগআউট'), onTap: () { FirebaseAuth.instance.signOut(); Navigator.popUntil(c, (r) => r.isFirst); }),
      ]));
}

// ───────── In-app updater (GitHub Releases) ─────────
bool newer(String a, String b) {
  final x = a.split('.').map((e) => int.tryParse(e) ?? 0).toList(), y = b.split('.').map((e) => int.tryParse(e) ?? 0).toList();
  for (var i = 0; i < 3; i++) { final p = i < x.length ? x[i] : 0, q = i < y.length ? y[i] : 0; if (p != q) return p > q; }
  return false;
}

Future<void> checkUpdate(BuildContext c, {bool silent = false}) async {
  void snack(String s) { if (!silent && c.mounted) ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(s))); }
  if (Platform.isIOS) return snack('iPhone এ আপডেট নিজে ইনস্টল করতে হবে');
  try {
    final r = await http.get(Uri.parse('https://api.github.com/repos/$kRepo/releases/latest'));
    final j = jsonDecode(r.body);
    final tag = (j['tag_name'] as String).replaceFirst('v', '');
    final cur = (await PackageInfo.fromPlatform()).version;
    if (!newer(tag, cur)) return snack('আপনার অ্যাপ আপ-টু-ডেট ($cur)');
    final ext = Platform.isAndroid ? '.apk' : '.zip';
    final asset = (j['assets'] as List).firstWhere((a) => a['name'].toString().endsWith(ext));
    if (!c.mounted) return;
    final ok = await showDialog<bool>(context: c, builder: (_) => AlertDialog(
        title: Text('নতুন আপডেট $tag'), content: const Text('আপডেট ডাউনলোড করে ইনস্টল করবেন?'),
        actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('পরে')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('আপডেট করুন'))]));
    if (ok != true || !c.mounted) return;
    final prog = ValueNotifier<double>(0);
    showDialog(context: c, barrierDismissible: false, builder: (_) => AlertDialog(title: const Text('ডাউনলোড হচ্ছে...'),
        content: ValueListenableBuilder<double>(valueListenable: prog, builder: (_, v, __) => LinearProgressIndicator(value: v))));
    final res = await http.Client().send(http.Request('GET', Uri.parse(asset['browser_download_url'])));
    final f = File('${(await getTemporaryDirectory()).path}/${asset['name']}');
    final sink = f.openWrite();
    var got = 0;
    await for (final ch in res.stream) { sink.add(ch); got += ch.length; prog.value = got / (res.contentLength ?? got); }
    await sink.close();
    if (c.mounted) Navigator.pop(c);
    if (Platform.isAndroid) await Permission.requestInstallPackages.request();
    await OpenFilex.open(f.path);
  } catch (_) { snack('আপডেট চেক করা যায়নি (ইন্টারনেট দেখুন)'); }
}

// ───────── Daily tasks ─────────
class TasksPage extends StatefulWidget {
  const TasksPage({super.key});
  @override
  State<TasksPage> createState() => _TPState();
}

class _TPState extends State<TasksPage> {
  final t = TextEditingController();
  void add([String? s]) {
    final v = (s ?? t.text).trim();
    if (v.isEmpty) return;
    tasks.add({'title': v, 'done': false, 'createdAt': Timestamp.now()});
    t.clear();
  }
  @override
  Widget build(BuildContext c) => Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(14, 14, 14, 6), child: TextField(controller: t, onSubmitted: (_) => add(),
            decoration: InputDecoration(hintText: 'আজকের কাজ লিখুন...', filled: true, fillColor: Colors.white,
                suffixIcon: IconButton(icon: const Icon(Icons.add_circle), onPressed: add)))),
        SizedBox(height: 44, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12), children: [
          for (final s in ['তাগাদা করা', 'মাল অর্ডার', 'দোকানের বিল', 'ব্যাংকে জমা', 'ফটোকপি/প্রিন্টের হিসাব'])
            Padding(padding: const EdgeInsets.only(right: 8), child: ActionChip(label: Text(s), onPressed: () => add(s)))])),
        Expanded(child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: tasks.orderBy('createdAt', descending: true).snapshots(),
            builder: (c, s) {
              final l = [...?s.data?.docs]..sort((a, b) => a['done'] == b['done'] ? 0 : (a['done'] ? 1 : -1));
              if (l.isEmpty) return const Center(child: Text('কোনো কাজ নেই'));
              return ListView(padding: const EdgeInsets.only(top: 6), children: [
                for (final d in l)
                  Dismissible(key: ValueKey(d.id), onDismissed: (_) => d.reference.delete(), background: Container(color: Colors.red.shade100),
                      child: Card(child: CheckboxListTile(value: d['done'] as bool, onChanged: (v) => d.reference.update({'done': v}),
                          title: Text(d['title'], style: TextStyle(decoration: (d['done'] as bool) ? TextDecoration.lineThrough : null)))))
              ]);
            })),
      ]);
}

// ───────── Windows ছোট উইজেট ─────────
class MiniPage extends StatefulWidget {
  const MiniPage({super.key});
  @override
  State<MiniPage> createState() => _MPState();
}

class _MPState extends State<MiniPage> {
  @override
  void initState() { super.initState(); windowManager.setSize(const Size(340, 520)); windowManager.setAlwaysOnTop(true); }
  @override
  void dispose() { windowManager.setAlwaysOnTop(false); windowManager.setSize(const Size(1100, 760)); super.dispose(); }
  @override
  Widget build(BuildContext c) => Scaffold(
      appBar: AppBar(title: const Text('বাকি উইজেট'), toolbarHeight: 46),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: cust.snapshots(),
          builder: (c, s) {
            final l = (s.data?.docs ?? []).where((d) => ((d['balance'] ?? 0) as num) > 0).toList()
              ..sort((a, b) => (b['balance'] as num).compareTo(a['balance'] as num));
            final total = l.fold<num>(0, (a, d) => a + (d['balance'] as num));
            return Column(children: [
              Container(width: double.infinity, margin: const EdgeInsets.all(10), padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), gradient: LinearGradient(colors: [Theme.of(c).colorScheme.primary, Theme.of(c).colorScheme.tertiary])),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('মোট বাকি', style: TextStyle(color: Colors.white70)),
                    Text(tk(total), style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w800)),
                    Text('${l.length} জন', style: const TextStyle(color: Colors.white70)),
                  ])),
              Expanded(child: ListView(children: [
                for (final d in l)
                  ListTile(dense: true, title: Text(d['name'], style: const TextStyle(fontWeight: FontWeight.w700)),
                      subtitle: d['due'] == null ? null : Text('⏰ ${dt((d['due'] as Timestamp).toDate())}'),
                      trailing: Text(tk(d['balance']), style: const TextStyle(fontWeight: FontWeight.w800, color: Colors.deepOrange)))
              ])),
            ]);
          }));
}
