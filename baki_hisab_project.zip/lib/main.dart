import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui' as ui;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:home_widget/home_widget.dart';
import 'package:http/http.dart' as http;
import 'package:intl/date_symbol_data_local.dart';
import 'package:intl/intl.dart';
import 'package:open_filex/open_filex.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:permission_handler/permission_handler.dart';
import 'package:printing/printing.dart';
import 'package:timezone/data/latest.dart' as tzd;
import 'package:timezone/timezone.dart' as tz;
import 'package:url_launcher/url_launcher.dart';
import 'package:window_manager/window_manager.dart';

const kRepo = 'OWNER/REPO'; // GitHub Action নিজে বসিয়ে দেয়
const fbOptions = FirebaseOptions(
  apiKey: 'AIzaSyDCYJ5_WxhGXebRjOqfFu9oG6EWgMQuo38',
  authDomain: 'baki-hisab-a32ba.firebaseapp.com',
  projectId: 'baki-hisab-a32ba',
  storageBucket: 'baki-hisab-a32ba.firebasestorage.app',
  messagingSenderId: '548966518518',
  appId: '1:548966518518:web:8b96d240aeba2f4ad226d7',
);

const defShop = 'সবুজ কম্পিউটার বুক ক্যাম্পাস';
const defSeed = 0xFF2E7D32;
final seed = ValueNotifier<int>(defSeed);
final shop = ValueNotifier<String>(defShop);
final notif = FlutterLocalNotificationsPlugin();
final navKey = GlobalKey<NavigatorState>();
bool get mobile => Platform.isAndroid || Platform.isIOS;
final db = FirebaseFirestore.instance;
String get uid => FirebaseAuth.instance.currentUser!.uid;
DocumentReference<Map<String, dynamic>> get me => db.collection('users').doc(uid);
CollectionReference<Map<String, dynamic>> get cust => me.collection('customers');
CollectionReference<Map<String, dynamic>> get tasks => me.collection('tasks');
CollectionReference<Map<String, dynamic>> get ledger => me.collection('ledger');

typedef Doc = QueryDocumentSnapshot<Map<String, dynamic>>;

// সব কাস্টমারের ডাটা একটাই লিসেনার থেকে (খরচ ও গোলমাল কম)
final custDocs = ValueNotifier<List<Doc>>([]);
final custReady = ValueNotifier<bool>(false);
final custError = ValueNotifier<String?>(null);

// ───────── Helpers ─────────
final _nf = NumberFormat('#,##,##0.##', 'bn');
String tk(num n) => '${n < 0 ? '-' : ''}৳ ${_nf.format(n.abs())}';
String dt(DateTime d) => DateFormat('d MMM yyyy, h:mm a', 'bn').format(d);
String toEn(String s) {
  const b = '০১২৩৪৫৬৭৮৯';
  return s.split('').map((x) {
    final i = b.indexOf(x);
    return i < 0 ? x : '$i';
  }).join();
}

String str(Map<String, dynamic> m, String k) {
  final v = m[k];
  return v == null ? '' : '$v'.trim();
}

num numOf(Map<String, dynamic> m, String k) {
  final v = m[k];
  return v is num ? v : 0;
}

DateTime? dtOf(Map<String, dynamic> m, String k) {
  final v = m[k];
  return v is Timestamp ? v.toDate() : null;
}

num? parseAmt(String s) {
  final t = toEn(s).replaceAll(RegExp(r'[^0-9.]'), '');
  if (t.isEmpty) return null;
  final v = num.tryParse(t);
  if (v == null) return null;
  return v == v.truncate() ? v.toInt() : v;
}

String plain(num n) => n == n.truncate() ? '${n.truncate()}' : '$n';

String phoneRaw(String s) => toEn(s).replaceAll(RegExp(r'[^0-9+]'), '');
String phoneIntl(String raw) {
  final d = toEn(raw).replaceAll(RegExp(r'[^0-9]'), '');
  if (d.isEmpty) return '';
  if (d.startsWith('880')) return d;
  if (d.startsWith('0')) return '88$d';
  if (d.length == 10) return '880$d';
  return d;
}

String dueMsg(Map<String, dynamic> m) =>
    'আসসালামু আলাইকুম ${str(m, 'name')}, ${shop.value} এ আপনার মোট বাকি ${tk(numOf(m, 'balance'))}। অনুগ্রহ করে সুবিধামতো পরিশোধ করবেন। ধন্যবাদ।';

String waUrl(String phone, String msg) => 'https://wa.me/${phoneIntl(phone)}?text=${Uri.encodeComponent(msg)}';
String smsUrl(String phone, String msg) => 'sms:${phoneRaw(phone)}?body=${Uri.encodeComponent(msg)}';

void toast(BuildContext c, String s) {
  final m = ScaffoldMessenger.maybeOf(c);
  m?.hideCurrentSnackBar();
  m?.showSnackBar(SnackBar(content: Text(s)));
}

Future<void> openUrl(BuildContext c, String url) async {
  try {
    final ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    if (!ok && c.mounted) toast(c, 'খোলা যায়নি');
  } catch (_) {
    if (c.mounted) toast(c, 'খোলা যায়নি');
  }
}

InputDecoration deco({String? label, String? hint, Widget? prefix, Widget? suffix, bool filled = false, String? err, String? helper}) => InputDecoration(
    labelText: label,
    hintText: hint,
    prefixIcon: prefix,
    suffixIcon: suffix,
    filled: filled,
    fillColor: filled ? Colors.white : null,
    errorText: err,
    errorMaxLines: 3,
    helperText: helper,
    helperMaxLines: 2,
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)));

final amtFmt = <TextInputFormatter>[FilteringTextInputFormatter.allow(RegExp('[0-9\u09E6-\u09EF.,]'))];
const numKb = TextInputType.numberWithOptions(decimal: true);

Widget card(Widget child, {EdgeInsets margin = const EdgeInsets.symmetric(horizontal: 14, vertical: 5)}) => Card(
    elevation: 0,
    color: Colors.white,
    surfaceTintColor: Colors.transparent,
    margin: margin,
    clipBehavior: Clip.antiAlias,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
    child: child);

void openDetail(BuildContext c, String id) => Navigator.push(c, MaterialPageRoute(builder: (_) => Detail(id)));

DateTime startOfToday() {
  final n = DateTime.now();
  return DateTime(n.year, n.month, n.day);
}

int overdueCount(List<Doc> docs) {
  final now = DateTime.now();
  return docs.where((d) {
    final due = dtOf(d.data(), 'due');
    return due != null && due.isBefore(now) && numOf(d.data(), 'balance') > 0;
  }).length;
}

// ডাটা লোড/এরর অবস্থা সামলে বিল্ডার চালায়
Widget withCust(Widget Function(BuildContext, List<Doc>) b) => ValueListenableBuilder<bool>(
    valueListenable: custReady,
    builder: (c, ready, _) => ValueListenableBuilder<List<Doc>>(
        valueListenable: custDocs,
        builder: (c, docs, _) {
          if (!ready) {
            return ValueListenableBuilder<String?>(
                valueListenable: custError,
                builder: (c, e, _) => Center(
                    child: e == null
                        ? const CircularProgressIndicator()
                        : Padding(padding: const EdgeInsets.all(24), child: Text('ডাটা লোড করা যায়নি।\nইন্টারনেট ও Firestore rules দেখুন।\n$e', textAlign: TextAlign.center))));
          }
          return b(c, docs);
        }));

// ───────── ডাটা অপারেশন ─────────
Map<String, dynamic> newCust(String name, String phone, String village, String note) =>
    {'name': name, 'phone': phone, 'village': village, 'note': note, 'balance': 0, 'due': null, 'createdAt': Timestamp.now()};

void fire(Future<void> f) {
  f.catchError((_) {});
}

void addEntry(String id, num amt, String note, {String name = ''}) {
  final r = cust.doc(id);
  final e = r.collection('entries').doc();
  final now = Timestamp.now();
  final b = db.batch();
  b.set(e, {'amount': amt, 'note': note, 'date': now});
  b.update(r, {'balance': FieldValue.increment(amt)});
  b.set(ledger.doc(e.id), {'cid': id, 'name': name, 'amount': amt, 'note': note, 'date': now});
  fire(b.commit());
}

void deleteEntry(String cid, DocumentSnapshot<Map<String, dynamic>> e) {
  final amt = numOf(e.data() ?? {}, 'amount');
  final b = db.batch();
  b.delete(e.reference);
  b.update(cust.doc(cid), {'balance': FieldValue.increment(-amt)});
  b.delete(ledger.doc(e.id));
  fire(b.commit());
}

Future<void> deleteCustomer(String id) async {
  final refs = <DocumentReference>[];
  final es = await cust.doc(id).collection('entries').get();
  refs.addAll(es.docs.map((d) => d.reference));
  final ls = await ledger.where('cid', isEqualTo: id).get();
  refs.addAll(ls.docs.map((d) => d.reference));
  refs.add(cust.doc(id));
  for (var i = 0; i < refs.length; i += 400) {
    final b = db.batch();
    for (final r in refs.skip(i).take(400)) {
      b.delete(r);
    }
    await b.commit();
  }
}

// দ্রুত পুরনো বাকি: প্রতি লাইনে "নাম, গ্রাম, টাকা"
Future<(int, int)> quickAdd(String text) async {
  final byName = <String, String>{};
  for (final d in custDocs.value) {
    byName[str(d.data(), 'name').toLowerCase()] = d.id;
  }
  var ok = 0, bad = 0;
  for (final line in text.split('\n')) {
    if (line.trim().isEmpty) continue;
    final p = line.split(RegExp('[,\u060C]')).map((e) => e.trim()).toList();
    final amt = p.length < 2 ? null : parseAmt(p.last);
    if (p.first.isEmpty || amt == null || amt <= 0) {
      bad++;
      continue;
    }
    final name = p.first;
    final key = name.toLowerCase();
    final id = byName[key];
    if (id != null) {
      addEntry(id, amt, 'পুরনো বাকি', name: name);
    } else {
      final r = cust.doc();
      final e = r.collection('entries').doc();
      final now = Timestamp.now();
      final b = db.batch();
      b.set(r, {...newCust(name, '', p.length > 2 ? p[1] : '', ''), 'balance': amt});
      b.set(e, {'amount': amt, 'note': 'পুরনো বাকি', 'date': now});
      b.set(ledger.doc(e.id), {'cid': r.id, 'name': name, 'amount': amt, 'note': 'পুরনো বাকি', 'date': now});
      fire(b.commit());
      byName[key] = r.id;
    }
    ok++;
  }
  return (ok, bad);
}

// ───────── নোটিফিকেশন / অ্যালার্ম ─────────
bool _rs = false, _rsAgain = false;

Future<void> reschedule() async {
  if (!mobile) return;
  if (_rs) {
    _rsAgain = true;
    return;
  }
  _rs = true;
  try {
    do {
      _rsAgain = false;
      await _doReschedule(custDocs.value);
    } while (_rsAgain);
  } finally {
    _rs = false;
  }
}

Future<void> _doReschedule(List<Doc> docs) async {
  try {
    await notif.cancelAll();
  } catch (_) {}
  var i = 1;
  final now = DateTime.now();
  for (final d in docs) {
    if (i > 400) break;
    final m = d.data();
    final due = dtOf(m, 'due');
    if (due == null || numOf(m, 'balance') <= 0 || due.isBefore(now)) continue;
    Future<void> go(AndroidScheduleMode mode) => notif.zonedSchedule(
        i,
        '💰 তাগাদা: ${str(m, 'name')}',
        '${tk(numOf(m, 'balance'))} আদায় করতে হবে',
        tz.TZDateTime.from(due, tz.local),
        const NotificationDetails(
            android: AndroidNotificationDetails('due', 'বাকি তাগাদা অ্যালার্ম',
                importance: Importance.max,
                priority: Priority.high,
                fullScreenIntent: true,
                category: AndroidNotificationCategory.alarm,
                audioAttributesUsage: AudioAttributesUsage.alarm),
            iOS: DarwinNotificationDetails(presentAlert: true, presentSound: true)),
        androidScheduleMode: mode,
        uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
        payload: d.id);
    try {
      await go(AndroidScheduleMode.alarmClock);
    } catch (_) {
      try {
        await go(AndroidScheduleMode.inexactAllowWhileIdle);
      } catch (_) {}
    }
    i++;
  }
}

// অনুমতি (Android): আগে নোটিফিকেশন, বাকিগুলো ব্যবহারকারী চাইলে
Future<void> askAlarmPerms() async {
  try {
    await Permission.scheduleExactAlarm.request();
  } catch (_) {}
  try {
    await Permission.ignoreBatteryOptimizations.request();
  } catch (_) {}
}

Future<void> askPermissions(BuildContext c, {bool force = false}) async {
  if (!Platform.isAndroid) return;
  File? f;
  try {
    f = File('${(await getApplicationSupportDirectory()).path}/perm_done');
    if (!force && await f.exists()) return;
  } catch (_) {}
  if (!c.mounted) return;
  final all = await showDialog<bool>(
      context: c,
      barrierDismissible: false,
      builder: (x) => AlertDialog(
          title: const Text('তাগাদার অ্যালার্মের অনুমতি'),
          content: const SingleChildScrollView(child: Text('তাগাদা ঠিক সময়ে বাজাতে নোটিফিকেশনের অনুমতি লাগবে।\n\n"সব অনুমতি দিন" চাপলে অ্যালার্ম ও ব্যাটারির সেটিংস পেজ খুলবে — সেখানে অ্যাপটি বেছে অনুমতি দিয়ে ব্যাক করুন।\n\nপরে চাইলে সেটিংস থেকেও দেওয়া যাবে।')),
          actions: [
            TextButton(onPressed: () => Navigator.pop(x, false), child: const Text('শুধু নোটিফিকেশন')),
            FilledButton(onPressed: () => Navigator.pop(x, true), child: const Text('সব অনুমতি দিন')),
          ]));
  try {
    await Permission.notification.request();
    if (all == true) await askAlarmPerms();
    await f?.writeAsString('1');
  } catch (_) {}
}

// হোম স্ক্রিন উইজেটের ডাটা আপডেট
Future<void> pushWidget(List<Doc> docs) async {
  if (!Platform.isAndroid) return;
  try {
    final l = docs.where((d) => numOf(d.data(), 'balance') > 0).toList();
    final total = l.fold<num>(0, (a, d) => a + numOf(d.data(), 'balance'));
    final due = l.where((d) => dtOf(d.data(), 'due') != null).toList()
      ..sort((a, b) => dtOf(a.data(), 'due')!.compareTo(dtOf(b.data(), 'due')!));
    final lines = due.take(3).map((d) => '⏰ ${str(d.data(), 'name')} • ${tk(numOf(d.data(), 'balance'))}').join('\n');
    await HomeWidget.saveWidgetData<String>('total', tk(total));
    await HomeWidget.saveWidgetData<String>('count', '${l.length} জন বাকি');
    await HomeWidget.saveWidgetData<String>('list', lines.isEmpty ? 'কোনো তাগাদা সেট নেই' : lines);
    await HomeWidget.updateWidget(name: 'BakiWidget', androidName: 'BakiWidget');
  } catch (_) {}
}

Future<void> doLogout(BuildContext c) async {
  final ok = await showDialog<bool>(
      context: c,
      builder: (x) => AlertDialog(title: const Text('লগআউট করবেন?'), content: const Text('আপনার ডাটা নিরাপদ থাকবে। আবার লগইন করলেই পাবেন।'), actions: [
            TextButton(onPressed: () => Navigator.pop(x, false), child: const Text('না')),
            FilledButton(onPressed: () => Navigator.pop(x, true), child: const Text('লগআউট')),
          ]));
  if (ok != true || !c.mounted) return;
  Navigator.of(c).popUntil((r) => r.isFirst);
  try {
    if (mobile) await notif.cancelAll();
  } catch (_) {}
  await FirebaseAuth.instance.signOut();
  shop.value = defShop;
  seed.value = defSeed;
  custDocs.value = [];
  custReady.value = false;
  custError.value = null;
}

// প্লাগিন ছাড়াই ফোনের টাইমজোন ঠিক করা: অফসেট মিললে সেই লোকেশন নেওয়া হয়
void setLocalTz() {
  try {
    final off = DateTime.now().timeZoneOffset;
    final pref = ['Asia/Dhaka', 'Asia/Kolkata', 'Asia/Dubai', 'Asia/Riyadh', 'Asia/Kuala_Lumpur', 'Asia/Singapore'];
    for (final n in pref) {
      final l = tz.getLocation(n);
      if (tz.TZDateTime.now(l).timeZoneOffset == off) {
        tz.setLocalLocation(l);
        return;
      }
    }
    for (final l in tz.timeZoneDatabase.locations.values) {
      if (tz.TZDateTime.now(l).timeZoneOffset == off) {
        tz.setLocalLocation(l);
        return;
      }
    }
  } catch (_) {}
  tz.setLocalLocation(tz.getLocation('Asia/Dhaka'));
}

// ───────── নিরাপদ স্টার্টআপ + ক্র্যাশ লগ ─────────
late Future<void> bootFuture;
String? bootError;

Future<File> crashFile() async => File('${(await getApplicationSupportDirectory()).path}/crash_log.txt');

Future<void> logCrash(Object e, StackTrace? st) async {
  try {
    final f = await crashFile();
    await f.writeAsString('[${DateTime.now()}] $e\n${st ?? ''}\n\n', mode: FileMode.append);
    if (await f.length() > 60000) {
      final all = await f.readAsString();
      await f.writeAsString(all.substring(all.length - 30000));
    }
  } catch (_) {}
}

Future<void> boot() async {
  bootError = null;
  try {
    await initializeDateFormatting('bn');
  } catch (e, st) {
    logCrash(e, st);
  }
  try {
    if (Firebase.apps.isEmpty) await Firebase.initializeApp(options: fbOptions);
  } catch (e, st) {
    bootError = 'Firebase চালু করা যায়নি:\n$e';
    logCrash(e, st);
    return;
  }
  if (Platform.isWindows) {
    try {
      await windowManager.ensureInitialized();
      await windowManager.setTitle('বাকি হিসাব');
    } catch (e, st) {
      logCrash(e, st);
    }
  }
  if (mobile) {
    try {
      tzd.initializeTimeZones();
      setLocalTz();
      await notif.initialize(
          const InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher'), iOS: DarwinInitializationSettings()),
          onDidReceiveNotificationResponse: (r) {
        final id = r.payload;
        if (id != null && id.isNotEmpty && FirebaseAuth.instance.currentUser != null) {
          navKey.currentState?.push(MaterialPageRoute(builder: (_) => Detail(id)));
        }
      });
    } catch (e, st) {
      logCrash(e, st);
    }
  }
}

void main() {
  runZonedGuarded(() {
    WidgetsFlutterBinding.ensureInitialized();
    FlutterError.onError = (d) {
      FlutterError.presentError(d);
      logCrash(d.exception, d.stack);
    };
    ui.PlatformDispatcher.instance.onError = (e, st) {
      logCrash(e, st);
      return true;
    };
    bootFuture = boot();
    runApp(const App());
  }, (e, st) => logCrash(e, st));
}

class BootErrorPage extends StatelessWidget {
  const BootErrorPage({super.key});
  @override
  Widget build(BuildContext c) => Scaffold(
      body: SafeArea(
          child: Center(
              child: SingleChildScrollView(
                  padding: const EdgeInsets.all(24),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.error_outline, size: 56, color: Colors.red),
                    const SizedBox(height: 12),
                    const Text('অ্যাপ চালু করা যায়নি', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 10),
                    SelectableText(bootError ?? '', textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54)),
                    const SizedBox(height: 20),
                    FilledButton(
                        onPressed: () async {
                          bootFuture = boot();
                          await bootFuture;
                          if (!c.mounted) return;
                          Navigator.pushReplacement(c, MaterialPageRoute(builder: (_) => bootError == null ? const Gate() : const BootErrorPage()));
                        },
                        child: const Text('আবার চেষ্টা করুন')),
                  ])))));
}

class CrashLogPage extends StatefulWidget {
  const CrashLogPage({super.key});
  @override
  State<CrashLogPage> createState() => _CLPState();
}

class _CLPState extends State<CrashLogPage> {
  String txt = '...';
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    String t;
    try {
      final f = await crashFile();
      t = await f.exists() ? await f.readAsString() : '';
    } catch (e) {
      t = 'পড়া যায়নি: $e';
    }
    if (mounted) setState(() => txt = t.trim().isEmpty ? 'কোনো ত্রুটি নেই ✅' : t);
  }

  @override
  Widget build(BuildContext c) => Scaffold(
      appBar: AppBar(title: const Text('ত্রুটির লগ'), actions: [
        IconButton(icon: const Icon(Icons.copy), tooltip: 'কপি', onPressed: () {
          Clipboard.setData(ClipboardData(text: txt));
          toast(c, 'কপি হয়েছে');
        }),
        IconButton(icon: const Icon(Icons.delete_outline), tooltip: 'মুছুন', onPressed: () async {
          try {
            final f = await crashFile();
            if (await f.exists()) await f.delete();
          } catch (_) {}
          load();
        }),
      ]),
      body: SingleChildScrollView(padding: const EdgeInsets.all(14), child: SelectableText(txt, style: const TextStyle(fontSize: 12))));
}

// ───────── App & Splash ─────────
class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext c) => ValueListenableBuilder<int>(
      valueListenable: seed,
      builder: (_, s, __) => MaterialApp(
          navigatorKey: navKey,
          title: 'বাকি হিসাব',
          debugShowCheckedModeBanner: false,
          theme: ThemeData(useMaterial3: true, colorSchemeSeed: Color(s), scaffoldBackgroundColor: const Color(0xFFF4F7F4)),
          // সিস্টেমের ফন্ট খুব বড় করা থাকলেও যেন লেখা উপচে না যায়
          builder: (ctx, child) {
            final mq = MediaQuery.of(ctx);
            final sc = mq.textScaler.scale(10) / 10;
            return MediaQuery(data: mq.copyWith(textScaler: TextScaler.linear(sc.clamp(0.85, 1.2).toDouble())), child: child ?? const SizedBox());
          },
          home: const Splash()));
}

class Splash extends StatefulWidget {
  const Splash({super.key});
  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> with SingleTickerProviderStateMixin {
  late final ac = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))..forward();
  @override
  void initState() {
    super.initState();
    go();
  }

  Future<void> go() async {
    await Future.wait([Future.delayed(const Duration(milliseconds: 2200)), bootFuture]);
    if (!mounted) return;
    Navigator.pushReplacement(
        context,
        PageRouteBuilder(
            transitionDuration: const Duration(milliseconds: 500),
            pageBuilder: (_, __, ___) => bootError == null ? const Gate() : const BootErrorPage(),
            transitionsBuilder: (_, a, __, w) => FadeTransition(opacity: a, child: w)));
  }

  @override
  void dispose() {
    ac.dispose();
    super.dispose();
  }

  Animation<double> iv(double a, double b, [Curve k = Curves.easeOut]) => CurvedAnimation(parent: ac, curve: Interval(a, b, curve: k));
  @override
  Widget build(BuildContext c) => Scaffold(
      backgroundColor: Colors.white,
      body: Center(
          child: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
        ScaleTransition(scale: iv(0, .6, Curves.elasticOut), child: FadeTransition(opacity: iv(0, .3), child: Image.asset('assets/logo.png', width: 150))),
        const SizedBox(height: 24),
        FadeTransition(
            opacity: iv(.5, .85),
            child: SlideTransition(
                position: Tween<Offset>(begin: const Offset(0, .5), end: Offset.zero).animate(iv(.5, .85)),
                child: const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20),
                    child: Column(children: [
                      Text('বাকি হিসাব', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800, color: Color(0xFF2E7D32))),
                      SizedBox(height: 4),
                      Text(defShop, textAlign: TextAlign.center, style: TextStyle(fontSize: 15, color: Colors.black54)),
                    ])))),
        const SizedBox(height: 32),
        SizedBox(
            width: 140,
            child: AnimatedBuilder(
                animation: ac,
                builder: (_, __) => LinearProgressIndicator(value: ac.value, minHeight: 5, borderRadius: BorderRadius.circular(9), color: const Color(0xFF2E7D32)))),
      ]))));
}

class Gate extends StatelessWidget {
  const Gate({super.key});
  @override
  Widget build(BuildContext c) => StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (c, s) {
        if (s.connectionState == ConnectionState.waiting) return const Scaffold(body: Center(child: CircularProgressIndicator()));
        return s.data == null ? const Login() : const Home();
      });
}

// ───────── Login ─────────
String authMsg(FirebaseAuthException x) {
  switch (x.code) {
    case 'invalid-email':
      return 'ইমেইল ঠিকভাবে লিখুন';
    case 'user-not-found':
    case 'wrong-password':
    case 'invalid-credential':
      return 'ইমেইল বা পাসওয়ার্ড ভুল';
    case 'email-already-in-use':
      return 'এই ইমেইলে আগেই একাউন্ট আছে, লগইন করুন';
    case 'weak-password':
      return 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের দিন';
    case 'network-request-failed':
      return 'ইন্টারনেট সংযোগ নেই';
    case 'too-many-requests':
      return 'অনেকবার চেষ্টা হয়েছে, একটু পরে আবার চেষ্টা করুন';
    case 'operation-not-allowed':
      return 'Firebase এ Email/Password লগইন চালু করা নেই (Console → Authentication → Sign-in method)';
    case 'configuration-not-found':
      return 'Firebase Authentication চালু করা হয়নি (Console → Authentication → Get started)';
    case 'invalid-api-key':
    case 'app-not-authorized':
      return 'Firebase কনফিগারেশনে সমস্যা আছে (API key / অ্যাপ অনুমতি)';
    default:
      return 'সমস্যা হয়েছে (${x.code})';
  }
}

class Login extends StatefulWidget {
  const Login({super.key});
  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final e = TextEditingController(), p = TextEditingController();
  bool busy = false, hide = true;
  String? err, info;
  Future<void> go(bool signup) async {
    if (e.text.trim().isEmpty || p.text.isEmpty) {
      setState(() {
        err = 'ইমেইল ও পাসওয়ার্ড দিন';
        info = null;
      });
      return;
    }
    setState(() {
      busy = true;
      err = null;
      info = null;
    });
    try {
      final a = FirebaseAuth.instance;
      if (signup) {
        await a.createUserWithEmailAndPassword(email: e.text.trim(), password: p.text);
      } else {
        await a.signInWithEmailAndPassword(email: e.text.trim(), password: p.text);
      }
    } on FirebaseAuthException catch (x) {
      err = authMsg(x);
    } catch (_) {
      err = 'সমস্যা হয়েছে, আবার চেষ্টা করুন';
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> forgot() async {
    if (e.text.trim().isEmpty) {
      setState(() {
        err = 'আগে ইমেইল লিখুন';
        info = null;
      });
      return;
    }
    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: e.text.trim());
      if (mounted) {
        setState(() {
          info = 'পাসওয়ার্ড রিসেটের লিংক ইমেইলে পাঠানো হয়েছে';
          err = null;
        });
      }
    } on FirebaseAuthException catch (x) {
      if (mounted) {
        setState(() {
          err = authMsg(x);
          info = null;
        });
      }
    } catch (_) {
      if (mounted) setState(() => err = 'সমস্যা হয়েছে, আবার চেষ্টা করুন');
    }
  }

  @override
  void dispose() {
    e.dispose();
    p.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext c) => Scaffold(
      body: Center(
          child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 400),
                  child: Column(children: [
                    Image.asset('assets/logo.png', width: 100),
                    const SizedBox(height: 14),
                    const Text('বাকি হিসাব', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 22),
                    TextField(controller: e, keyboardType: TextInputType.emailAddress, decoration: deco(label: 'ইমেইল', prefix: const Icon(Icons.mail_outline))),
                    const SizedBox(height: 12),
                    TextField(
                        controller: p,
                        obscureText: hide,
                        onSubmitted: (_) => busy ? null : go(false),
                        decoration: deco(label: 'পাসওয়ার্ড', prefix: const Icon(Icons.lock_outline), suffix: IconButton(icon: Icon(hide ? Icons.visibility_off : Icons.visibility), onPressed: () => setState(() => hide = !hide)))),
                    if (err != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(err!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.red))),
                    if (info != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(info!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.green))),
                    const SizedBox(height: 18),
                    SizedBox(width: double.infinity, height: 50, child: FilledButton(onPressed: busy ? null : () => go(false), child: busy ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5)) : const Text('লগইন'))),
                    TextButton(onPressed: busy ? null : forgot, child: const Text('পাসওয়ার্ড ভুলে গেছেন?')),
                    TextButton(onPressed: busy ? null : () => go(true), child: const Text('নতুন একাউন্ট খুলুন (প্রথমবার)', textAlign: TextAlign.center)),
                  ])))));
}

// ───────── Home ─────────
class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int tab = 0;
  StreamSubscription? s1, s2;
  Timer? tm;
  final shown = <String>{};
  @override
  void initState() {
    super.initState();
    s1 = me.collection('meta').doc('settings').snapshots().listen((d) {
      final m = d.data();
      if (m == null) return;
      final sh = m['shop'];
      final sd = m['seed'];
      if (sh is String && sh.trim().isNotEmpty) shop.value = sh;
      if (sd is int) seed.value = sd;
    }, onError: (_) {});
    s2 = cust.snapshots().listen((q) {
      custDocs.value = q.docs;
      custError.value = null;
      custReady.value = true;
      reschedule();
      pushWidget(q.docs);
    }, onError: (e) {
      final t = '$e';
      custError.value = t.length > 140 ? t.substring(0, 140) : t;
    });
    if (Platform.isWindows) tm = Timer.periodic(const Duration(seconds: 20), (_) => desktopAlarm());
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await askPermissions(context);
      reschedule();
      if (mounted) checkUpdate(context, silent: true);
    });
  }

  @override
  void dispose() {
    s1?.cancel();
    s2?.cancel();
    tm?.cancel();
    super.dispose();
  }

  // Windows: অ্যাপ খোলা থাকলে সময় হলে পপআপ + বিপ
  Future<void> desktopAlarm() async {
    final now = DateTime.now();
    for (final d in custDocs.value) {
      final m = d.data();
      final due = dtOf(m, 'due');
      if (due == null || numOf(m, 'balance') <= 0 || due.isAfter(now) || now.difference(due).inHours > 12) continue;
      if (!shown.add('${d.id}${due.millisecondsSinceEpoch}')) continue;
      try {
        Process.run('powershell', ['-NoProfile', '-c', '1..3|%{[console]::beep(1200,400)}']);
        windowManager.show();
        windowManager.focus();
      } catch (_) {}
      if (!mounted) return;
      await showDialog(
          context: context,
          builder: (x) => AlertDialog(
                  title: const Text('⏰ তাগাদার সময় হয়েছে!'),
                  content: Text('${str(m, 'name')}\n${str(m, 'village')} ${str(m, 'phone')}\nবাকি: ${tk(numOf(m, 'balance'))}', style: const TextStyle(fontSize: 18)),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(x), child: const Text('পরে')),
                    FilledButton(
                        onPressed: () {
                          Navigator.pop(x);
                          openDetail(context, d.id);
                        },
                        child: const Text('খুলুন'))
                  ]));
    }
  }

  @override
  Widget build(BuildContext c) {
    final pages = <Widget>[const CustomerList(), const DuePage(), const TasksPage(), const ReportPage()];
    return Scaffold(
      appBar: AppBar(
          titleSpacing: 16,
          title: ValueListenableBuilder<String>(
              valueListenable: shop,
              builder: (_, s, __) => FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(s, style: const TextStyle(fontWeight: FontWeight.w700)))),
          actions: [
            IconButton(icon: const Icon(Icons.bolt), tooltip: 'দ্রুত পুরনো বাকি লিখুন', onPressed: () => quickEntry(c)),
            if (Platform.isWindows) IconButton(icon: const Icon(Icons.picture_in_picture_alt), tooltip: 'ছোট উইজেট', onPressed: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const MiniPage()))),
            IconButton(icon: const Icon(Icons.settings), tooltip: 'সেটিংস', onPressed: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const SettingsPage()))),
          ]),
      body: pages[tab],
      floatingActionButton: tab == 0 ? FloatingActionButton.extended(onPressed: () => customerForm(c), icon: const Icon(Icons.person_add), label: const Text('নতুন কাস্টমার')) : null,
      bottomNavigationBar: ValueListenableBuilder<List<Doc>>(
          valueListenable: custDocs,
          builder: (_, docs, __) {
            final n = overdueCount(docs);
            return NavigationBar(selectedIndex: tab, onDestinationSelected: (i) => setState(() => tab = i), destinations: [
              const NavigationDestination(icon: Icon(Icons.people_alt_outlined), selectedIcon: Icon(Icons.people_alt), label: 'বাকি তালিকা'),
              NavigationDestination(
                  icon: Badge(isLabelVisible: n > 0, label: Text('$n'), child: const Icon(Icons.alarm_outlined)),
                  selectedIcon: Badge(isLabelVisible: n > 0, label: Text('$n'), child: const Icon(Icons.alarm)),
                  label: 'তাগাদা'),
              const NavigationDestination(icon: Icon(Icons.checklist_outlined), selectedIcon: Icon(Icons.checklist), label: 'দৈনিক কাজ'),
              const NavigationDestination(icon: Icon(Icons.picture_as_pdf_outlined), selectedIcon: Icon(Icons.picture_as_pdf), label: 'রিপোর্ট'),
            ]);
          }),
    );
  }
}

void quickEntry(BuildContext c) {
  final t = TextEditingController();
  showModalBottomSheet(
      context: c,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (ctx) => Padding(
          padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 20),
          child: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('⚡ দ্রুত পুরনো বাকি লিখুন', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            const Text('প্রতি লাইনে একজন:  নাম, গ্রাম, টাকা\nযেমন:  রহিম, কুমিল্লা, ৫০০\nগ্রাম না থাকলে:  করিম, ২০০\nএকই নাম থাকলে তার সাথে যোগ হবে।', style: TextStyle(color: Colors.black54)),
            const SizedBox(height: 12),
            TextField(controller: t, maxLines: 6, minLines: 3, autofocus: true, decoration: deco(hint: 'রহিম, কুমিল্লা, ৫০০\nকরিম, ২০০')),
            const SizedBox(height: 12),
            SizedBox(
                width: double.infinity,
                height: 50,
                child: FilledButton(
                    onPressed: () async {
                      final r = await quickAdd(t.text);
                      if (ctx.mounted) Navigator.pop(ctx);
                      if (c.mounted) toast(c, r.$2 == 0 ? '${r.$1} টি বাকি যোগ হয়েছে' : '${r.$1} টি যোগ হয়েছে, ${r.$2} লাইন ঠিক ফরম্যাটে ছিল না');
                    },
                    child: const Text('যোগ করুন'))),
          ]))));
}

// ───────── কাস্টমার তালিকা ─────────
Widget tile(BuildContext c, Doc d) {
  final m = d.data();
  final bal = numOf(m, 'balance');
  final due = dtOf(m, 'due');
  final overdue = due != null && bal > 0 && due.isBefore(DateTime.now());
  final name = str(m, 'name');
  final sub = [str(m, 'village'), str(m, 'phone')].where((x) => x.isNotEmpty).join(' • ');
  final dueLine = due != null && bal > 0 ? '⏰ ${dt(due)}' : '';
  final lines = [if (sub.isNotEmpty) sub, if (dueLine.isNotEmpty) dueLine];
  return card(ListTile(
    onTap: () => openDetail(c, d.id),
    leading: CircleAvatar(backgroundColor: Theme.of(c).colorScheme.primaryContainer, child: Text(name.isEmpty ? '?' : name.characters.first, style: const TextStyle(fontWeight: FontWeight.bold))),
    title: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
    subtitle: lines.isEmpty ? null : Text(lines.join('\n'), maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: overdue ? Colors.red : null)),
    trailing: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 110),
        child: FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerRight,
            child: Text(bal < 0 ? 'অগ্রিম ${tk(-bal)}' : tk(bal), style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: overdue ? Colors.red : bal > 0 ? Colors.deepOrange : Colors.green)))),
  ));
}

Widget statBox(String l, String v) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(l, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white70, fontSize: 12)),
      FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(v, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w800))),
    ]);

class TodayStats extends StatefulWidget {
  const TodayStats({super.key});
  @override
  State<TodayStats> createState() => _TSState();
}

class _TSState extends State<TodayStats> {
  late final Stream<QuerySnapshot<Map<String, dynamic>>> st = ledger.where('date', isGreaterThanOrEqualTo: Timestamp.fromDate(startOfToday())).snapshots();
  @override
  Widget build(BuildContext c) => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: st,
      builder: (c, s) {
        num given = 0, got = 0;
        for (final d in s.data?.docs ?? <QueryDocumentSnapshot<Map<String, dynamic>>>[]) {
          final m = d.data();
          if (str(m, 'note') == 'পুরনো বাকি') continue;
          final a = numOf(m, 'amount');
          if (a > 0) {
            given += a;
          } else {
            got += -a;
          }
        }
        return Row(children: [Expanded(child: statBox('আজ বাকি দিয়েছি', tk(given))), const SizedBox(width: 10), Expanded(child: statBox('আজ জমা পেয়েছি', tk(got)))]);
      });
}

class CustomerList extends StatefulWidget {
  const CustomerList({super.key});
  @override
  State<CustomerList> createState() => _CLState();
}

class _CLState extends State<CustomerList> {
  final qc = TextEditingController();
  String q = '';
  int filter = 0, sort = 0;
  static const filters = ['সব', 'বাকি আছে', 'দেরি', 'পরিশোধিত'];
  @override
  void dispose() {
    qc.dispose();
    super.dispose();
  }

  List<Doc> apply(List<Doc> all) {
    final now = DateTime.now();
    final key = toEn(q).toLowerCase().trim();
    final l = all.where((d) {
      final m = d.data();
      final bal = numOf(m, 'balance');
      final due = dtOf(m, 'due');
      if (filter == 1 && bal <= 0) return false;
      if (filter == 2 && !(bal > 0 && due != null && due.isBefore(now))) return false;
      if (filter == 3 && bal > 0) return false;
      if (key.isEmpty) return true;
      return toEn('${str(m, 'name')} ${str(m, 'village')} ${str(m, 'phone')}').toLowerCase().contains(key);
    }).toList();
    l.sort((a, b) {
      final x = a.data(), y = b.data();
      if (sort == 1) return numOf(y, 'balance').compareTo(numOf(x, 'balance'));
      if (sort == 2) {
        final p = dtOf(x, 'due'), r = dtOf(y, 'due');
        if (p == null && r == null) return 0;
        if (p == null) return 1;
        if (r == null) return -1;
        return p.compareTo(r);
      }
      return str(x, 'name').toLowerCase().compareTo(str(y, 'name').toLowerCase());
    });
    return l;
  }

  @override
  Widget build(BuildContext c) => withCust((c, all) {
        final list = apply(all);
        final total = all.fold<num>(0, (a, d) => a + numOf(d.data(), 'balance'));
        final count = all.where((d) => numOf(d.data(), 'balance') > 0).length;
        final header = Column(children: [
          Container(
              margin: const EdgeInsets.all(14),
              padding: const EdgeInsets.all(18),
              width: double.infinity,
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), gradient: LinearGradient(colors: [Theme.of(c).colorScheme.primary, Theme.of(c).colorScheme.tertiary])),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('মোট বাকি', style: TextStyle(color: Colors.white70)),
                FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(tk(total), style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w800))),
                Text('$count জন বাকি আছে • মোট ${all.length} জন কাস্টমার', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white70)),
                const Divider(color: Colors.white24, height: 22),
                const TodayStats(),
              ])),
          Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              child: Row(children: [
                Expanded(
                    child: TextField(
                        controller: qc,
                        onChanged: (v) => setState(() => q = v),
                        decoration: deco(hint: 'নাম / গ্রাম / মোবাইল দিয়ে খুঁজুন', prefix: const Icon(Icons.search), filled: true, suffix: q.isEmpty ? null : IconButton(icon: const Icon(Icons.close), onPressed: () => setState(() { qc.clear(); q = ''; }))))),
                PopupMenuButton<int>(
                    icon: const Icon(Icons.sort),
                    tooltip: 'সাজান',
                    onSelected: (v) => setState(() => sort = v),
                    itemBuilder: (_) => const [
                          PopupMenuItem(value: 0, child: Text('নাম অনুযায়ী')),
                          PopupMenuItem(value: 1, child: Text('বেশি বাকি আগে')),
                          PopupMenuItem(value: 2, child: Text('তাগাদার সময় অনুযায়ী')),
                        ]),
              ])),
          SizedBox(
              height: 50,
              child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12), children: [
                for (var i = 0; i < filters.length; i++)
                  Padding(padding: const EdgeInsets.only(right: 8, top: 8, bottom: 6), child: ChoiceChip(label: Text(filters[i]), selected: filter == i, onSelected: (_) => setState(() => filter = i))),
              ])),
        ]);
        return ListView.builder(
            padding: const EdgeInsets.only(bottom: 96),
            itemCount: list.length + 1 + (list.isEmpty ? 1 : 0),
            itemBuilder: (c, i) {
              if (i == 0) return header;
              if (list.isEmpty) {
                return Padding(
                    padding: const EdgeInsets.all(40),
                    child: Text(all.isEmpty ? 'কোনো কাস্টমার নেই।\nনিচের "নতুন কাস্টমার" বা ⚡ চাপুন।' : 'কিছু পাওয়া যায়নি', textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54)));
              }
              return tile(c, list[i - 1]);
            });
      });
}

// ───────── তাগাদা ─────────
void snooze(BuildContext c, Doc d) {
  final due = dtOf(d.data(), 'due');
  if (due == null) return;
  final n = DateTime.now();
  var next = due.add(const Duration(days: 1));
  if (!next.isAfter(n)) next = DateTime(n.year, n.month, n.day + 1, due.hour, due.minute);
  d.reference.update({'due': Timestamp.fromDate(next)});
  toast(c, 'তাগাদা পরের দিনে সরানো হয়েছে');
}

Widget dueCard(BuildContext c, Doc d) {
  final m = d.data();
  final bal = numOf(m, 'balance');
  final due = dtOf(m, 'due')!;
  final over = due.isBefore(DateTime.now());
  final ph = phoneRaw(str(m, 'phone'));
  final sub = [str(m, 'village'), str(m, 'phone')].where((x) => x.isNotEmpty).join(' • ');
  final msg = dueMsg(m);
  return card(Padding(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        InkWell(
            onTap: () => openDetail(c, d.id),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(str(m, 'name'), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                if (sub.isNotEmpty) Text(sub, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.black54)),
                Text('⏰ ${dt(due)}', style: TextStyle(color: over ? Colors.red : Colors.black87, fontWeight: FontWeight.w600)),
              ])),
              const SizedBox(width: 8),
              ConstrainedBox(constraints: const BoxConstraints(maxWidth: 120), child: FittedBox(fit: BoxFit.scaleDown, child: Text(tk(bal), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Colors.deepOrange)))),
            ])),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 0, children: [
          if (mobile && ph.isNotEmpty) ActionChip(avatar: const Icon(Icons.call, size: 18), label: const Text('কল'), onPressed: () => openUrl(c, 'tel:$ph')),
          if (phoneIntl(ph).isNotEmpty) ActionChip(avatar: const Icon(Icons.chat, size: 18), label: const Text('WhatsApp'), onPressed: () => openUrl(c, waUrl(ph, msg))),
          if (mobile && ph.isNotEmpty) ActionChip(avatar: const Icon(Icons.sms, size: 18), label: const Text('SMS'), onPressed: () => openUrl(c, smsUrl(ph, msg))),
          ActionChip(avatar: const Icon(Icons.update, size: 18), label: const Text('+১ দিন'), onPressed: () => snooze(c, d)),
          ActionChip(avatar: const Icon(Icons.check, size: 18), label: const Text('তাগাদা শেষ'), onPressed: () => d.reference.update({'due': null})),
        ]),
      ])));
}

class DuePage extends StatelessWidget {
  const DuePage({super.key});
  @override
  Widget build(BuildContext c) => withCust((c, docs) {
        final now = DateTime.now();
        final tomorrow = DateTime(now.year, now.month, now.day + 1);
        final l = docs.where((d) => dtOf(d.data(), 'due') != null && numOf(d.data(), 'balance') > 0).toList()
          ..sort((a, b) => dtOf(a.data(), 'due')!.compareTo(dtOf(b.data(), 'due')!));
        if (l.isEmpty) {
          return const Center(child: Padding(padding: EdgeInsets.all(24), child: Text('কোনো তাগাদা সেট করা নেই\nকাস্টমার খুলে "তাগাদা সেট" করুন', textAlign: TextAlign.center)));
        }
        final overdue = l.where((d) => dtOf(d.data(), 'due')!.isBefore(now)).toList();
        final today = l.where((d) {
          final x = dtOf(d.data(), 'due')!;
          return !x.isBefore(now) && x.isBefore(tomorrow);
        }).toList();
        final later = l.where((d) => !dtOf(d.data(), 'due')!.isBefore(tomorrow)).toList();
        final items = <Object>[];
        void sec(String t, List<Doc> x) {
          if (x.isNotEmpty) {
            items.add(t);
            items.addAll(x);
          }
        }

        sec('⚠ সময় পার হয়েছে (${overdue.length})', overdue);
        sec('📅 আজ (${today.length})', today);
        sec('🗓 আসছে (${later.length})', later);
        return ListView.builder(
            padding: const EdgeInsets.only(top: 6, bottom: 24),
            itemCount: items.length,
            itemBuilder: (c, i) {
              final x = items[i];
              if (x is String) return Padding(padding: const EdgeInsets.fromLTRB(18, 12, 18, 4), child: Text(x, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)));
              return dueCard(c, x as Doc);
            });
      });
}

// ───────── কাস্টমার যোগ / এডিট ─────────
void customerForm(BuildContext c, {String? editId, Map<String, dynamic>? data}) {
  final m = data ?? <String, dynamic>{};
  final n = TextEditingController(text: str(m, 'name'));
  final p = TextEditingController(text: str(m, 'phone'));
  final v = TextEditingController(text: str(m, 'village'));
  final nt = TextEditingController(text: str(m, 'note'));
  final o = TextEditingController();
  String? err;
  var warned = false;
  Widget f(TextEditingController t, String l, {TextInputType? kb, List<TextInputFormatter>? fmt}) =>
      Padding(padding: const EdgeInsets.only(bottom: 10), child: TextField(controller: t, keyboardType: kb, inputFormatters: fmt, decoration: deco(label: l)));
  showModalBottomSheet(
      context: c,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (ctx) => StatefulBuilder(
          builder: (ctx, setS) => Padding(
              padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 20),
              child: SingleChildScrollView(
                  child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(editId == null ? 'নতুন কাস্টমার' : 'কাস্টমার এডিট', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                const SizedBox(height: 14),
                f(n, 'নাম *'),
                f(p, 'মোবাইল (ঐচ্ছিক)', kb: TextInputType.phone),
                f(v, 'গ্রাম / ভাগ (ঐচ্ছিক)'),
                if (editId == null) f(o, 'পুরনো বাকি (ঐচ্ছিক)', kb: numKb, fmt: amtFmt),
                f(nt, 'নোট (ঐচ্ছিক)'),
                if (err != null) Padding(padding: const EdgeInsets.only(bottom: 10), child: Text(err!, style: const TextStyle(color: Colors.red))),
                SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: FilledButton(
                        onPressed: () {
                          final name = n.text.trim();
                          if (name.isEmpty) {
                            setS(() => err = 'নাম লিখুন');
                            return;
                          }
                          final dup = custDocs.value.any((d) => d.id != editId && str(d.data(), 'name').toLowerCase() == name.toLowerCase() && str(d.data(), 'village').toLowerCase() == v.text.trim().toLowerCase());
                          if (dup && !warned) {
                            warned = true;
                            setS(() => err = 'এই নাম ও গ্রামের কাস্টমার আগে থেকেই আছে। তবুও সংরক্ষণ করতে আবার চাপুন।');
                            return;
                          }
                          if (editId != null) {
                            fire(cust.doc(editId).update({'name': name, 'phone': p.text.trim(), 'village': v.text.trim(), 'note': nt.text.trim()}));
                          } else {
                            final r = cust.doc();
                            fire(r.set(newCust(name, p.text.trim(), v.text.trim(), nt.text.trim())));
                            final amt = parseAmt(o.text);
                            if (amt != null && amt > 0) addEntry(r.id, amt, 'পুরনো বাকি', name: name);
                          }
                          Navigator.pop(ctx);
                        },
                        child: const Text('সংরক্ষণ'))),
              ])))));
}

// ───────── লেনদেন এন্ট্রি ─────────
Future<void> entryDialog(BuildContext c, String id, bool baki, {num bal = 0, String name = ''}) async {
  final a = TextEditingController(), n = TextEditingController();
  String? err;
  final ok = await showDialog<bool>(
      context: c,
      builder: (x) => StatefulBuilder(
          builder: (x, setS) => AlertDialog(
                title: Text(baki ? 'বাকি দিলাম' : 'জমা নিলাম'),
                content: SingleChildScrollView(
                    child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                  TextField(controller: a, autofocus: true, keyboardType: numKb, inputFormatters: amtFmt, decoration: deco(label: 'টাকার পরিমাণ', err: err)),
                  if (!baki && bal > 0) Align(alignment: Alignment.centerLeft, child: TextButton(onPressed: () => a.text = plain(bal), child: Text('পুরো বাকি ${tk(bal)}'))),
                  const SizedBox(height: 8),
                  TextField(controller: n, decoration: deco(label: 'নোট (ঐচ্ছিক)')),
                ])),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(x, false), child: const Text('বাতিল')),
                  FilledButton(
                      onPressed: () {
                        final v = parseAmt(a.text);
                        if (v == null || v <= 0) {
                          setS(() => err = 'সঠিক টাকার পরিমাণ লিখুন');
                          return;
                        }
                        Navigator.pop(x, true);
                      },
                      child: const Text('সংরক্ষণ')),
                ],
              )));
  final v = parseAmt(a.text);
  if (ok == true && v != null && v > 0) addEntry(id, baki ? v : -v, n.text.trim(), name: name);
}

// ───────── কাস্টমারের বিস্তারিত ─────────
class Detail extends StatefulWidget {
  final String id;
  const Detail(this.id, {super.key});
  @override
  State<Detail> createState() => _DetailState();
}

class _DetailState extends State<Detail> {
  String get id => widget.id;
  late final Stream<DocumentSnapshot<Map<String, dynamic>>> st = cust.doc(widget.id).snapshots();
  late final Stream<QuerySnapshot<Map<String, dynamic>>> es = cust.doc(widget.id).collection('entries').orderBy('date', descending: true).limit(300).snapshots();

  Future<void> setDue(DateTime? cur) async {
    final now = DateTime.now();
    final init = (cur != null && cur.isAfter(now)) ? cur : now;
    final d = await showDatePicker(context: context, firstDate: DateTime(now.year, now.month, now.day), lastDate: now.add(const Duration(days: 730)), initialDate: init);
    if (d == null || !mounted) return;
    final t = await showTimePicker(context: context, initialTime: TimeOfDay(hour: cur?.hour ?? 17, minute: cur?.minute ?? 0));
    if (t == null || !mounted) return;
    final due = DateTime(d.year, d.month, d.day, t.hour, t.minute);
    if (due.isBefore(DateTime.now())) {
      toast(context, 'এই সময় পার হয়ে গেছে, ভবিষ্যতের সময় দিন');
      return;
    }
    cust.doc(id).update({'due': Timestamp.fromDate(due)});
  }

  Future<void> del(String name) async {
    final ok = await showDialog<bool>(
        context: context,
        builder: (x) => AlertDialog(
                title: const Text('কাস্টমার মুছবেন?'),
                content: Text('$name এবং তার সব হিসাব মুছে যাবে। এটা আর ফেরানো যাবে না।'),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(x, false), child: const Text('না')),
                  FilledButton(style: FilledButton.styleFrom(backgroundColor: Colors.red), onPressed: () => Navigator.pop(x, true), child: const Text('হ্যাঁ, মুছুন')),
                ]));
    if (ok == true && mounted) {
      final nav = Navigator.of(context);
      unawaited(deleteCustomer(id));
      nav.pop();
    }
  }

  Future<void> delEntry(DocumentSnapshot<Map<String, dynamic>> e) async {
    final ok = await showDialog<bool>(
        context: context,
        builder: (x) => AlertDialog(
                title: const Text('এই লেনদেন মুছবেন?'),
                content: const Text('মুছলে বাকির হিসাব আগের অবস্থায় ফিরে যাবে।'),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(x, false), child: const Text('না')),
                  FilledButton(onPressed: () => Navigator.pop(x, true), child: const Text('মুছুন')),
                ]));
    if (ok == true) deleteEntry(id, e);
  }

  Widget info(IconData i, String t) => Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(i, size: 18, color: Colors.black54),
        const SizedBox(width: 8),
        Expanded(child: Text(t)),
      ]));

  @override
  Widget build(BuildContext c) => StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: st,
      builder: (c, s) {
        if (s.hasError) return Scaffold(appBar: AppBar(), body: const Center(child: Text('লোড করা যায়নি')));
        final m = s.data?.data();
        if (m == null) {
          return Scaffold(appBar: AppBar(), body: Center(child: s.connectionState == ConnectionState.waiting ? const CircularProgressIndicator() : const Text('কাস্টমার পাওয়া যায়নি')));
        }
        final name = str(m, 'name');
        final bal = numOf(m, 'balance');
        final due = dtOf(m, 'due');
        final phone = str(m, 'phone');
        final village = str(m, 'village');
        final note = str(m, 'note');
        final ph = phoneRaw(phone);
        final msg = dueMsg(m);
        return Scaffold(
          appBar: AppBar(title: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis), actions: [
            IconButton(icon: const Icon(Icons.edit_outlined), tooltip: 'এডিট', onPressed: () => customerForm(context, editId: id, data: m)),
            IconButton(icon: const Icon(Icons.delete_outline), tooltip: 'মুছুন', onPressed: () => del(name)),
          ]),
          body: ListView(padding: const EdgeInsets.only(bottom: 30), children: [
            card(Padding(
                padding: const EdgeInsets.all(18),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(bal < 0 ? 'অগ্রিম জমা আছে' : 'বর্তমান বাকি', style: TextStyle(color: Colors.grey.shade600)),
                  FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(tk(bal.abs()), style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800, color: bal > 0 ? Colors.deepOrange : Colors.green))),
                  const SizedBox(height: 6),
                  if (village.isNotEmpty) info(Icons.place_outlined, village),
                  if (phone.isNotEmpty) info(Icons.phone_outlined, phone),
                  if (note.isNotEmpty) info(Icons.notes, note),
                  if (phone.isNotEmpty)
                    Padding(
                        padding: const EdgeInsets.only(top: 6),
                        child: Wrap(spacing: 8, runSpacing: 4, children: [
                          if (mobile) OutlinedButton.icon(onPressed: () => openUrl(context, 'tel:$ph'), icon: const Icon(Icons.call, size: 18), label: const Text('কল')),
                          if (mobile) OutlinedButton.icon(onPressed: () => openUrl(context, smsUrl(ph, msg)), icon: const Icon(Icons.sms, size: 18), label: const Text('SMS')),
                          if (phoneIntl(ph).isNotEmpty) OutlinedButton.icon(onPressed: () => openUrl(context, waUrl(ph, msg)), icon: const Icon(Icons.chat, size: 18), label: const Text('WhatsApp')),
                        ])),
                  const Divider(height: 24),
                  Text(due == null ? 'তাগাদার সময় সেট নেই' : '⏰ ${dt(due)}', style: const TextStyle(fontWeight: FontWeight.w600)),
                  Wrap(spacing: 8, children: [
                    TextButton.icon(onPressed: () => setDue(due), icon: const Icon(Icons.alarm_add), label: Text(due == null ? 'তাগাদা সেট' : 'সময় বদলান')),
                    if (due != null) TextButton.icon(onPressed: () => cust.doc(id).update({'due': null}), icon: const Icon(Icons.close), label: const Text('তাগাদা মুছুন')),
                  ]),
                ]))),
            Padding(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                child: Row(children: [
                  Expanded(child: FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: Colors.deepOrange, minimumSize: const Size(0, 50)), onPressed: () => entryDialog(context, id, true, bal: bal, name: name), icon: const Icon(Icons.add), label: const Text('বাকি দিলাম'))),
                  const SizedBox(width: 10),
                  Expanded(child: FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: Colors.green, minimumSize: const Size(0, 50)), onPressed: () => entryDialog(context, id, false, bal: bal, name: name), icon: const Icon(Icons.remove), label: const Text('জমা নিলাম'))),
                ])),
            const Padding(padding: EdgeInsets.fromLTRB(18, 14, 18, 4), child: Text('লেনদেনের ইতিহাস', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
            StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                stream: es,
                builder: (c, e) {
                  final docs = e.data?.docs ?? <QueryDocumentSnapshot<Map<String, dynamic>>>[];
                  if (e.connectionState == ConnectionState.waiting && docs.isEmpty) return const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator()));
                  if (docs.isEmpty) return const Padding(padding: EdgeInsets.all(24), child: Center(child: Text('এখনো কোনো লেনদেন নেই', style: TextStyle(color: Colors.black54))));
                  num given = 0, got = 0;
                  for (final x in docs) {
                    final a = numOf(x.data(), 'amount');
                    if (a > 0) {
                      given += a;
                    } else {
                      got += -a;
                    }
                  }
                  return Column(children: [
                    Padding(padding: const EdgeInsets.fromLTRB(18, 0, 18, 6), child: Align(alignment: Alignment.centerLeft, child: Text('মোট বাকি দিয়েছি ${tk(given)} • মোট জমা নিয়েছি ${tk(got)}', style: const TextStyle(color: Colors.black54, fontSize: 13)))),
                    for (final x in docs) entryTile(x),
                  ]);
                }),
          ]),
        );
      });

  Widget entryTile(QueryDocumentSnapshot<Map<String, dynamic>> x) {
    final m = x.data();
    final a = numOf(m, 'amount');
    final d = dtOf(m, 'date');
    final nt = str(m, 'note');
    return card(ListTile(
      leading: Icon(a > 0 ? Icons.north_east : Icons.south_west, color: a > 0 ? Colors.deepOrange : Colors.green),
      title: Text('${a > 0 ? 'বাকি' : 'জমা'}  ${tk(a.abs())}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Text([if (d != null) dt(d), if (nt.isNotEmpty) nt].join('\n'), maxLines: 3, overflow: TextOverflow.ellipsis),
      trailing: IconButton(icon: const Icon(Icons.delete_outline, size: 20), tooltip: 'মুছুন', onPressed: () => delEntry(x)),
    ));
  }
}

// ───────── Report PDF (পেজ ভাগ করা, কিছু কাটা পড়ে না) ─────────
class _RR {
  final bool head, over;
  final String name, phone, due, amt;
  final double h;
  _RR({required this.head, this.over = false, this.name = '', this.phone = '', this.due = '', this.amt = '', required this.h});
}

const double _pw = 595, _ph = 842, _pm = 28, _foot = 22;

class ReportPage extends StatefulWidget {
  const ReportPage({super.key});
  @override
  State<ReportPage> createState() => _RPState();
}

class _RPState extends State<ReportPage> {
  final _keys = <GlobalKey>[];
  bool busy = false;

  Future<void> makePdf() async {
    setState(() => busy = true);
    try {
      final doc = pw.Document();
      for (final k in _keys) {
        final b = k.currentContext?.findRenderObject() as RenderRepaintBoundary?;
        if (b == null) continue;
        final img = await b.toImage(pixelRatio: 2.2);
        final bd = await img.toByteData(format: ui.ImageByteFormat.png);
        if (bd == null) continue;
        final bytes = bd.buffer.asUint8List();
        doc.addPage(pw.Page(pageFormat: PdfPageFormat.a4, margin: pw.EdgeInsets.zero, build: (_) => pw.Image(pw.MemoryImage(bytes), fit: pw.BoxFit.fill)));
      }
      final data = await doc.save();
      if (Platform.isWindows) {
        final dir = await getDownloadsDirectory() ?? await getTemporaryDirectory();
        final f = File('${dir.path}/baki-report-${DateTime.now().millisecondsSinceEpoch}.pdf');
        await f.writeAsBytes(data);
        await OpenFilex.open(f.path);
      } else {
        await Printing.sharePdf(bytes: data, filename: 'baki-report.pdf');
      }
    } catch (_) {
      if (mounted) toast(context, 'PDF তৈরি করা যায়নি, আবার চেষ্টা করুন');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Widget rowW(_RR r) {
    if (r.head) {
      return Container(
          height: r.h - 8,
          margin: const EdgeInsets.only(top: 8),
          padding: const EdgeInsets.symmetric(horizontal: 8),
          color: const Color(0xFFE8F5E9),
          child: Row(children: [
            Expanded(child: Text(r.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14, height: 1.3, fontWeight: FontWeight.w800, color: Colors.black))),
            Text(r.amt, maxLines: 1, style: const TextStyle(fontSize: 14, height: 1.3, fontWeight: FontWeight.w800, color: Colors.black)),
          ]));
    }
    return SizedBox(
        height: r.h,
        child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 4),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(r.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14, height: 1.4, fontWeight: FontWeight.w700, color: Colors.black)),
                if (r.phone.isNotEmpty) Text(r.phone, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, height: 1.4, color: Colors.black54)),
                if (r.due.isNotEmpty) Text(r.due, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, height: 1.4, color: r.over ? Colors.red : Colors.black54)),
              ])),
              const SizedBox(width: 8),
              Text(r.amt, maxLines: 1, style: const TextStyle(fontSize: 14, height: 1.4, fontWeight: FontWeight.w800, color: Colors.black)),
            ])));
  }

  Widget pageW(int i, int n, List<_RR> rows, {required bool first, required bool last, required num total, required DateTime now}) => ClipRect(
      child: Container(
          width: _pw,
          height: _ph,
          color: Colors.white,
          padding: const EdgeInsets.all(_pm),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (first) ...[
              SizedBox(
                  height: 58,
                  child: Row(children: [
                    Image.asset('assets/logo.png', width: 54, height: 54),
                    const SizedBox(width: 12),
                    Expanded(
                        child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(shop.value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 18, height: 1.3, fontWeight: FontWeight.w800, color: Colors.black)),
                      Text('বাকির রিপোর্ট • ${dt(now)}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, height: 1.3, color: Colors.black54)),
                    ])),
                  ])),
              const SizedBox(height: 24, child: Divider(color: Colors.black26)),
            ],
            for (final r in rows) rowW(r),
            if (last)
              SizedBox(
                  height: 44,
                  child: Column(children: [
                    const Divider(height: 4, color: Colors.black26),
                    Expanded(
                        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      const Text('সর্বমোট বাকি', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: Colors.black)),
                      Text(tk(total), style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: Colors.deepOrange)),
                    ])),
                  ])),
            const Spacer(),
            SizedBox(height: _foot, child: Align(alignment: Alignment.centerRight, child: Text('পৃষ্ঠা ${i + 1} / $n', style: const TextStyle(fontSize: 11, color: Colors.black45)))),
          ])));

  @override
  Widget build(BuildContext c) => withCust((c, docs) {
        final now = DateTime.now();
        final l = docs.where((d) => numOf(d.data(), 'balance') > 0).toList();
        if (l.isEmpty) return const Center(child: Text('কোনো বাকি নেই — রিপোর্টের কিছু নেই 🎉'));
        l.sort((a, b) => str(a.data(), 'name').toLowerCase().compareTo(str(b.data(), 'name').toLowerCase()));
        final g = <String, List<Doc>>{};
        for (final d in l) {
          final v = str(d.data(), 'village');
          g.putIfAbsent(v.isEmpty ? 'অন্যান্য' : v, () => []).add(d);
        }
        final names = g.keys.toList()..sort((a, b) => a == 'অন্যান্য' ? 1 : b == 'অন্যান্য' ? -1 : a.compareTo(b));
        final total = l.fold<num>(0, (a, d) => a + numOf(d.data(), 'balance'));
        final rows = <_RR>[];
        for (final k in names) {
          final list = g[k]!;
          rows.add(_RR(head: true, name: '$k  (${list.length} জন)', amt: tk(list.fold<num>(0, (a, d) => a + numOf(d.data(), 'balance'))), h: 34));
          for (final d in list) {
            final m = d.data();
            final due = dtOf(m, 'due');
            final over = due != null && due.isBefore(now);
            final ph = str(m, 'phone');
            final dueTxt = due == null ? '' : (over ? '⚠ সময় পার হয়েছে: ${dt(due)}' : 'দেওয়ার কথা: ${dt(due)}');
            rows.add(_RR(head: false, name: str(m, 'name'), phone: ph, due: dueTxt, over: over, amt: tk(numOf(m, 'balance')), h: 28 + (ph.isNotEmpty ? 17 : 0) + (dueTxt.isNotEmpty ? 17 : 0)));
          }
        }
        const cap = _ph - 2 * _pm - _foot;
        final pages = <List<_RR>>[[]];
        var used = 82.0;
        for (final r in rows) {
          final need = r.head ? r.h + 34 : r.h;
          if (used + need > cap && pages.last.isNotEmpty) {
            pages.add([]);
            used = 0;
          }
          pages.last.add(r);
          used += r.h;
        }
        if (used + 44 > cap) pages.add([]);
        while (_keys.length < pages.length) {
          _keys.add(GlobalKey());
        }
        return Column(children: [
          Expanded(
              child: LayoutBuilder(
                  builder: (c, bc) {
                    final sc = ((bc.maxWidth - 24) / _pw).clamp(0.3, 1.6).toDouble();
                    return SingleChildScrollView(
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        child: Column(children: [
                          for (var i = 0; i < pages.length; i++)
                            Padding(
                                padding: const EdgeInsets.symmetric(vertical: 6),
                                child: Container(
                                    decoration: const BoxDecoration(boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 6)]),
                                    width: _pw * sc,
                                    height: _ph * sc,
                                    child: FittedBox(
                                        fit: BoxFit.contain,
                                        child: RepaintBoundary(key: _keys[i], child: pageW(i, pages.length, pages[i], first: i == 0, last: i == pages.length - 1, total: total, now: now))))),
                        ]));
                  })),
          Padding(
              padding: const EdgeInsets.all(12),
              child: SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: FilledButton.icon(
                      onPressed: busy ? null : makePdf,
                      icon: busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.picture_as_pdf),
                      label: Text(Platform.isWindows ? 'PDF সেভ করুন' : 'PDF তৈরি / শেয়ার করুন')))),
        ]);
      });
}

// ───────── Settings ─────────
class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SPState();
}

class _SPState extends State<SettingsPage> {
  late final n = TextEditingController(text: shop.value);
  String ver = '';
  static const colors = [0xFF2E7D32, 0xFF1565C0, 0xFF6A1B9A, 0xFFC62828, 0xFFEF6C00, 0xFF00695C];
  @override
  void initState() {
    super.initState();
    PackageInfo.fromPlatform().then((p) {
      if (mounted) setState(() => ver = p.version);
    }).catchError((_) {});
  }

  @override
  void dispose() {
    n.dispose();
    super.dispose();
  }

  void save(Map<String, dynamic> m) => fire(me.collection('meta').doc('settings').set(m, SetOptions(merge: true)));
  void saveShop() {
    final v = n.text.trim();
    if (v.isEmpty) {
      toast(context, 'দোকানের নাম খালি রাখা যাবে না');
      return;
    }
    shop.value = v;
    save({'shop': v});
    FocusScope.of(context).unfocus();
    toast(context, 'নাম সংরক্ষণ হয়েছে');
  }

  @override
  Widget build(BuildContext c) {
    final email = FirebaseAuth.instance.currentUser?.email ?? '';
    return Scaffold(
        appBar: AppBar(title: const Text('সেটিংস')),
        body: ListView(padding: const EdgeInsets.all(18), children: [
          TextField(controller: n, onSubmitted: (_) => saveShop(), decoration: deco(label: 'দোকানের নাম', suffix: IconButton(icon: const Icon(Icons.check), onPressed: saveShop))),
          const SizedBox(height: 22),
          const Text('থিমের রঙ', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          ValueListenableBuilder<int>(
              valueListenable: seed,
              builder: (_, cur, __) => Wrap(spacing: 12, runSpacing: 12, children: [
                    for (final k in colors)
                      GestureDetector(
                          onTap: () {
                            seed.value = k;
                            save({'seed': k});
                          },
                          child: CircleAvatar(radius: 22, backgroundColor: Color(k), child: cur == k ? const Icon(Icons.check, color: Colors.white) : null))
                  ])),
          const SizedBox(height: 16),
          if (email.isNotEmpty) ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.account_circle_outlined), title: const Text('লগইন একাউন্ট'), subtitle: Text(email, maxLines: 1, overflow: TextOverflow.ellipsis)),
          if (email.isNotEmpty)
            ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.password),
                title: const Text('পাসওয়ার্ড বদলান'),
                subtitle: const Text('ইমেইলে রিসেট লিংক যাবে'),
                onTap: () async {
                  try {
                    await FirebaseAuth.instance.sendPasswordResetEmail(email: email);
                    if (c.mounted) toast(c, 'রিসেট লিংক ইমেইলে পাঠানো হয়েছে');
                  } catch (_) {
                    if (c.mounted) toast(c, 'পাঠানো যায়নি, ইন্টারনেট দেখুন');
                  }
                }),
          if (Platform.isAndroid) ...[
            ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.notifications_active_outlined),
                title: const Text('নোটিফিকেশনের অনুমতি'),
                onTap: () async {
                  try {
                    await Permission.notification.request();
                  } catch (_) {}
                  reschedule();
                }),
            ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.alarm_on),
                title: const Text('সঠিক সময়ের অ্যালার্ম ও ব্যাটারি ছাড়'),
                subtitle: const Text('সেটিংস পেজ খুলবে, অনুমতি দিয়ে ব্যাক করুন'),
                onTap: () async {
                  await askAlarmPerms();
                  reschedule();
                }),
          ],
          ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.system_update_alt), title: const Text('নতুন আপডেট খুঁজুন'), subtitle: Text(ver.isEmpty ? '' : 'বর্তমান সংস্করণ $ver'), onTap: () => checkUpdate(c)),
          ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.bug_report_outlined), title: const Text('ত্রুটির লগ'), subtitle: const Text('অ্যাপে সমস্যা হলে এখান থেকে কপি করে পাঠান'), onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const CrashLogPage()))),
          ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.logout, color: Colors.red), title: const Text('লগআউট'), onTap: () => doLogout(c)),
        ]));
  }
}

// ───────── In-app updater (GitHub Releases) ─────────
bool newer(String a, String b) {
  final x = a.split('.').map((e) => int.tryParse(e) ?? 0).toList(), y = b.split('.').map((e) => int.tryParse(e) ?? 0).toList();
  for (var i = 0; i < 3; i++) {
    final p = i < x.length ? x[i] : 0, q = i < y.length ? y[i] : 0;
    if (p != q) return p > q;
  }
  return false;
}

Future<void> checkUpdate(BuildContext c, {bool silent = false}) async {
  void snack(String s) {
    if (!silent && c.mounted) toast(c, s);
  }

  if (Platform.isIOS) {
    snack('iPhone এ আপডেট নিজে ইনস্টল করতে হবে');
    return;
  }
  var dialogOpen = false;
  final client = http.Client();
  try {
    final r = await client.get(Uri.parse('https://api.github.com/repos/$kRepo/releases/latest')).timeout(const Duration(seconds: 15));
    if (r.statusCode != 200) {
      snack('আপডেটের তথ্য পাওয়া যায়নি');
      return;
    }
    final j = jsonDecode(r.body);
    final tag = '${j['tag_name']}'.replaceFirst('v', '');
    final cur = (await PackageInfo.fromPlatform()).version;
    if (!newer(tag, cur)) {
      snack('আপনার অ্যাপ আপ-টু-ডেট ($cur)');
      return;
    }
    final ext = Platform.isAndroid ? '.apk' : '.zip';
    final assets = ((j['assets'] as List?) ?? []).cast<Map>();
    final asset = assets.firstWhere((a) => '${a['name']}'.endsWith(ext), orElse: () => {});
    if (asset.isEmpty) {
      snack('নতুন ভার্সন তৈরি হচ্ছে, একটু পরে চেষ্টা করুন');
      return;
    }
    if (!c.mounted) return;
    final ok = await showDialog<bool>(
        context: c,
        builder: (x) => AlertDialog(title: Text('নতুন আপডেট $tag'), content: const Text('আপডেট ডাউনলোড করে ইনস্টল করবেন?'), actions: [
              TextButton(onPressed: () => Navigator.pop(x, false), child: const Text('পরে')),
              FilledButton(onPressed: () => Navigator.pop(x, true), child: const Text('আপডেট করুন')),
            ]));
    if (ok != true || !c.mounted) return;
    final prog = ValueNotifier<double>(0);
    dialogOpen = true;
    showDialog(
        context: c,
        barrierDismissible: false,
        builder: (_) => AlertDialog(
            title: const Text('ডাউনলোড হচ্ছে...'),
            content: ValueListenableBuilder<double>(valueListenable: prog, builder: (_, v, __) => LinearProgressIndicator(value: v > 0 ? v : null))));
    final res = await client.send(http.Request('GET', Uri.parse('${asset['browser_download_url']}')));
    final f = File('${(await getTemporaryDirectory()).path}/${asset['name']}');
    final sink = f.openWrite();
    var got = 0;
    final total = res.contentLength ?? 0;
    await for (final ch in res.stream) {
      sink.add(ch);
      got += ch.length;
      if (total > 0) prog.value = got / total;
    }
    await sink.close();
    if (dialogOpen && c.mounted) Navigator.of(c).pop();
    dialogOpen = false;
    if (Platform.isAndroid) await Permission.requestInstallPackages.request();
    await OpenFilex.open(f.path);
  } catch (_) {
    if (dialogOpen && c.mounted) {
      Navigator.of(c).pop();
      dialogOpen = false;
    }
    snack('আপডেট চেক করা যায়নি (ইন্টারনেট দেখুন)');
  } finally {
    client.close();
  }
}

// ───────── Daily tasks ─────────
class TasksPage extends StatefulWidget {
  const TasksPage({super.key});
  @override
  State<TasksPage> createState() => _TPState();
}

class _TPState extends State<TasksPage> {
  final t = TextEditingController();
  late final Stream<QuerySnapshot<Map<String, dynamic>>> st = tasks.orderBy('createdAt', descending: true).snapshots();
  @override
  void dispose() {
    t.dispose();
    super.dispose();
  }

  void add([String? s]) {
    final v = (s ?? t.text).trim();
    if (v.isEmpty) return;
    fire(tasks.add({'title': v, 'done': false, 'createdAt': Timestamp.now()}).then((_) {}));
    t.clear();
  }

  @override
  Widget build(BuildContext c) => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: st,
      builder: (c, s) {
        final l = [...?s.data?.docs]..sort((a, b) {
            final x = a.data()['done'] == true, y = b.data()['done'] == true;
            return x == y ? 0 : (x ? 1 : -1);
          });
        return ListView(padding: const EdgeInsets.only(bottom: 24), children: [
          Padding(
              padding: const EdgeInsets.fromLTRB(14, 14, 14, 6),
              child: TextField(controller: t, onSubmitted: (_) => add(), decoration: deco(hint: 'আজকের কাজ লিখুন...', filled: true, suffix: IconButton(icon: const Icon(Icons.add_circle), onPressed: () => add())))),
          SizedBox(
              height: 46,
              child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12), children: [
                for (final x in ['তাগাদা করা', 'মাল অর্ডার', 'দোকানের বিল', 'ব্যাংকে জমা', 'ফটোকপি/প্রিন্টের হিসাব'])
                  Padding(padding: const EdgeInsets.only(right: 8), child: ActionChip(label: Text(x), onPressed: () => add(x)))
              ])),
          if (l.isEmpty) const Padding(padding: EdgeInsets.all(40), child: Center(child: Text('কোনো কাজ নেই', style: TextStyle(color: Colors.black54)))),
          for (final d in l)
            Dismissible(
                key: ValueKey(d.id),
                onDismissed: (_) {
                  final data = d.data();
                  d.reference.delete();
                  final m = ScaffoldMessenger.of(c);
                  m.hideCurrentSnackBar();
                  m.showSnackBar(SnackBar(content: const Text('কাজ মুছে গেছে'), action: SnackBarAction(label: 'ফিরিয়ে আনুন', onPressed: () => d.reference.set(data))));
                },
                background: Container(color: Colors.red.shade100, alignment: Alignment.centerLeft, padding: const EdgeInsets.only(left: 20), child: const Icon(Icons.delete_outline)),
                secondaryBackground: Container(color: Colors.red.shade100, alignment: Alignment.centerRight, padding: const EdgeInsets.only(right: 20), child: const Icon(Icons.delete_outline)),
                child: card(CheckboxListTile(
                    value: d.data()['done'] == true,
                    onChanged: (v) => d.reference.update({'done': v ?? false}),
                    title: Text(str(d.data(), 'title'), style: TextStyle(decoration: d.data()['done'] == true ? TextDecoration.lineThrough : null))))),
        ]);
      });
}

// ───────── Windows ছোট উইজেট ─────────
class MiniPage extends StatefulWidget {
  const MiniPage({super.key});
  @override
  State<MiniPage> createState() => _MPState();
}

class _MPState extends State<MiniPage> {
  @override
  void initState() {
    super.initState();
    windowManager.setSize(const Size(340, 520));
    windowManager.setAlwaysOnTop(true);
  }

  @override
  void dispose() {
    windowManager.setAlwaysOnTop(false);
    windowManager.setSize(const Size(1100, 760));
    super.dispose();
  }

  @override
  Widget build(BuildContext c) => Scaffold(
      appBar: AppBar(title: const Text('বাকি উইজেট'), toolbarHeight: 46),
      body: withCust((c, docs) {
        final l = docs.where((d) => numOf(d.data(), 'balance') > 0).toList()..sort((a, b) => numOf(b.data(), 'balance').compareTo(numOf(a.data(), 'balance')));
        final total = l.fold<num>(0, (a, d) => a + numOf(d.data(), 'balance'));
        return Column(children: [
          Container(
              width: double.infinity,
              margin: const EdgeInsets.all(10),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), gradient: LinearGradient(colors: [Theme.of(c).colorScheme.primary, Theme.of(c).colorScheme.tertiary])),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('মোট বাকি', style: TextStyle(color: Colors.white70)),
                FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(tk(total), style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w800))),
                Text('${l.length} জন', style: const TextStyle(color: Colors.white70)),
              ])),
          Expanded(
              child: ListView.builder(
                  itemCount: l.length,
                  itemBuilder: (c, i) {
                    final m = l[i].data();
                    final due = dtOf(m, 'due');
                    return ListTile(
                        dense: true,
                        onTap: () => openDetail(c, l[i].id),
                        title: Text(str(m, 'name'), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
                        subtitle: due == null ? null : Text('⏰ ${dt(due)}', maxLines: 1, overflow: TextOverflow.ellipsis),
                        trailing: Text(tk(numOf(m, 'balance')), style: const TextStyle(fontWeight: FontWeight.w800, color: Colors.deepOrange)));
                  })),
        ]);
      }));
}
