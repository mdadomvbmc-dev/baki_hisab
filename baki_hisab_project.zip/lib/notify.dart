import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tzd;
import 'package:timezone/timezone.dart' as tz;
import 'bazar.dart';
import 'main.dart';

// ───────── নোটিফিকেশন চ্যানেল ─────────
const chDue = 'due_alarm_v2';
const chBazar = 'bazar_v1';
const chDaily = 'daily_v1';
const brandColor = Color(0xFF2E7D32);

int stableHash(String s) {
  var h = 7;
  for (final c in s.codeUnits) {
    h = (h * 131 + c) % 2147483647;
  }
  return h;
}

String mkPayload(Map<String, dynamic> m) => jsonEncode(m);
Map<String, dynamic> parsePayload(String? s) {
  try {
    final v = jsonDecode(s ?? '');
    return v is Map<String, dynamic> ? v : <String, dynamic>{};
  } catch (_) {
    return <String, dynamic>{};
  }
}

AndroidNotificationDetails dueAndroid(String big, bool loop) => AndroidNotificationDetails(
      chDue,
      'বাকি তাগাদা অ্যালার্ম',
      channelDescription: 'তাগাদার সময় হলে অ্যালার্ম বাজবে',
      importance: Importance.max,
      priority: Priority.max,
      fullScreenIntent: true,
      category: AndroidNotificationCategory.alarm,
      audioAttributesUsage: AudioAttributesUsage.alarm,
      visibility: NotificationVisibility.public,
      ongoing: loop,
      autoCancel: !loop,
      additionalFlags: loop ? Int32List.fromList(<int>[4]) : null,
      enableVibration: true,
      vibrationPattern: Int64List.fromList(<int>[0, 700, 400, 700, 400, 1000]),
      color: brandColor,
      ticker: 'তাগাদা',
      styleInformation: BigTextStyleInformation(big),
      actions: const <AndroidNotificationAction>[
        AndroidNotificationAction('stop', '⏹ বন্ধ করুন', cancelNotification: true),
        AndroidNotificationAction('snooze', '⏰ ১০ মিনিট পরে', cancelNotification: true),
      ],
    );

NotificationDetails dueDetails(String big, bool loop) => NotificationDetails(
    android: dueAndroid(big, loop), iOS: const DarwinNotificationDetails(presentAlert: true, presentSound: true, presentBadge: true));

NotificationDetails softDetails(String chId, String chName, String desc, String big) => NotificationDetails(
    android: AndroidNotificationDetails(chId, chName,
        channelDescription: desc,
        importance: Importance.high,
        priority: Priority.high,
        color: brandColor,
        styleInformation: BigTextStyleInformation(big)),
    iOS: const DarwinNotificationDetails(presentAlert: true, presentSound: true));

Future<void> _zs(int id, String title, String body, DateTime when, NotificationDetails nd, String payload, {DateTimeComponents? comps}) async {
  Future<void> go(AndroidScheduleMode m) => notif.zonedSchedule(id, title, body, tz.TZDateTime.from(when, tz.local), nd,
      androidScheduleMode: m,
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
      payload: payload,
      matchDateTimeComponents: comps);
  try {
    await go(AndroidScheduleMode.alarmClock);
  } catch (_) {
    try {
      await go(AndroidScheduleMode.inexactAllowWhileIdle);
    } catch (_) {}
  }
}

// ───────── শুরুতে সেটআপ ─────────
Future<void> initNotifications() async {
  tzd.initializeTimeZones();
  setLocalTz();
  await notif.initialize(
      const InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher'), iOS: DarwinInitializationSettings()),
      onDidReceiveNotificationResponse: onNotifResponse,
      onDidReceiveBackgroundNotificationResponse: notifBg);
}

// ব্যাকগ্রাউন্ডে অ্যাকশন বাটন (স্নুজ)
@pragma('vm:entry-point')
void notifBg(NotificationResponse r) async {
  if (r.actionId != 'snooze') return;
  try {
    tzd.initializeTimeZones();
    setLocalTz();
    await notif.initialize(const InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher')));
    await snoozeDue(parsePayload(r.payload));
  } catch (_) {}
}

Future<void> snoozeDue(Map<String, dynamic> p, {int minutes = 10}) async {
  final id = 500000 + (stableHash('${p['id']}') % 400000);
  final when = DateTime.now().add(Duration(minutes: minutes));
  final name = '${p['n'] ?? ''}';
  final a = p['a'];
  final amt = a is num ? a : 0;
  final big = '👤 $name\n💰 বাকি: ${tk(amt)}\n(স্নুজ করা তাগাদা)';
  await _zs(id, '⏰ তাগাদা: $name', '${tk(amt)} আদায় করতে হবে', when, dueDetails(big, loopAlarm.value), mkPayload({...p, 's': 1, 'nid': id}));
}

String _lastOpen = '';
DateTime _lastOpenAt = DateTime(2000);

void onNotifResponse(NotificationResponse r) {
  final p = parsePayload(r.payload);
  if (r.actionId == 'stop') return;
  if (r.actionId == 'snooze') {
    snoozeDue(p);
    return;
  }
  openFromPayload(p);
}

void openFromPayload(Map<String, dynamic> p) {
  if (FirebaseAuth.instance.currentUser == null) return;
  final nav = navKey.currentState;
  if (nav == null) return;
  final key = jsonEncode(p);
  if (key == _lastOpen && DateTime.now().difference(_lastOpenAt).inSeconds < 4) return;
  _lastOpen = key;
  _lastOpenAt = DateTime.now();
  final t = p['t'];
  if (t == 'due') {
    nav.push(MaterialPageRoute(builder: (_) => AlarmScreen(p)));
  } else if (t == 'bazar') {
    nav.push(MaterialPageRoute(builder: (_) => BazarDetail('${p['id']}')));
  }
}

// অ্যাপ বন্ধ থাকা অবস্থায় অ্যালার্ম/নোটিফিকেশন থেকে খুললে
Future<void> handleLaunch() async {
  if (!mobile) return;
  try {
    final d = await notif.getNotificationAppLaunchDetails();
    final r = d?.notificationResponse;
    if (d != null && d.didNotificationLaunchApp && r != null) onNotifResponse(r);
  } catch (_) {}
}

Future<void> cancelAllAlarms() async {
  if (!mobile) return;
  try {
    await notif.cancelAll();
  } catch (_) {}
  _lastSig = '';
}

// ───────── সব শিডিউল নতুন করে সাজানো ─────────
String _lastSig = '';
bool _rs = false, _rsAgain = false;

String _sig() {
  final b = StringBuffer();
  for (final d in custDocs.value) {
    final m = d.data();
    final due = dtOf(m, 'due');
    if (due != null && numOf(m, 'balance') > 0) b.write('${d.id}|${numOf(m, 'balance')}|${due.millisecondsSinceEpoch};');
  }
  b.write('#');
  for (final d in bazarDocs.value) {
    final m = d.data();
    final at = dtOf(m, 'remind');
    if (at != null) {
      final items = m['items'];
      final left = items is List ? items.where((e) => e is Map && e['d'] != true).length : 0;
      b.write('${d.id}|${at.millisecondsSinceEpoch}|$left;');
    }
  }
  b.write('#${loopAlarm.value}|${dailyOn.value}|${dailyH.value}|${dailyM.value}');
  return b.toString();
}

Future<void> reschedule({bool force = false}) async {
  if (!mobile) return;
  if (_rs) {
    _rsAgain = true;
    return;
  }
  _rs = true;
  try {
    do {
      _rsAgain = false;
      final sig = _sig();
      if (!force && sig == _lastSig) continue;
      _lastSig = sig;
      await _doAll();
    } while (_rsAgain);
  } finally {
    _rs = false;
  }
}

Future<void> _doAll() async {
  final now = DateTime.now();
  var pend = <PendingNotificationRequest>[];
  try {
    pend = await notif.pendingNotificationRequests();
  } catch (_) {}
  final live = <String, num>{};
  for (final d in custDocs.value) {
    live[d.id] = numOf(d.data(), 'balance');
  }
  for (final p in pend) {
    final m = parsePayload(p.payload);
    if (m['t'] == 'due' && m['s'] == 1) {
      final bal = live['${m['id']}'];
      if (bal == null || bal <= 0) {
        try {
          await notif.cancel(p.id);
        } catch (_) {}
      }
      continue;
    }
    try {
      await notif.cancel(p.id);
    } catch (_) {}
  }
  // তাগাদা অ্যালার্ম
  var i = 1;
  for (final d in custDocs.value) {
    if (i > 900) break;
    final m = d.data();
    final due = dtOf(m, 'due');
    final bal = numOf(m, 'balance');
    if (due == null || bal <= 0 || !due.isAfter(now)) continue;
    final name = str(m, 'name');
    final big = ['👤 $name', '💰 বাকি: ${tk(bal)}', if (str(m, 'village').isNotEmpty) '📍 ${str(m, 'village')}', if (str(m, 'phone').isNotEmpty) '📞 ${str(m, 'phone')}'].join('\n');
    await _zs(i, '⏰ তাগাদার সময়: $name', '${tk(bal)} আদায় করতে হবে', due, dueDetails(big, loopAlarm.value),
        mkPayload({'t': 'due', 'id': d.id, 'n': name, 'a': bal, 'ph': str(m, 'phone'), 'nid': i}));
    i++;
  }
  // বাজার তালিকার রিমাইন্ডার
  var j = 5000;
  for (final d in bazarDocs.value) {
    if (j > 5400) break;
    final m = d.data();
    final at = dtOf(m, 'remind');
    if (at == null || !at.isAfter(now)) continue;
    final raw = m['items'];
    final items = raw is List ? raw.whereType<Map>().toList() : <Map>[];
    final left = items.where((e) => e['d'] != true).toList();
    if (items.isNotEmpty && left.isEmpty) continue;
    final lines = left.take(15).map((e) {
      final q = '${e['q'] ?? ''}'.trim();
      return '• ${e['n']}${q.isEmpty ? '' : ' ($q)'}';
    }).toList();
    final big = left.isEmpty ? 'তালিকা এখনো খালি' : lines.join('\n') + (left.length > 15 ? '\n… আরও ${left.length - 15} টি' : '');
    await _zs(j, '🛒 বাজারের সময়: ${str(m, 'title')}', '${left.length} টি জিনিস কেনা বাকি', at,
        softDetails(chBazar, 'বাজার তালিকা রিমাইন্ডার', 'বাজারের সময় মনে করিয়ে দেবে', big), mkPayload({'t': 'bazar', 'id': d.id}));
    j++;
  }
  // দৈনিক হিসাব রিমাইন্ডার
  if (dailyOn.value) {
    final n = tz.TZDateTime.now(tz.local);
    var t = tz.TZDateTime(tz.local, n.year, n.month, n.day, dailyH.value, dailyM.value);
    if (!t.isAfter(n)) t = t.add(const Duration(days: 1));
    await _zs(9000, '📒 আজকের হিসাব মিলিয়ে নিন', 'আজকের বাকি, জমা ও খরচ খাতায় লিখেছেন তো?', t,
        softDetails(chDaily, 'দৈনিক হিসাব রিমাইন্ডার', 'প্রতিদিন নির্দিষ্ট সময়ে হিসাব মেলানোর কথা মনে করাবে', 'আজকের বাকি, জমা ও খরচ খাতায় লিখেছেন তো?\nদিন শেষে হিসাব মিলিয়ে নিন।'),
        mkPayload({'t': 'daily'}),
        comps: DateTimeComponents.time);
  }
}

// ১০ সেকেন্ড পরে টেস্ট অ্যালার্ম
Future<void> testAlarm() async {
  final when = DateTime.now().add(const Duration(seconds: 10));
  final p = {'t': 'due', 'id': 'test', 'n': 'টেস্ট কাস্টমার', 'a': 500, 'ph': '', 'nid': 8999};
  await _zs(8999, '⏰ টেস্ট অ্যালার্ম', 'এভাবেই তাগাদার অ্যালার্ম বাজবে', when, dueDetails('👤 টেস্ট কাস্টমার\n💰 বাকি: ${tk(500)}\nএটি একটি পরীক্ষামূলক অ্যালার্ম', loopAlarm.value), mkPayload(p));
}

// ───────── অ্যালার্ম স্ক্রিন ─────────
class AlarmScreen extends StatefulWidget {
  final Map<String, dynamic> p;
  const AlarmScreen(this.p, {super.key});
  @override
  State<AlarmScreen> createState() => _AlarmState();
}

class _AlarmState extends State<AlarmScreen> {
  Map<String, dynamic> get p => widget.p;
  int? get nid => p['nid'] is int ? p['nid'] as int : null;

  Future<void> stop() async {
    try {
      final n = nid;
      if (n != null) await notif.cancel(n);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext c) {
    final name = '${p['n'] ?? ''}';
    final a = p['a'];
    final amt = a is num ? a : 0;
    final ph = '${p['ph'] ?? ''}';
    final id = '${p['id'] ?? ''}';
    return Scaffold(
        backgroundColor: const Color(0xFF0F3D1A),
        body: SafeArea(
            child: Center(
                child: SingleChildScrollView(
                    padding: const EdgeInsets.all(24),
                    child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 420),
                        child: Column(mainAxisSize: MainAxisSize.min, children: [
                          const Icon(Icons.alarm_on, size: 84, color: Colors.white),
                          const SizedBox(height: 10),
                          const Text('তাগাদার সময় হয়েছে!', style: TextStyle(color: Colors.white70, fontSize: 18)),
                          const SizedBox(height: 18),
                          Text(name, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w800)),
                          const SizedBox(height: 8),
                          FittedBox(fit: BoxFit.scaleDown, child: Text(tk(amt), style: const TextStyle(color: Color(0xFFFFCC80), fontSize: 46, fontWeight: FontWeight.w900))),
                          if (ph.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text(ph, style: const TextStyle(color: Colors.white70, fontSize: 16))),
                          const SizedBox(height: 28),
                          SizedBox(
                              width: double.infinity,
                              height: 58,
                              child: FilledButton.icon(
                                  style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: const Color(0xFF0F3D1A)),
                                  onPressed: () async {
                                    await stop();
                                    if (c.mounted) Navigator.pop(c);
                                  },
                                  icon: const Icon(Icons.stop_circle_outlined),
                                  label: const Text('বন্ধ করুন', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)))),
                          const SizedBox(height: 12),
                          SizedBox(
                              width: double.infinity,
                              height: 50,
                              child: OutlinedButton.icon(
                                  style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: Colors.white54)),
                                  onPressed: () async {
                                    await stop();
                                    await snoozeDue(p);
                                    if (c.mounted) {
                                      Navigator.pop(c);
                                      toast(c, '১০ মিনিট পরে আবার বাজবে');
                                    }
                                  },
                                  icon: const Icon(Icons.snooze),
                                  label: const Text('১০ মিনিট পরে মনে করান'))),
                          const SizedBox(height: 12),
                          Wrap(alignment: WrapAlignment.center, spacing: 10, runSpacing: 8, children: [
                            if (mobile && ph.isNotEmpty)
                              TextButton.icon(
                                  style: TextButton.styleFrom(foregroundColor: Colors.white),
                                  onPressed: () async {
                                    await stop();
                                    if (c.mounted) openUrl(c, 'tel:${phoneRaw(ph)}');
                                  },
                                  icon: const Icon(Icons.call),
                                  label: const Text('কল')),
                            if (id.isNotEmpty && id != 'test')
                              TextButton.icon(
                                  style: TextButton.styleFrom(foregroundColor: Colors.white),
                                  onPressed: () async {
                                    await stop();
                                    if (!c.mounted) return;
                                    final nav = Navigator.of(c);
                                    nav.pop();
                                    nav.push(MaterialPageRoute(builder: (_) => Detail(id)));
                                  },
                                  icon: const Icon(Icons.person),
                                  label: const Text('কাস্টমার খুলুন')),
                          ]),
                        ]))))));
  }
}
