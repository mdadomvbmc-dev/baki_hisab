import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'main.dart';
import 'report.dart';

const inCats = ['বিক্রি', 'বাকি আদায়', 'সার্ভিস/কাজ', 'ধার পেলাম', 'অন্যান্য আয়'];
const outCats = ['মাল ক্রয়', 'দোকান ভাড়া', 'বিদ্যুৎ/ইন্টারনেট', 'বেতন', 'যাতায়াত', 'খাবার/নাস্তা', 'ধার শোধ', 'ব্যক্তিগত', 'অন্যান্য খরচ'];

bool sameDay(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;

class CashbookPage extends StatefulWidget {
  const CashbookPage({super.key});
  @override
  State<CashbookPage> createState() => _CBState();
}

class _CBState extends State<CashbookPage> {
  late DateTime month;
  late Stream<QuerySnapshot<Map<String, dynamic>>> st;

  @override
  void initState() {
    super.initState();
    final n = DateTime.now();
    month = DateTime(n.year, n.month);
    st = mk(month);
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> mk(DateTime m) => cashbook
      .where('date', isGreaterThanOrEqualTo: Timestamp.fromDate(m))
      .where('date', isLessThan: Timestamp.fromDate(DateTime(m.year, m.month + 1)))
      .orderBy('date', descending: true)
      .snapshots();

  bool get isCurrent {
    final n = DateTime.now();
    return month.year == n.year && month.month == n.month;
  }

  void go(int delta) {
    final m = DateTime(month.year, month.month + delta);
    setState(() {
      month = m;
      st = mk(m);
    });
  }

  Widget entryTile(BuildContext c, Doc d) {
    final m = d.data();
    final isIn = str(m, 'type') != 'out';
    final a = numOf(m, 'amount');
    final when = dtOf(m, 'date');
    final note = str(m, 'note');
    final sub = [if (note.isNotEmpty) note, if (when != null) timeOnly(when)].join(' • ');
    final sign = isIn ? '+' : '-';
    return card(ListTile(
      onTap: () => cashForm(c, edit: d),
      leading: CircleAvatar(
          backgroundColor: isIn ? Colors.green.shade50 : Colors.red.shade50,
          child: Icon(isIn ? Icons.south_west : Icons.north_east, color: isIn ? Colors.green : Colors.red)),
      title: Text(str(m, 'cat').isEmpty ? (isIn ? 'আয়' : 'ব্যয়') : str(m, 'cat'), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: sub.isEmpty ? null : Text(sub, maxLines: 2, overflow: TextOverflow.ellipsis),
      trailing: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 110),
          child: FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerRight, child: Text('$sign${tk(a)}', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: isIn ? Colors.green : Colors.red)))),
    ));
  }

  @override
  Widget build(BuildContext c) => Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(onPressed: () => cashForm(c), icon: const Icon(Icons.add), label: const Text('নতুন এন্ট্রি')),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: st,
          builder: (c, s) {
            if (s.hasError) return const Center(child: Text('খাতা লোড করা যায়নি'));
            final docs = s.data?.docs ?? <QueryDocumentSnapshot<Map<String, dynamic>>>[];
            num inc = 0, out = 0;
            final groups = <DateTime, List<Doc>>{};
            for (final d in docs) {
              final m = d.data();
              final a = numOf(m, 'amount');
              if (str(m, 'type') == 'out') {
                out += a;
              } else {
                inc += a;
              }
              final w = dtOf(m, 'date') ?? month;
              groups.putIfAbsent(DateTime(w.year, w.month, w.day), () => <Doc>[]).add(d);
            }
            final bal = inc - out;
            final end = DateTime(month.year, month.month + 1);
            return ListView(padding: const EdgeInsets.only(bottom: 96), children: [
              Padding(
                  padding: const EdgeInsets.fromLTRB(6, 6, 6, 0),
                  child: Row(children: [
                    IconButton(icon: const Icon(Icons.chevron_left), onPressed: () => go(-1)),
                    Expanded(child: Center(child: Text(monthName(month), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)))),
                    IconButton(icon: const Icon(Icons.chevron_right), onPressed: isCurrent ? null : () => go(1)),
                  ])),
              Container(
                  margin: const EdgeInsets.fromLTRB(14, 4, 14, 10),
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), gradient: LinearGradient(colors: [Theme.of(c).colorScheme.primary, Theme.of(c).colorScheme.tertiary])),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('এই মাসের ব্যালেন্স', style: TextStyle(color: Colors.white70)),
                    FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(tk(bal), style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w800))),
                    const Divider(color: Colors.white24, height: 22),
                    Row(children: [Expanded(child: statBox('মোট আয়', tk(inc))), const SizedBox(width: 10), Expanded(child: statBox('মোট ব্যয়', tk(out)))]),
                  ])),
              Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  child: Align(
                      alignment: Alignment.centerLeft,
                      child: OutlinedButton.icon(
                          onPressed: () => openCashReport(c, month, end, monthName(month)),
                          icon: const Icon(Icons.picture_as_pdf),
                          label: const Text('এই মাসের PDF রিপোর্ট')))),
              if (s.connectionState == ConnectionState.waiting && docs.isEmpty) const Padding(padding: EdgeInsets.all(40), child: Center(child: CircularProgressIndicator())),
              if (s.connectionState != ConnectionState.waiting && docs.isEmpty)
                const Padding(padding: EdgeInsets.all(40), child: Text('এই মাসে কোনো এন্ট্রি নেই।\nনিচের "নতুন এন্ট্রি" চেপে আয়-ব্যয় লিখুন।', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54))),
              for (final e in groups.entries) ...[
                Padding(
                    padding: const EdgeInsets.fromLTRB(18, 12, 18, 2),
                    child: Row(children: [
                      Expanded(child: Text(dayTitle(e.key), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800))),
                      Text(tk(e.value.fold<num>(0, (a, d) => a + (str(d.data(), 'type') == 'out' ? -numOf(d.data(), 'amount') : numOf(d.data(), 'amount')))), style: const TextStyle(color: Colors.black54, fontSize: 13)),
                    ])),
                for (final d in e.value) entryTile(c, d),
              ],
            ]);
          }));
}

// ───────── নতুন / এডিট ফর্ম ─────────
void cashForm(BuildContext c, {Doc? edit}) {
  final m = edit?.data() ?? <String, dynamic>{};
  var isIn = edit == null ? true : str(m, 'type') != 'out';
  final amt = TextEditingController(text: edit == null ? '' : plain(numOf(m, 'amount')));
  final note = TextEditingController(text: str(m, 'note'));
  var cat = edit == null ? '' : str(m, 'cat');
  var date = dtOf(m, 'date') ?? DateTime.now();
  String? err;
  showModalBottomSheet(
      context: c,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setS) {
            final cats = isIn ? inCats : outCats;
            return Padding(
                padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 20),
                child: SingleChildScrollView(
                    child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Expanded(child: Text(edit == null ? 'নতুন এন্ট্রি' : 'এন্ট্রি এডিট', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800))),
                    if (edit != null)
                      IconButton(
                          icon: const Icon(Icons.delete_outline, color: Colors.red),
                          onPressed: () async {
                            final ok = await showDialog<bool>(
                                context: ctx,
                                builder: (x) => AlertDialog(title: const Text('এন্ট্রি মুছবেন?'), actions: [
                                      TextButton(onPressed: () => Navigator.pop(x, false), child: const Text('না')),
                                      FilledButton(onPressed: () => Navigator.pop(x, true), child: const Text('মুছুন')),
                                    ]));
                            if (ok == true) {
                              fire(edit.reference.delete());
                              if (ctx.mounted) Navigator.pop(ctx);
                            }
                          }),
                  ]),
                  const SizedBox(height: 10),
                  Row(children: [
                    Expanded(
                        child: ChoiceChip(
                            label: const SizedBox(width: double.infinity, child: Text('আয় (জমা)', textAlign: TextAlign.center)),
                            selected: isIn,
                            onSelected: (_) => setS(() {
                                  isIn = true;
                                  cat = '';
                                }))),
                    const SizedBox(width: 8),
                    Expanded(
                        child: ChoiceChip(
                            label: const SizedBox(width: double.infinity, child: Text('ব্যয় (খরচ)', textAlign: TextAlign.center)),
                            selected: !isIn,
                            onSelected: (_) => setS(() {
                                  isIn = false;
                                  cat = '';
                                }))),
                  ]),
                  const SizedBox(height: 12),
                  TextField(controller: amt, autofocus: edit == null, keyboardType: numKb, inputFormatters: amtFmt, decoration: deco(label: 'টাকার পরিমাণ', err: err, prefix: const Icon(Icons.currency_exchange))),
                  const SizedBox(height: 12),
                  Wrap(spacing: 8, runSpacing: 0, children: [
                    for (final k in cats) ChoiceChip(label: Text(k), selected: cat == k, onSelected: (_) => setS(() => cat = k)),
                  ]),
                  const SizedBox(height: 10),
                  TextField(controller: note, decoration: deco(label: 'নোট (ঐচ্ছিক)')),
                  const SizedBox(height: 10),
                  OutlinedButton.icon(
                      onPressed: () async {
                        final d = await showDatePicker(context: ctx, initialDate: date, firstDate: DateTime(2020), lastDate: DateTime.now().add(const Duration(days: 365)));
                        if (d != null) setS(() => date = d);
                      },
                      icon: const Icon(Icons.event),
                      label: Text('তারিখ: ${dOnly(date)}')),
                  const SizedBox(height: 14),
                  SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: FilledButton(
                          onPressed: () {
                            final v = parseAmt(amt.text);
                            if (v == null || v <= 0) {
                              setS(() => err = 'সঠিক টাকার পরিমাণ লিখুন');
                              return;
                            }
                            final now = DateTime.now();
                            final base = dtOf(m, 'date');
                            final when = (edit != null && base != null && sameDay(base, date)) ? base : DateTime(date.year, date.month, date.day, now.hour, now.minute);
                            final data = <String, dynamic>{
                              'type': isIn ? 'in' : 'out',
                              'amount': v,
                              'cat': cat.isEmpty ? (isIn ? 'অন্যান্য আয়' : 'অন্যান্য খরচ') : cat,
                              'note': note.text.trim(),
                              'date': Timestamp.fromDate(when),
                            };
                            if (edit != null) {
                              fire(edit.reference.update(data));
                            } else {
                              fire(cashbook.add({...data, 'createdAt': Timestamp.now()}).then((_) {}));
                            }
                            Navigator.pop(ctx);
                          },
                          child: const Text('সংরক্ষণ'))),
                ])));
          }));
}
