import 'dart:io';
import 'dart:ui' as ui;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'main.dart';

const double kPageW = 595, kPageH = 842, kPad = 28, kFoot = 22;
const Color _green = Color(0xFF2E7D32);

// ───────── রিপোর্টের ডাটা মডেল ─────────
class RItem {
  final bool head, warn;
  final String title, sub1, sub2, amt;
  final Color color;
  final double h;
  RItem._({required this.head, this.warn = false, this.title = '', this.sub1 = '', this.sub2 = '', this.amt = '', this.color = Colors.black, required this.h});
  factory RItem.head(String title, String amt) => RItem._(head: true, title: title, amt: amt, h: 34);
  factory RItem.row(String title, {String sub1 = '', String sub2 = '', String amt = '', Color color = Colors.black, bool warn = false}) =>
      RItem._(head: false, title: title, sub1: sub1, sub2: sub2, amt: amt, color: color, warn: warn, h: 28 + (sub1.isNotEmpty ? 17 : 0) + (sub2.isNotEmpty ? 17 : 0));
}

class RSum {
  final String label, value;
  final Color color;
  const RSum(this.label, this.value, [this.color = Colors.black]);
}

class ReportSpec {
  final String title, period, info;
  final List<RItem> rows;
  final List<RSum> sums;
  ReportSpec({required this.title, required this.period, this.info = '', required this.rows, required this.sums});
}

// ───────── নেভিগেশন হেল্পার ─────────
void openReport(BuildContext c, String title, Future<ReportSpec> Function() build) =>
    Navigator.push(c, MaterialPageRoute(builder: (_) => ReportLoader(title: title, build: build)));
void openCashReport(BuildContext c, DateTime s, DateTime e, String label) => openReport(c, 'আয়-ব্যয় রিপোর্ট', () => buildCashReport(s, e, label));
void openStatement(BuildContext c, String id, Map<String, dynamic> m) => openReport(c, 'কাস্টমার বিবরণী', () => buildStatement(id, m));

Future<(DateTime, DateTime, String)?> pickPeriod(BuildContext c) async {
  final now = DateTime.now();
  final today = DateTime(now.year, now.month, now.day);
  final opts = <(String, DateTime, DateTime)>[
    ('আজ', today, today.add(const Duration(days: 1))),
    ('গতকাল', today.subtract(const Duration(days: 1)), today),
    ('গত ৭ দিন', today.subtract(const Duration(days: 6)), today.add(const Duration(days: 1))),
    ('এই মাস', DateTime(now.year, now.month), DateTime(now.year, now.month + 1)),
    ('গত মাস', DateTime(now.year, now.month - 1), DateTime(now.year, now.month)),
    ('এই বছর', DateTime(now.year), DateTime(now.year + 1)),
    ('সব সময়', DateTime(2000), DateTime(2100)),
  ];
  return showModalBottomSheet<(DateTime, DateTime, String)>(
      context: c,
      useSafeArea: true,
      builder: (x) => SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
            const ListTile(title: Text('সময়কাল বেছে নিন', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17))),
            for (final o in opts) ListTile(title: Text(o.$1), onTap: () => Navigator.pop(x, (o.$2, o.$3, o.$1))),
            ListTile(
                leading: const Icon(Icons.date_range),
                title: const Text('নিজে তারিখ বেছে নিন'),
                onTap: () async {
                  final r = await showDateRangePicker(context: x, firstDate: DateTime(2020), lastDate: DateTime(now.year + 1, 12, 31));
                  if (r != null && x.mounted) {
                    final s = DateTime(r.start.year, r.start.month, r.start.day);
                    final e = DateTime(r.end.year, r.end.month, r.end.day).add(const Duration(days: 1));
                    Navigator.pop(x, (s, e, '${dOnly(r.start)} – ${dOnly(r.end)}'));
                  }
                }),
          ])));
}

// ───────── রিপোর্ট তৈরির ফাংশন ─────────
ReportSpec buildBakiReport() {
  final now = DateTime.now();
  final l = custDocs.value.where((d) => numOf(d.data(), 'balance') > 0).toList()
    ..sort((a, b) => str(a.data(), 'name').toLowerCase().compareTo(str(b.data(), 'name').toLowerCase()));
  final g = <String, List<Doc>>{};
  for (final d in l) {
    final v = str(d.data(), 'village');
    g.putIfAbsent(v.isEmpty ? 'অন্যান্য' : v, () => <Doc>[]).add(d);
  }
  final names = g.keys.toList()..sort((a, b) => a == 'অন্যান্য' ? 1 : b == 'অন্যান্য' ? -1 : a.compareTo(b));
  final rows = <RItem>[];
  for (final k in names) {
    final list = g[k]!;
    rows.add(RItem.head('$k  (${list.length} জন)', tk(list.fold<num>(0, (a, d) => a + numOf(d.data(), 'balance')))));
    for (final d in list) {
      final m = d.data();
      final due = dtOf(m, 'due');
      final over = due != null && due.isBefore(now);
      final dueTxt = due == null ? '' : (over ? '⚠ সময় পার হয়েছে: ${dt(due)}' : 'দেওয়ার কথা: ${dt(due)}');
      rows.add(RItem.row(str(m, 'name'), sub1: str(m, 'phone'), sub2: dueTxt, amt: tk(numOf(m, 'balance')), warn: over));
    }
  }
  final total = l.fold<num>(0, (a, d) => a + numOf(d.data(), 'balance'));
  return ReportSpec(
      title: 'বাকির তালিকা',
      period: dt(now),
      rows: rows,
      sums: [RSum('মোট কাস্টমার (বাকি আছে)', '${l.length} জন'), RSum('সর্বমোট বাকি', tk(total), Colors.deepOrange)]);
}

Future<ReportSpec> buildLedgerReport(DateTime start, DateTime end, String label) async {
  final q = await ledger
      .where('date', isGreaterThanOrEqualTo: Timestamp.fromDate(start))
      .where('date', isLessThan: Timestamp.fromDate(end))
      .orderBy('date', descending: true)
      .get();
  final groups = <DateTime, List<Map<String, dynamic>>>{};
  num given = 0, got = 0;
  for (final d in q.docs) {
    final m = d.data();
    final w = dtOf(m, 'date') ?? start;
    groups.putIfAbsent(DateTime(w.year, w.month, w.day), () => <Map<String, dynamic>>[]).add(m);
    final a = numOf(m, 'amount');
    if (a > 0) {
      given += a;
    } else {
      got += -a;
    }
  }
  final rows = <RItem>[];
  for (final e in groups.entries) {
    num g = 0, r = 0;
    for (final m in e.value) {
      final a = numOf(m, 'amount');
      if (a > 0) {
        g += a;
      } else {
        r += -a;
      }
    }
    rows.add(RItem.head(dayTitle(e.key), 'বাকি ${tk(g)} • জমা ${tk(r)}'));
    for (final m in e.value) {
      final a = numOf(m, 'amount');
      final w = dtOf(m, 'date');
      final note = str(m, 'note');
      rows.add(RItem.row(str(m, 'name').isEmpty ? '—' : str(m, 'name'),
          sub1: note, sub2: w == null ? '' : timeOnly(w), amt: '${a > 0 ? 'বাকি' : 'জমা'} ${tk(a.abs())}', color: a > 0 ? Colors.deepOrange : Colors.green.shade800));
    }
  }
  return ReportSpec(
      title: 'বাকি ও জমার লেনদেন',
      period: label,
      rows: rows,
      sums: [RSum('মোট বাকি দিয়েছি', tk(given), Colors.deepOrange), RSum('মোট জমা পেয়েছি', tk(got), Colors.green.shade800), RSum('নেট বাকি বেড়েছে', tk(given - got))]);
}

Future<ReportSpec> buildCashReport(DateTime start, DateTime end, String label) async {
  final q = await cashbook
      .where('date', isGreaterThanOrEqualTo: Timestamp.fromDate(start))
      .where('date', isLessThan: Timestamp.fromDate(end))
      .orderBy('date', descending: true)
      .get();
  final groups = <DateTime, List<Map<String, dynamic>>>{};
  num inc = 0, out = 0;
  final inCat = <String, num>{}, outCat = <String, num>{};
  for (final d in q.docs) {
    final m = d.data();
    final w = dtOf(m, 'date') ?? start;
    groups.putIfAbsent(DateTime(w.year, w.month, w.day), () => <Map<String, dynamic>>[]).add(m);
    final a = numOf(m, 'amount');
    final cat = str(m, 'cat').isEmpty ? 'অন্যান্য' : str(m, 'cat');
    if (str(m, 'type') == 'out') {
      out += a;
      outCat[cat] = (outCat[cat] ?? 0) + a;
    } else {
      inc += a;
      inCat[cat] = (inCat[cat] ?? 0) + a;
    }
  }
  final rows = <RItem>[];
  for (final e in groups.entries) {
    num net = 0;
    for (final m in e.value) {
      net += str(m, 'type') == 'out' ? -numOf(m, 'amount') : numOf(m, 'amount');
    }
    rows.add(RItem.head(dayTitle(e.key), 'নেট ${tk(net)}'));
    for (final m in e.value) {
      final isIn = str(m, 'type') != 'out';
      final w = dtOf(m, 'date');
      rows.add(RItem.row(str(m, 'cat').isEmpty ? (isIn ? 'আয়' : 'ব্যয়') : str(m, 'cat'),
          sub1: str(m, 'note'), sub2: w == null ? '' : timeOnly(w), amt: '${isIn ? '+' : '-'}${tk(numOf(m, 'amount'))}', color: isIn ? Colors.green.shade800 : Colors.red.shade700));
    }
  }
  final sums = <RSum>[RSum('মোট আয়', tk(inc), Colors.green.shade800), RSum('মোট ব্যয়', tk(out), Colors.red.shade700), RSum('ব্যালেন্স (আয় − ব্যয়)', tk(inc - out), inc - out >= 0 ? Colors.green.shade800 : Colors.red.shade700)];
  final oc = outCat.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
  for (final e in oc.take(6)) {
    sums.add(RSum('   ব্যয়: ${e.key}', tk(e.value), Colors.black54));
  }
  final ic = inCat.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
  for (final e in ic.take(4)) {
    sums.add(RSum('   আয়: ${e.key}', tk(e.value), Colors.black54));
  }
  return ReportSpec(title: 'আয়-ব্যয় খাতা', period: label, rows: rows, sums: sums);
}

Future<ReportSpec> buildStatement(String id, Map<String, dynamic> m) async {
  final q = await cust.doc(id).collection('entries').orderBy('date').get();
  num run = 0, given = 0, got = 0;
  final rows = <RItem>[];
  for (final d in q.docs) {
    final e = d.data();
    final a = numOf(e, 'amount');
    run += a;
    if (a > 0) {
      given += a;
    } else {
      got += -a;
    }
    final w = dtOf(e, 'date');
    rows.add(RItem.row(w == null ? '—' : dt(w),
        sub1: str(e, 'note'), sub2: 'ব্যালেন্স: ${tk(run)}', amt: '${a > 0 ? 'বাকি' : 'জমা'} ${tk(a.abs())}', color: a > 0 ? Colors.deepOrange : Colors.green.shade800));
  }
  final parts = [str(m, 'name'), str(m, 'village'), str(m, 'phone')].where((x) => x.isNotEmpty).join(' • ');
  final bal = numOf(m, 'balance');
  return ReportSpec(
      title: 'হিসাব বিবরণী',
      period: dt(DateTime.now()),
      info: 'কাস্টমার: $parts',
      rows: rows,
      sums: [RSum('মোট বাকি দিয়েছি', tk(given), Colors.deepOrange), RSum('মোট জমা পেয়েছি', tk(got), Colors.green.shade800), RSum(bal < 0 ? 'অগ্রিম জমা আছে' : 'বর্তমান বাকি', tk(bal.abs()), bal > 0 ? Colors.deepOrange : Colors.green.shade800)]);
}

// ───────── রিপোর্ট কেন্দ্র ─────────
class ReportCenter extends StatelessWidget {
  const ReportCenter({super.key});

  Widget item(IconData i, String t, String s, VoidCallback f) => card(ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      leading: CircleAvatar(backgroundColor: _green.withAlpha(28), child: Icon(i, color: _green)),
      title: Text(t, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Text(s),
      trailing: const Icon(Icons.chevron_right),
      onTap: f));

  @override
  Widget build(BuildContext c) => Scaffold(
      appBar: AppBar(title: const Text('রিপোর্ট কেন্দ্র')),
      body: ListView(padding: const EdgeInsets.symmetric(vertical: 10), children: [
        item(Icons.people_alt, 'বাকির তালিকা', 'সব বাকি কাস্টমার, গ্রাম অনুযায়ী', () => openReport(c, 'বাকির তালিকা', () async => buildBakiReport())),
        item(Icons.swap_vert, 'বাকি ও জমার লেনদেন', 'সময়কাল বেছে দিন-ভিত্তিক লেনদেন', () async {
          final p = await pickPeriod(c);
          if (p != null && c.mounted) openReport(c, 'বাকি ও জমার লেনদেন', () => buildLedgerReport(p.$1, p.$2, p.$3));
        }),
        item(Icons.menu_book, 'আয়-ব্যয় খাতা', 'আয়, ব্যয় ও খাতভিত্তিক হিসাব', () async {
          final p = await pickPeriod(c);
          if (p != null && c.mounted) openCashReport(c, p.$1, p.$2, p.$3);
        }),
        item(Icons.receipt_long, 'কাস্টমারের বিবরণী', 'একজনের সব লেনদেন ও ব্যালেন্স', () => Navigator.push(c, MaterialPageRoute(builder: (_) => const PickCustomerPage()))),
      ]));
}

class PickCustomerPage extends StatefulWidget {
  const PickCustomerPage({super.key});
  @override
  State<PickCustomerPage> createState() => _PCState();
}

class _PCState extends State<PickCustomerPage> {
  String q = '';
  @override
  Widget build(BuildContext c) {
    final key = toEn(q).toLowerCase().trim();
    final l = custDocs.value.where((d) => key.isEmpty || toEn('${str(d.data(), 'name')} ${str(d.data(), 'village')} ${str(d.data(), 'phone')}').toLowerCase().contains(key)).toList()
      ..sort((a, b) => str(a.data(), 'name').toLowerCase().compareTo(str(b.data(), 'name').toLowerCase()));
    return Scaffold(
        appBar: AppBar(title: const Text('কাস্টমার বেছে নিন')),
        body: Column(children: [
          Padding(padding: const EdgeInsets.all(14), child: TextField(onChanged: (v) => setState(() => q = v), decoration: deco(hint: 'নাম / গ্রাম / মোবাইল', prefix: const Icon(Icons.search), filled: true))),
          Expanded(
              child: ListView.builder(
                  itemCount: l.length,
                  itemBuilder: (c, i) {
                    final m = l[i].data();
                    final sub = [str(m, 'village'), str(m, 'phone')].where((x) => x.isNotEmpty).join(' • ');
                    return card(ListTile(
                        title: Text(str(m, 'name'), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
                        subtitle: sub.isEmpty ? null : Text(sub, maxLines: 1, overflow: TextOverflow.ellipsis),
                        trailing: Text(tk(numOf(m, 'balance')), style: const TextStyle(fontWeight: FontWeight.w800)),
                        onTap: () => openStatement(c, l[i].id, m)));
                  })),
        ]));
  }
}

// ───────── রিপোর্ট লোড + প্রিভিউ + PDF ─────────
class ReportLoader extends StatefulWidget {
  final String title;
  final Future<ReportSpec> Function() build;
  const ReportLoader({super.key, required this.title, required this.build});
  @override
  State<ReportLoader> createState() => _RLState();
}

class _RLState extends State<ReportLoader> {
  late final Future<ReportSpec> f = widget.build();
  @override
  Widget build(BuildContext c) => FutureBuilder<ReportSpec>(
      future: f,
      builder: (c, s) {
        if (s.hasError) return Scaffold(appBar: AppBar(title: Text(widget.title)), body: const Center(child: Text('রিপোর্ট তৈরি করা যায়নি')));
        if (!s.hasData) return Scaffold(appBar: AppBar(title: Text(widget.title)), body: const Center(child: CircularProgressIndicator()));
        return ReportView(s.data!);
      });
}

class ReportView extends StatefulWidget {
  final ReportSpec spec;
  const ReportView(this.spec, {super.key});
  @override
  State<ReportView> createState() => _RVState();
}

class _RVState extends State<ReportView> {
  final _keys = <GlobalKey>[];
  bool busy = false;

  Future<void> makePdf() async {
    setState(() => busy = true);
    try {
      final doc = pw.Document();
      for (final k in _keys) {
        final b = k.currentContext?.findRenderObject() as RenderRepaintBoundary?;
        if (b == null) continue;
        final img = await b.toImage(pixelRatio: 2.2);
        final bd = await img.toByteData(format: ui.ImageByteFormat.png);
        if (bd == null) continue;
        final bytes = bd.buffer.asUint8List();
        doc.addPage(pw.Page(pageFormat: PdfPageFormat.a4, margin: pw.EdgeInsets.zero, build: (_) => pw.Image(pw.MemoryImage(bytes), fit: pw.BoxFit.fill)));
      }
      final data = await doc.save();
      if (isWindows) {
        final dir = await getDownloadsDirectory() ?? await getTemporaryDirectory();
        final f = File('${dir.path}/dhar-dena-${DateTime.now().millisecondsSinceEpoch}.pdf');
        await f.writeAsBytes(data);
        await openFileLocal(f.path);
      } else {
        await Printing.sharePdf(bytes: data, filename: 'dhar-dena-report.pdf');
      }
    } catch (_) {
      if (mounted) toast(context, 'PDF তৈরি করা যায়নি, আবার চেষ্টা করুন');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Widget logo() {
    final b = shopLogo.value;
    if (b != null) return Image.memory(b, width: 56, height: 56, fit: BoxFit.contain);
    final n = shop.value.trim();
    return Container(
        width: 56,
        height: 56,
        alignment: Alignment.center,
        decoration: BoxDecoration(color: _green, borderRadius: BorderRadius.circular(14)),
        child: Text(n.isEmpty ? '৳' : n.characters.first, style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w800)));
  }

  Widget rowW(RItem r) {
    if (r.head) {
      return Container(
          height: r.h - 8,
          margin: const EdgeInsets.only(top: 8),
          padding: const EdgeInsets.symmetric(horizontal: 8),
          color: const Color(0xFFE8F5E9),
          child: Row(children: [
            Expanded(child: Text(r.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14, height: 1.3, fontWeight: FontWeight.w800, color: Colors.black))),
            const SizedBox(width: 8),
            Text(r.amt, maxLines: 1, style: const TextStyle(fontSize: 12, height: 1.3, fontWeight: FontWeight.w700, color: Colors.black87)),
          ]));
    }
    return SizedBox(
        height: r.h,
        child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 4),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(r.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14, height: 1.4, fontWeight: FontWeight.w700, color: Colors.black)),
                if (r.sub1.isNotEmpty) Text(r.sub1, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, height: 1.4, color: Colors.black54)),
                if (r.sub2.isNotEmpty) Text(r.sub2, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, height: 1.4, color: r.warn ? Colors.red : Colors.black54)),
              ])),
              const SizedBox(width: 8),
              Text(r.amt, maxLines: 1, style: TextStyle(fontSize: 14, height: 1.4, fontWeight: FontWeight.w800, color: r.color)),
            ])));
  }

  Widget pageW(int i, int n, List<RItem> rows, {required bool first, required bool last}) {
    final sp = widget.spec;
    final contact = [owner.value, shopPhone.value, shopAddr.value].where((x) => x.trim().isNotEmpty).join('  •  ');
    return ClipRect(
        child: Container(
            width: kPageW,
            height: kPageH,
            color: Colors.white,
            padding: const EdgeInsets.all(kPad),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              if (first) ...[
                SizedBox(
                    height: 64,
                    child: Row(children: [
                      logo(),
                      const SizedBox(width: 12),
                      Expanded(
                          child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(shop.value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 18, height: 1.3, fontWeight: FontWeight.w800, color: Colors.black)),
                        if (contact.isNotEmpty) Text(contact, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, height: 1.3, color: Colors.black54)),
                      ])),
                      const SizedBox(width: 8),
                      ConstrainedBox(
                          constraints: const BoxConstraints(maxWidth: 190),
                          child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
                            Text(sp.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 15, height: 1.3, fontWeight: FontWeight.w800, color: _green)),
                            Text(sp.period, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, height: 1.3, color: Colors.black54)),
                          ])),
                    ])),
                const SizedBox(height: 20, child: Divider(color: Colors.black26)),
                if (sp.info.isNotEmpty) SizedBox(height: 22, child: Text(sp.info, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, height: 1.4, fontWeight: FontWeight.w700, color: Colors.black87))),
              ],
              for (final r in rows) rowW(r),
              if (last) ...[
                const SizedBox(height: 14, child: Divider(height: 14, color: Colors.black26)),
                for (final s in sp.sums)
                  SizedBox(
                      height: 30,
                      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                        Expanded(child: Text(s.label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14, height: 1.4, fontWeight: FontWeight.w800, color: Colors.black))),
                        Text(s.value, maxLines: 1, style: TextStyle(fontSize: 15, height: 1.4, fontWeight: FontWeight.w900, color: s.color)),
                      ])),
              ],
              const Spacer(),
              SizedBox(
                  height: kFoot,
                  child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    const Text('Dhar Dena (ধার দেনা) দিয়ে তৈরি', style: TextStyle(fontSize: 10, color: Colors.black38)),
                    Text('পৃষ্ঠা ${i + 1} / $n', style: const TextStyle(fontSize: 11, color: Colors.black45)),
                  ])),
            ])));
  }

  @override
  Widget build(BuildContext c) {
    final sp = widget.spec;
    const cap = kPageH - 2 * kPad - kFoot;
    final headH = 84.0 + (sp.info.isEmpty ? 0 : 22);
    final sumH = 14.0 + 30.0 * sp.sums.length + 6;
    final pages = <List<RItem>>[<RItem>[]];
    var used = headH;
    for (final r in sp.rows) {
      final need = r.head ? r.h + 34 : r.h;
      if (used + need > cap && pages.last.isNotEmpty) {
        pages.add(<RItem>[]);
        used = 0;
      }
      pages.last.add(r);
      used += r.h;
    }
    if (used + sumH > cap) pages.add(<RItem>[]);
    while (_keys.length < pages.length) {
      _keys.add(GlobalKey());
    }
    return Scaffold(
        appBar: AppBar(title: Text(sp.title)),
        body: sp.rows.isEmpty
            ? const Center(child: Padding(padding: EdgeInsets.all(30), child: Text('এই সময়ে কোনো তথ্য নেই', style: TextStyle(color: Colors.black54, fontSize: 16))))
            : Column(children: [
                Expanded(
                    child: LayoutBuilder(builder: (c, bc) {
                  final sc = ((bc.maxWidth - 24) / kPageW).clamp(0.3, 1.6).toDouble();
                  return SingleChildScrollView(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Column(children: [
                        for (var i = 0; i < pages.length; i++)
                          Padding(
                              padding: const EdgeInsets.symmetric(vertical: 6),
                              child: Container(
                                  decoration: const BoxDecoration(boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 6)]),
                                  width: kPageW * sc,
                                  height: kPageH * sc,
                                  child: FittedBox(fit: BoxFit.contain, child: RepaintBoundary(key: _keys[i], child: pageW(i, pages.length, pages[i], first: i == 0, last: i == pages.length - 1))))),
                      ]));
                })),
                Padding(
                    padding: const EdgeInsets.all(12),
                    child: SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: FilledButton.icon(
                            onPressed: busy ? null : makePdf,
                            icon: busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.picture_as_pdf),
                            label: Text(isWindows ? 'PDF সেভ করুন' : (kIsWeb ? 'PDF ডাউনলোড করুন' : 'PDF তৈরি / শেয়ার করুন'))))),
              ]));
  }
}
