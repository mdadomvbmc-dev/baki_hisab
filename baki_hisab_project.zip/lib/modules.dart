import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'cashbook.dart';
import 'main.dart';

// ═════════════════════════════════════════════════════════════
//  মাস্টার মডিউল: স্টক • অ্যাকাউন্ট • নিয়মিত এন্ট্রি • লক্ষ্য • ঋণ/কিস্তি • চার্ট
// ═════════════════════════════════════════════════════════════

CollectionReference<Map<String, dynamic>> get prodCol => me.collection('products');
CollectionReference<Map<String, dynamic>> get goalCol => me.collection('goals');
CollectionReference<Map<String, dynamic>> get loanCol => me.collection('loans');
CollectionReference<Map<String, dynamic>> get recCol => me.collection('recurring');

num r2(num v) => (v * 100).round() / 100;
num r3(num v) => (v * 1000).round() / 1000;

// ───────── ছোট সাহায্যকারী ─────────
void postCash({required bool isIn, required num amt, required String cat, String note = '', String acct = ''}) {
  fire(cashbook.add({
    'type': isIn ? 'in' : 'out',
    'amount': amt,
    'cat': cat,
    'note': note,
    'acct': acct,
    'date': Timestamp.now(),
    'createdAt': Timestamp.now(),
  }).then((_) {}));
}

Widget hero(BuildContext c, List<Widget> kids) => Container(
    margin: const EdgeInsets.fromLTRB(14, 14, 14, 6),
    padding: const EdgeInsets.all(18),
    width: double.infinity,
    decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), gradient: LinearGradient(colors: [Theme.of(c).colorScheme.primary, Theme.of(c).colorScheme.tertiary])),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: kids));

Widget bigNum(String s) => FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(s, style: const TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w800)));

Widget chipWrap(List<String> items, String sel, void Function(String) on) =>
    Wrap(spacing: 8, runSpacing: 0, children: [for (final k in items) ChoiceChip(label: Text(k), selected: sel == k, onSelected: (_) => on(k))]);

Future<bool> confirmDel(BuildContext c, String title) async {
  final ok = await showDialog<bool>(
      context: c,
      builder: (x) => AlertDialog(title: Text(title), actions: [
            TextButton(onPressed: () => Navigator.pop(x, false), child: const Text('না')),
            FilledButton(onPressed: () => Navigator.pop(x, true), child: const Text('মুছুন')),
          ]));
  return ok == true;
}

void sheet(BuildContext c, List<Widget> Function(BuildContext, StateSetter) kids) => showModalBottomSheet(
    context: c,
    isScrollControlled: true,
    useSafeArea: true,
    builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => Padding(
            padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 20),
            child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: kids(ctx, setS))))));

Widget sheetTitle(String t) => Text(t, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800));

// পরিমাণ + (ঐচ্ছিক) "খাতায় যোগ করুন" চেকবক্স সহ ডায়ালগ
void amountDialog(BuildContext c,
    {required String title, required String label, String initial = '', String? checkLabel, String? helper, String? Function(num v)? validate, required void Function(num v, bool check) onOk}) {
  final tc = TextEditingController(text: initial);
  var check = true;
  String? err;
  showDialog(
      context: c,
      builder: (x) => StatefulBuilder(
          builder: (x, setS) => AlertDialog(
                  title: Text(title),
                  content: SingleChildScrollView(
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                    TextField(controller: tc, autofocus: true, keyboardType: numKb, inputFormatters: amtFmt, decoration: deco(label: label, err: err, helper: helper)),
                    if (checkLabel != null)
                      CheckboxListTile(
                          contentPadding: EdgeInsets.zero,
                          controlAffinity: ListTileControlAffinity.leading,
                          value: check,
                          onChanged: (v) => setS(() => check = v ?? false),
                          title: Text(checkLabel, style: const TextStyle(fontSize: 14))),
                  ])),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(x), child: const Text('বাতিল')),
                    FilledButton(
                        onPressed: () {
                          final v = parseAmt(tc.text);
                          if (v == null || v <= 0) {
                            setS(() => err = 'সঠিক পরিমাণ লিখুন');
                            return;
                          }
                          final e = validate?.call(v);
                          if (e != null) {
                            setS(() => err = e);
                            return;
                          }
                          Navigator.pop(x);
                          onOk(v, check);
                        },
                        child: const Text('সংরক্ষণ')),
                  ])));
}

// একটি কালেকশনের লাইভ তালিকা (নতুন আগে)
class ColView extends StatefulWidget {
  final CollectionReference<Map<String, dynamic>> col;
  final Widget Function(BuildContext, List<Doc>) builder;
  const ColView({super.key, required this.col, required this.builder});
  @override
  State<ColView> createState() => _ColViewState();
}

class _ColViewState extends State<ColView> {
  late final Stream<QuerySnapshot<Map<String, dynamic>>> st = widget.col.snapshots();
  @override
  Widget build(BuildContext c) => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: st,
      builder: (c, s) {
        if (s.hasError) return const Center(child: Text('লোড করা যায়নি'));
        if (!s.hasData) return const LogoLoader(size: 120);
        final docs = <Doc>[...s.data!.docs];
        docs.sort((a, b) {
          final x = dtOf(a.data(), 'createdAt'), y = dtOf(b.data(), 'createdAt');
          if (x == null && y == null) return 0;
          if (x == null) return 1;
          if (y == null) return -1;
          return y.compareTo(x);
        });
        return widget.builder(c, docs);
      });
}

Widget emptyNote(String t) => Padding(padding: const EdgeInsets.all(40), child: Text(t, textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54)));

// ═════════════════ ১) পণ্য ও স্টক ═════════════════
const units = ['পিস', 'কেজি', 'গ্রাম', 'লিটার', 'ডজন', 'প্যাকেট', 'বক্স', 'বস্তা'];

bool isLowStock(Map<String, dynamic> m) {
  final mn = numOf(m, 'min');
  return mn > 0 && numOf(m, 'qty') <= mn;
}

class StockPage extends StatefulWidget {
  const StockPage({super.key});
  @override
  State<StockPage> createState() => _StockState();
}

class _StockState extends State<StockPage> {
  late final Stream<QuerySnapshot<Map<String, dynamic>>> st = prodCol.snapshots();
  final qc = TextEditingController();
  String q = '';
  bool lowOnly = false;

  @override
  void dispose() {
    qc.dispose();
    super.dispose();
  }

  Widget tileOf(BuildContext c, Doc d) {
    final m = d.data();
    final low = isLowStock(m);
    final u = str(m, 'unit').isEmpty ? 'পিস' : str(m, 'unit');
    final info = '${plain(r3(numOf(m, 'qty')))} $u • ক্রয় ${tk(numOf(m, 'buy'))} • বিক্রয় ${tk(numOf(m, 'sell'))}${low ? '\n⚠️ স্টক কমে গেছে' : ''}';
    return card(ListTile(
      onTap: () => productForm(c, edit: d),
      leading: CircleAvatar(backgroundColor: low ? Colors.red.shade50 : Colors.green.shade50, child: Icon(Icons.inventory_2, color: low ? Colors.red : Colors.green)),
      title: Text(str(m, 'name'), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Text(info, maxLines: 3, overflow: TextOverflow.ellipsis, style: TextStyle(color: low ? Colors.red : null)),
      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
        IconButton(tooltip: 'বিক্রি / স্টক বের', icon: const Icon(Icons.remove_circle_outline, color: Colors.deepOrange), onPressed: () => stockMove(c, d, false)),
        IconButton(tooltip: 'ক্রয় / স্টক জমা', icon: const Icon(Icons.add_circle_outline, color: Colors.green), onPressed: () => stockMove(c, d, true)),
      ]),
    ));
  }

  @override
  Widget build(BuildContext c) => Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(onPressed: () => productForm(c), icon: const Icon(Icons.add_box), label: const Text('নতুন পণ্য')),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: st,
          builder: (c, s) {
            if (s.hasError) return const Center(child: Text('স্টক লোড করা যায়নি'));
            if (!s.hasData) return const LogoLoader(size: 120);
            final all = <Doc>[...s.data!.docs];
            all.sort((a, b) => str(a.data(), 'name').toLowerCase().compareTo(str(b.data(), 'name').toLowerCase()));
            num cost = 0, sale = 0;
            var low = 0;
            for (final d in all) {
              final m = d.data();
              final qn = numOf(m, 'qty');
              cost += qn * numOf(m, 'buy');
              sale += qn * numOf(m, 'sell');
              if (isLowStock(m)) low++;
            }
            final key = toEn(q).toLowerCase().trim();
            final list = all.where((d) {
              if (lowOnly && !isLowStock(d.data())) return false;
              return key.isEmpty || toEn(str(d.data(), 'name')).toLowerCase().contains(key);
            }).toList();
            return ListView(padding: const EdgeInsets.only(bottom: 96), children: [
              hero(c, [
                const Text('স্টকের মোট মূল্য (ক্রয়দামে)', style: TextStyle(color: Colors.white70)),
                bigNum(tk(cost)),
                const Divider(color: Colors.white24, height: 22),
                Row(children: [Expanded(child: statBox('বিক্রয়মূল্যে', tk(sale))), const SizedBox(width: 10), Expanded(child: statBox('সম্ভাব্য লাভ', tk(sale - cost)))]),
                const SizedBox(height: 8),
                Text('মোট ${nbn(all.length)} টি পণ্য${low > 0 ? ' • ⚠️ ${nbn(low)} টির স্টক কম' : ''}', style: const TextStyle(color: Colors.white70, fontSize: 12.5)),
              ]),
              Padding(
                  padding: const EdgeInsets.fromLTRB(14, 6, 14, 0),
                  child: Row(children: [
                    Expanded(
                        child: TextField(
                            controller: qc,
                            onChanged: (v) => setState(() => q = v),
                            decoration: deco(hint: 'পণ্যের নাম খুঁজুন', prefix: const Icon(Icons.search), filled: true, suffix: q.isEmpty ? null : IconButton(icon: const Icon(Icons.close), onPressed: () => setState(() { qc.clear(); q = ''; }))))),
                    const SizedBox(width: 8),
                    FilterChip(label: const Text('কম স্টক'), selected: lowOnly, onSelected: (v) => setState(() => lowOnly = v)),
                  ])),
              const SizedBox(height: 6),
              if (all.isEmpty) emptyNote('কোনো পণ্য নেই।\nনিচের "নতুন পণ্য" চেপে পণ্য ও স্টক যোগ করুন।'),
              if (all.isNotEmpty && list.isEmpty) emptyNote('কিছু পাওয়া যায়নি'),
              for (final d in list) tileOf(c, d),
            ]);
          }));
}

void stockMove(BuildContext c, Doc d, bool isIn) {
  final m = d.data();
  final name = str(m, 'name');
  final u = str(m, 'unit').isEmpty ? 'পিস' : str(m, 'unit');
  final have = numOf(m, 'qty');
  final dp = numOf(m, isIn ? 'buy' : 'sell');
  final qc = TextEditingController();
  final pc = TextEditingController(text: dp > 0 ? plain(dp) : '');
  var check = true;
  String? err;
  showDialog(
      context: c,
      builder: (x) => StatefulBuilder(
          builder: (x, setS) => AlertDialog(
                  title: Text(isIn ? '$name — স্টক জমা (ক্রয়)' : '$name — বিক্রি / স্টক বের'),
                  content: SingleChildScrollView(
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                    TextField(controller: qc, autofocus: true, keyboardType: numKb, inputFormatters: amtFmt, decoration: deco(label: 'পরিমাণ ($u)', err: err, helper: 'বর্তমান স্টক: ${plain(r3(have))} $u')),
                    const SizedBox(height: 10),
                    TextField(controller: pc, keyboardType: numKb, inputFormatters: amtFmt, decoration: deco(label: isIn ? 'প্রতি $u ক্রয়দাম (ঐচ্ছিক)' : 'প্রতি $u বিক্রয়দাম (ঐচ্ছিক)')),
                    CheckboxListTile(
                        contentPadding: EdgeInsets.zero,
                        controlAffinity: ListTileControlAffinity.leading,
                        value: check,
                        onChanged: (v) => setS(() => check = v ?? false),
                        title: Text(isIn ? 'খাতায় ব্যয় (মাল ক্রয়) হিসেবে যোগ করুন' : 'খাতায় আয় (বিক্রি) হিসেবে যোগ করুন', style: const TextStyle(fontSize: 14))),
                  ])),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(x), child: const Text('বাতিল')),
                    FilledButton(
                        onPressed: () {
                          final qv = parseAmt(qc.text);
                          if (qv == null || qv <= 0) {
                            setS(() => err = 'সঠিক পরিমাণ লিখুন');
                            return;
                          }
                          if (!isIn && qv > have) {
                            setS(() => err = 'স্টকে মাত্র ${plain(r3(have))} $u আছে');
                            return;
                          }
                          final pv = parseAmt(pc.text) ?? 0;
                          Navigator.pop(x);
                          fire(d.reference.update({'qty': FieldValue.increment(isIn ? qv : -qv)}));
                          if (check && pv > 0) {
                            postCash(isIn: !isIn, amt: r2(qv * pv), cat: isIn ? 'মাল ক্রয়' : 'ব্যবসা / বিক্রি', note: '$name × ${plain(r3(qv))} $u');
                          }
                        },
                        child: const Text('সংরক্ষণ')),
                  ])));
}

void productForm(BuildContext c, {Doc? edit}) {
  final m = edit?.data() ?? <String, dynamic>{};
  final name = TextEditingController(text: str(m, 'name'));
  final qty = TextEditingController(text: edit == null ? '' : plain(r3(numOf(m, 'qty'))));
  final buy = TextEditingController(text: numOf(m, 'buy') > 0 ? plain(numOf(m, 'buy')) : '');
  final sell = TextEditingController(text: numOf(m, 'sell') > 0 ? plain(numOf(m, 'sell')) : '');
  final mn = TextEditingController(text: numOf(m, 'min') > 0 ? plain(numOf(m, 'min')) : '');
  var unit = str(m, 'unit').isEmpty ? 'পিস' : str(m, 'unit');
  String? err;
  sheet(c, (ctx, setS) => [
        Row(children: [
          Expanded(child: sheetTitle(edit == null ? 'নতুন পণ্য' : 'পণ্য এডিট')),
          if (edit != null)
            IconButton(
                icon: const Icon(Icons.delete_outline, color: Colors.red),
                onPressed: () async {
                  final ok = await confirmDel(ctx, 'পণ্যটি মুছবেন?');
                  if (ok) {
                    fire(edit.reference.delete());
                    if (ctx.mounted) Navigator.pop(ctx);
                  }
                }),
        ]),
        const SizedBox(height: 10),
        TextField(controller: name, autofocus: edit == null, textCapitalization: TextCapitalization.sentences, decoration: deco(label: 'পণ্যের নাম *', err: err, prefix: const Icon(Icons.inventory_2_outlined))),
        const SizedBox(height: 10),
        chipWrap(units, unit, (k) => setS(() => unit = k)),
        const SizedBox(height: 10),
        TextField(controller: qty, keyboardType: numKb, inputFormatters: amtFmt, decoration: deco(label: edit == null ? 'শুরুর স্টক (পরিমাণ)' : 'বর্তমান স্টক (পরিমাণ)')),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: TextField(controller: buy, keyboardType: numKb, inputFormatters: amtFmt, decoration: deco(label: 'ক্রয়দাম (প্রতি একক)'))),
          const SizedBox(width: 10),
          Expanded(child: TextField(controller: sell, keyboardType: numKb, inputFormatters: amtFmt, decoration: deco(label: 'বিক্রয়দাম (প্রতি একক)'))),
        ]),
        const SizedBox(height: 10),
        TextField(controller: mn, keyboardType: numKb, inputFormatters: amtFmt, decoration: deco(label: 'কম স্টক সতর্কতা (ঐচ্ছিক)', helper: 'এই পরিমাণ বা তার কম হলে লাল সতর্কতা দেখাবে')),
        const SizedBox(height: 14),
        SizedBox(
            width: double.infinity,
            height: 50,
            child: FilledButton(
                onPressed: () {
                  if (name.text.trim().isEmpty) {
                    setS(() => err = 'পণ্যের নাম লিখুন');
                    return;
                  }
                  final data = <String, dynamic>{
                    'name': name.text.trim(),
                    'unit': unit,
                    'qty': parseAmt(qty.text) ?? 0,
                    'buy': parseAmt(buy.text) ?? 0,
                    'sell': parseAmt(sell.text) ?? 0,
                    'min': parseAmt(mn.text) ?? 0,
                  };
                  if (edit != null) {
                    fire(edit.reference.update(data));
                  } else {
                    fire(prodCol.add({...data, 'createdAt': Timestamp.now()}).then((_) {}));
                  }
                  Navigator.pop(ctx);
                },
                child: const Text('সংরক্ষণ'))),
      ]);
}

// ═════════════════ ২) অ্যাকাউন্ট ব্যালেন্স (সব সময়ের) ═════════════════
class AccountsPage extends StatefulWidget {
  const AccountsPage({super.key});
  @override
  State<AccountsPage> createState() => _AccState();
}

class _AccState extends State<AccountsPage> {
  late Future<QuerySnapshot<Map<String, dynamic>>> f = cashbook.get();

  void setOpening(String k) {
    final tc = TextEditingController(text: (openBal.value[k] ?? 0) > 0 ? plain(openBal.value[k]!) : '');
    showDialog(
        context: context,
        builder: (x) => AlertDialog(
                title: Text('$k — শুরুর ব্যালেন্স'),
                content: TextField(controller: tc, autofocus: true, keyboardType: numKb, inputFormatters: amtFmt, decoration: deco(label: 'অ্যাপ ব্যবহারের আগে যত টাকা ছিল', helper: 'না থাকলে খালি রাখুন')),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(x), child: const Text('বাতিল')),
                  FilledButton(
                      onPressed: () {
                        final v = tc.text.trim().isEmpty ? 0 : (parseAmt(tc.text) ?? 0);
                        final nm = Map<String, num>.from(openBal.value);
                        nm[k] = v;
                        openBal.value = nm;
                        savePrefs({
                          'open': {k: v}
                        });
                        Navigator.pop(x);
                      },
                      child: const Text('সেভ')),
                ]));
  }

  @override
  Widget build(BuildContext c) => Scaffold(
      appBar: AppBar(title: const Text('অ্যাকাউন্ট ব্যালেন্স'), actions: [
        IconButton(
            tooltip: 'রিফ্রেশ',
            icon: const Icon(Icons.refresh),
            onPressed: () => setState(() {
                  f = cashbook.get();
                })),
      ]),
      body: FutureBuilder<QuerySnapshot<Map<String, dynamic>>>(
          future: f,
          builder: (c, s) {
            if (s.hasError) return const Center(child: Text('লোড করা যায়নি'));
            if (!s.hasData) return const LogoLoader(size: 120);
            final inn = <String, num>{};
            final out = <String, num>{};
            for (final d in s.data!.docs) {
              final m = d.data();
              final a = numOf(m, 'amount');
              var k = str(m, 'acct');
              if (k.isEmpty) k = 'অনির্দিষ্ট';
              if (str(m, 'type') == 'out') {
                out[k] = (out[k] ?? 0) + a;
              } else {
                inn[k] = (inn[k] ?? 0) + a;
              }
            }
            return ValueListenableBuilder<Map<String, num>>(
                valueListenable: openBal,
                builder: (c, ob, _) {
                  final keys = <String>[...accts];
                  for (final k in {...inn.keys, ...out.keys, ...ob.keys}) {
                    if (!keys.contains(k)) keys.add(k);
                  }
                  final shown = keys.where((k) => accts.contains(k) || (inn[k] ?? 0) != 0 || (out[k] ?? 0) != 0 || (ob[k] ?? 0) != 0).toList();
                  num bal(String k) => (ob[k] ?? 0) + (inn[k] ?? 0) - (out[k] ?? 0);
                  final total = shown.fold<num>(0, (a, k) => a + bal(k));
                  return ListView(padding: const EdgeInsets.only(bottom: 30), children: [
                    hero(c, [
                      const Text('মোট টাকা (সব মাধ্যম মিলিয়ে)', style: TextStyle(color: Colors.white70)),
                      bigNum(tk(total)),
                      const SizedBox(height: 4),
                      const Text('শুরুর ব্যালেন্স + এ পর্যন্ত সব আয় − সব ব্যয়', style: TextStyle(color: Colors.white70, fontSize: 12)),
                    ]),
                    for (final k in shown)
                      card(ListTile(
                        onTap: () => setOpening(k),
                        leading: CircleAvatar(backgroundColor: Theme.of(c).colorScheme.primaryContainer, child: const Icon(Icons.account_balance_wallet_outlined)),
                        title: Text(k, style: const TextStyle(fontWeight: FontWeight.w700)),
                        subtitle: Text('শুরু ${tk(ob[k] ?? 0)} • আয় ${tk(inn[k] ?? 0)} • ব্যয় ${tk(out[k] ?? 0)}', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12.5)),
                        trailing: ConstrainedBox(
                            constraints: const BoxConstraints(maxWidth: 120),
                            child: FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerRight, child: Text(tk(bal(k)), style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: bal(k) < 0 ? Colors.red : Colors.green)))),
                      )),
                    Padding(
                        padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
                        child: Text('টিপস: খাতায় এন্ট্রি দেওয়ার সময় "কোন মাধ্যমে" বেছে নিলে এখানে সেই মাধ্যমের ব্যালেন্স মিলবে। মাধ্যম না বাছা এন্ট্রি "অনির্দিষ্ট" এ জমা হয়। কোনো লাইনে চাপ দিলে শুরুর ব্যালেন্স বসাতে পারবেন।',
                            style: TextStyle(color: Colors.black54, fontSize: 12.5))),
                  ]);
                });
          }));
}

// ═════════════════ ৩) নিয়মিত (প্রতি মাসের) এন্ট্রি ═════════════════
// অ্যাপ খুললে বাকি থাকা মাসগুলোর এন্ট্রি নিজে খাতায় বসে যায়।
// এন্ট্রির আইডি নির্দিষ্ট (rec_<id>_<মাস>) তাই দুই ডিভাইসে খুললেও ডুপ্লিকেট হয় না।
Future<void> runRecurring() async {
  if (!mods.value.contains('recur')) return;
  try {
    final q = await recCol.get();
    final now = DateTime.now();
    final nowIdx = now.year * 12 + now.month - 1;
    for (final d in q.docs) {
      final m = d.data();
      if (m['active'] == false) continue;
      final amt = numOf(m, 'amount');
      if (amt <= 0) continue;
      final day = intOf(m, 'day', 1);
      final orig = intOf(m, 'last', nowIdx);
      final last = orig < nowIdx - 24 ? nowIdx - 24 : orig;
      var cur = last;
      final b = db.batch();
      for (var idx = last + 1; idx <= nowIdx; idx++) {
        final y = idx ~/ 12;
        final mo = idx % 12 + 1;
        final dim = DateTime(y, mo + 1, 0).day;
        final when = DateTime(y, mo, day > dim ? dim : day, 9);
        if (when.isAfter(now)) break;
        final isOut = str(m, 'type') == 'out';
        b.set(cashbook.doc('rec_${d.id}_$idx'), {
          'type': isOut ? 'out' : 'in',
          'amount': amt,
          'cat': str(m, 'cat').isEmpty ? (isOut ? 'অন্যান্য খরচ' : 'অন্যান্য আয়') : str(m, 'cat'),
          'note': str(m, 'note').isEmpty ? 'নিয়মিত এন্ট্রি' : str(m, 'note'),
          'acct': str(m, 'acct'),
          'date': Timestamp.fromDate(when),
          'createdAt': Timestamp.now(),
          'auto': true,
        });
        cur = idx;
      }
      if (cur != orig) {
        b.update(d.reference, {'last': cur});
        fire(b.commit());
      }
    }
  } catch (_) {}
}

class RecurringPage extends StatelessWidget {
  const RecurringPage({super.key});
  @override
  Widget build(BuildContext c) => Scaffold(
      appBar: AppBar(title: const Text('নিয়মিত এন্ট্রি')),
      floatingActionButton: FloatingActionButton.extended(onPressed: () => recurringForm(c), icon: const Icon(Icons.event_repeat), label: const Text('নতুন নিয়মিত এন্ট্রি')),
      body: ColView(
          col: recCol,
          builder: (c, docs) => ListView(padding: const EdgeInsets.only(bottom: 96), children: [
                Padding(
                    padding: const EdgeInsets.fromLTRB(18, 12, 18, 4),
                    child: Text('বাসা ভাড়া, কিস্তি, বেতন, ইন্টারনেট বিল — যা প্রতি মাসে একই তারিখে আসে বা যায়। তারিখ হলেই অ্যাপ খুললে খাতায় নিজে যোগ হবে।', style: TextStyle(color: Colors.black54, fontSize: 12.5))),
                if (docs.isEmpty) emptyNote('কোনো নিয়মিত এন্ট্রি নেই।'),
                for (final d in docs) recTile(c, d),
              ])));

  Widget recTile(BuildContext c, Doc d) {
    final m = d.data();
    final isIn = str(m, 'type') != 'out';
    final on = m['active'] != false;
    final sub = ['প্রতি মাসের ${nbn(intOf(m, 'day', 1))} তারিখ', if (str(m, 'acct').isNotEmpty) str(m, 'acct'), if (str(m, 'note').isNotEmpty) str(m, 'note')].join(' • ');
    return card(ListTile(
      onTap: () => recurringForm(c, edit: d),
      leading: CircleAvatar(backgroundColor: isIn ? Colors.green.shade50 : Colors.red.shade50, child: Icon(isIn ? Icons.south_west : Icons.north_east, color: isIn ? Colors.green : Colors.red)),
      title: Text('${str(m, 'cat').isEmpty ? (isIn ? 'আয়' : 'ব্যয়') : str(m, 'cat')} • ${tk(numOf(m, 'amount'))}', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: FontWeight.w700, color: on ? null : Colors.black45)),
      subtitle: Text(sub, maxLines: 2, overflow: TextOverflow.ellipsis),
      trailing: Switch(value: on, onChanged: (v) => fire(d.reference.update({'active': v}))),
    ));
  }
}

void recurringForm(BuildContext c, {Doc? edit}) {
  final m = edit?.data() ?? <String, dynamic>{};
  var isIn = edit == null ? false : str(m, 'type') != 'out';
  final amt = TextEditingController(text: edit == null ? '' : plain(numOf(m, 'amount')));
  final note = TextEditingController(text: str(m, 'note'));
  final dayC = TextEditingController(text: '${edit == null ? DateTime.now().day : intOf(m, 'day', 1)}');
  var cat = str(m, 'cat');
  var acct = str(m, 'acct');
  String? err;
  sheet(c, (ctx, setS) {
    final cats = isIn ? inCats : outCats;
    return [
      Row(children: [
        Expanded(child: sheetTitle(edit == null ? 'নতুন নিয়মিত এন্ট্রি' : 'নিয়মিত এন্ট্রি এডিট')),
        if (edit != null)
          IconButton(
              icon: const Icon(Icons.delete_outline, color: Colors.red),
              onPressed: () async {
                final ok = await confirmDel(ctx, 'নিয়মিত এন্ট্রিটি মুছবেন?\n(খাতার আগের এন্ট্রি থাকবে)');
                if (ok) {
                  fire(edit.reference.delete());
                  if (ctx.mounted) Navigator.pop(ctx);
                }
              }),
      ]),
      const SizedBox(height: 10),
      Row(children: [
        Expanded(child: ChoiceChip(label: const SizedBox(width: double.infinity, child: Text('আয়', textAlign: TextAlign.center)), selected: isIn, onSelected: (_) => setS(() { isIn = true; cat = ''; }))),
        const SizedBox(width: 8),
        Expanded(child: ChoiceChip(label: const SizedBox(width: double.infinity, child: Text('ব্যয়', textAlign: TextAlign.center)), selected: !isIn, onSelected: (_) => setS(() { isIn = false; cat = ''; }))),
      ]),
      const SizedBox(height: 12),
      TextField(controller: amt, keyboardType: numKb, inputFormatters: amtFmt, decoration: deco(label: 'টাকার পরিমাণ', err: err, prefix: const Icon(Icons.currency_exchange))),
      const SizedBox(height: 12),
      chipWrap(cats, cat, (k) => setS(() => cat = k)),
      const SizedBox(height: 10),
      const Text('কোন মাধ্যমে (ঐচ্ছিক)', style: TextStyle(fontSize: 12.5, color: Colors.black54)),
      Wrap(spacing: 8, runSpacing: 0, children: [for (final k in accts) ChoiceChip(label: Text(k), selected: acct == k, onSelected: (v) => setS(() => acct = v ? k : ''))]),
      const SizedBox(height: 10),
      TextField(controller: dayC, keyboardType: TextInputType.number, decoration: deco(label: 'প্রতি মাসের কত তারিখে (১–৩১)', helper: 'আজ বা তার আগের তারিখ দিলে শুরু হবে আগামী মাস থেকে')),
      const SizedBox(height: 10),
      TextField(controller: note, decoration: deco(label: 'নোট (যেমন: বাসা ভাড়া, বাইকের কিস্তি)')),
      const SizedBox(height: 14),
      SizedBox(
          width: double.infinity,
          height: 50,
          child: FilledButton(
              onPressed: () {
                final v = parseAmt(amt.text);
                final dv = int.tryParse(toEn(dayC.text).trim());
                if (v == null || v <= 0) {
                  setS(() => err = 'সঠিক টাকার পরিমাণ লিখুন');
                  return;
                }
                if (dv == null || dv < 1 || dv > 31) {
                  setS(() => err = 'তারিখ ১ থেকে ৩১ এর মধ্যে দিন');
                  return;
                }
                final now = DateTime.now();
                final nowIdx = now.year * 12 + now.month - 1;
                final data = <String, dynamic>{
                  'type': isIn ? 'in' : 'out',
                  'amount': v,
                  'cat': cat.isEmpty ? (isIn ? 'অন্যান্য আয়' : 'অন্যান্য খরচ') : cat,
                  'note': note.text.trim(),
                  'acct': acct,
                  'day': dv,
                };
                if (edit != null) {
                  fire(edit.reference.update(data));
                } else {
                  fire(recCol.add({...data, 'active': true, 'last': dv <= now.day ? nowIdx : nowIdx - 1, 'createdAt': Timestamp.now()}).then((_) {}));
                }
                Navigator.pop(ctx);
              },
              child: const Text('সংরক্ষণ'))),
    ];
  });
}

// ═════════════════ ৪) সঞ্চয় লক্ষ্য ═════════════════
class GoalsPage extends StatelessWidget {
  const GoalsPage({super.key});
  @override
  Widget build(BuildContext c) => Scaffold(
      appBar: AppBar(title: const Text('সঞ্চয় লক্ষ্য')),
      floatingActionButton: FloatingActionButton.extended(onPressed: () => goalForm(c), icon: const Icon(Icons.flag), label: const Text('নতুন লক্ষ্য')),
      body: ColView(
          col: goalCol,
          builder: (c, docs) => ListView(padding: const EdgeInsets.only(bottom: 96), children: [
                if (docs.isEmpty) emptyNote('কোনো লক্ষ্য নেই।\nযেমন: নতুন ফোন, হজ্জ, বাইক, জরুরি তহবিল — নিচের বোতাম চেপে লক্ষ্য ঠিক করুন।'),
                for (final d in docs) goalCard(c, d),
              ])));

  Widget goalCard(BuildContext c, Doc d) {
    final m = d.data();
    final name = str(m, 'name');
    final target = numOf(m, 'target');
    final saved = numOf(m, 'saved');
    final dl = dtOf(m, 'deadline');
    final done = target > 0 && saved >= target;
    final ratio = target <= 0 ? 0.0 : (saved / target).clamp(0.0, 1.0).toDouble();
    final rem = target - saved;
    String? hint;
    if (!done && dl != null) {
      final now = DateTime.now();
      if (dl.isBefore(DateTime(now.year, now.month, now.day))) {
        hint = 'সময় পেরিয়ে গেছে — আর ${tk(rem)} বাকি';
      } else {
        final months = (dl.year - now.year) * 12 + dl.month - now.month;
        final mm = months < 1 ? 1 : months;
        hint = '${dOnly(dl)} এর মধ্যে — মাসে ${tk((rem / mm).ceil())} জমালে পূরণ হবে';
      }
    }
    final col = done ? Colors.green : Theme.of(c).colorScheme.primary;
    return card(Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 8, 12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Text('${done ? '🎉 ' : '🎯 '}$name', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
            Text('${nbn((ratio * 100).round())}%', style: TextStyle(fontWeight: FontWeight.w800, color: col)),
            PopupMenuButton<int>(
                onSelected: (v) async {
                  if (v == 0) {
                    goalForm(c, edit: d);
                  } else {
                    final ok = await confirmDel(c, 'লক্ষ্যটি মুছবেন?');
                    if (ok) fire(d.reference.delete());
                  }
                },
                itemBuilder: (_) => const [PopupMenuItem(value: 0, child: Text('এডিট')), PopupMenuItem(value: 1, child: Text('মুছুন'))]),
          ]),
          Padding(padding: const EdgeInsets.only(right: 8), child: LinearProgressIndicator(value: ratio, minHeight: 10, borderRadius: BorderRadius.circular(9), color: col)),
          const SizedBox(height: 8),
          Text('জমেছে ${tk(saved)} / লক্ষ্য ${tk(target)}${done ? '' : ' • বাকি ${tk(rem)}'}', style: const TextStyle(fontSize: 13)),
          if (hint != null) Padding(padding: const EdgeInsets.only(top: 2), child: Text(hint, style: const TextStyle(fontSize: 12.5, color: Colors.black54))),
          const SizedBox(height: 8),
          Row(children: [
            OutlinedButton.icon(
                onPressed: () => amountDialog(c,
                    title: '$name — টাকা জমা',
                    label: 'জমার পরিমাণ',
                    checkLabel: 'খাতায় "সঞ্চয়" ব্যয় হিসেবে যোগ করুন',
                    onOk: (v, ck) {
                      fire(d.reference.update({'saved': FieldValue.increment(v)}));
                      if (ck) postCash(isIn: false, amt: v, cat: 'সঞ্চয় / বিনিয়োগ', note: 'লক্ষ্য: $name');
                    }),
                icon: const Icon(Icons.add),
                label: const Text('জমা')),
            const SizedBox(width: 8),
            OutlinedButton.icon(
                onPressed: saved <= 0
                    ? null
                    : () => amountDialog(c,
                        title: '$name — টাকা তোলা',
                        label: 'তোলার পরিমাণ',
                        checkLabel: 'খাতায় আয় হিসেবে যোগ করুন',
                        validate: (v) => v > saved ? 'জমা আছে মাত্র ${tk(saved)}' : null,
                        onOk: (v, ck) {
                          fire(d.reference.update({'saved': FieldValue.increment(-v)}));
                          if (ck) postCash(isIn: true, amt: v, cat: 'অন্যান্য আয়', note: 'লক্ষ্য থেকে তোলা: $name');
                        }),
                icon: const Icon(Icons.remove),
                label: const Text('তুলুন')),
          ]),
        ])));
  }
}

void goalForm(BuildContext c, {Doc? edit}) {
  final m = edit?.data() ?? <String, dynamic>{};
  final name = TextEditingController(text: str(m, 'name'));
  final target = TextEditingController(text: edit == null ? '' : plain(numOf(m, 'target')));
  final saved = TextEditingController();
  DateTime? dl = dtOf(m, 'deadline');
  String? err;
  sheet(c, (ctx, setS) => [
        sheetTitle(edit == null ? 'নতুন লক্ষ্য' : 'লক্ষ্য এডিট'),
        const SizedBox(height: 12),
        TextField(controller: name, autofocus: edit == null, decoration: deco(label: 'লক্ষ্যের নাম (যেমন: নতুন ফোন)', prefix: const Icon(Icons.flag_outlined))),
        const SizedBox(height: 10),
        TextField(controller: target, keyboardType: numKb, inputFormatters: amtFmt, decoration: deco(label: 'কত টাকা লাগবে', err: err, prefix: const Icon(Icons.currency_exchange))),
        if (edit == null) ...[
          const SizedBox(height: 10),
          TextField(controller: saved, keyboardType: numKb, inputFormatters: amtFmt, decoration: deco(label: 'এখন পর্যন্ত জমেছে (ঐচ্ছিক)')),
        ],
        const SizedBox(height: 10),
        Row(children: [
          Expanded(
              child: OutlinedButton.icon(
                  onPressed: () async {
                    final now = DateTime.now();
                    final p = await showDatePicker(context: ctx, initialDate: dl ?? now.add(const Duration(days: 180)), firstDate: now, lastDate: DateTime(now.year + 30));
                    if (p != null) setS(() => dl = p);
                  },
                  icon: const Icon(Icons.event),
                  label: Text(dl == null ? 'শেষ তারিখ (ঐচ্ছিক)' : 'শেষ তারিখ: ${dOnly(dl!)}'))),
          if (dl != null) IconButton(icon: const Icon(Icons.close), onPressed: () => setS(() => dl = null)),
        ]),
        const SizedBox(height: 14),
        SizedBox(
            width: double.infinity,
            height: 50,
            child: FilledButton(
                onPressed: () {
                  final t = parseAmt(target.text);
                  if (name.text.trim().isEmpty) {
                    setS(() => err = 'লক্ষ্যের নাম লিখুন');
                    return;
                  }
                  if (t == null || t <= 0) {
                    setS(() => err = 'সঠিক টাকার পরিমাণ লিখুন');
                    return;
                  }
                  final data = <String, dynamic>{'name': name.text.trim(), 'target': t, 'deadline': dl == null ? null : Timestamp.fromDate(dl!)};
                  if (edit != null) {
                    fire(edit.reference.update(data));
                  } else {
                    fire(goalCol.add({...data, 'saved': parseAmt(saved.text) ?? 0, 'createdAt': Timestamp.now()}).then((_) {}));
                  }
                  Navigator.pop(ctx);
                },
                child: const Text('সংরক্ষণ'))),
      ]);
}

// ═════════════════ ৫) ঋণ ও কিস্তি ═════════════════
DateTime nextDueDate(int day) {
  final n = DateTime.now();
  DateTime mk(int y, int m) {
    final dim = DateTime(y, m + 1, 0).day;
    return DateTime(y, m, day > dim ? dim : day);
  }

  var d = mk(n.year, n.month);
  if (d.isBefore(DateTime(n.year, n.month, n.day))) d = mk(n.year, n.month + 1);
  return d;
}

class LoansPage extends StatelessWidget {
  const LoansPage({super.key});
  @override
  Widget build(BuildContext c) => Scaffold(
      appBar: AppBar(title: const Text('ঋণ ও কিস্তি')),
      floatingActionButton: FloatingActionButton.extended(onPressed: () => loanForm(c), icon: const Icon(Icons.add), label: const Text('নতুন ঋণ / কিস্তি')),
      body: ColView(
          col: loanCol,
          builder: (c, docs) {
            num owe = 0, lent = 0;
            for (final d in docs) {
              final m = d.data();
              final rem = numOf(m, 'total') - numOf(m, 'paid');
              if (rem <= 0) continue;
              if (str(m, 'kind') == 'given') {
                lent += rem;
              } else {
                owe += rem;
              }
            }
            return ListView(padding: const EdgeInsets.only(bottom: 96), children: [
              hero(c, [
                Row(children: [Expanded(child: statBox('আমাকে শোধ করতে হবে', tk(owe))), const SizedBox(width: 10), Expanded(child: statBox('আমি পাব (ধার দিয়েছি)', tk(lent)))]),
              ]),
              if (docs.isEmpty) emptyNote('কোনো ঋণ বা কিস্তি নেই।\nব্যাংক লোন, ফোন/বাইকের কিস্তি, বা কাউকে ধার দিলে এখানে লিখে রাখুন।'),
              for (final d in docs) loanCard(c, d),
            ]);
          }));

  Widget loanCard(BuildContext c, Doc d) {
    final m = d.data();
    final given = str(m, 'kind') == 'given';
    final name = str(m, 'name');
    final total = numOf(m, 'total');
    final paid = numOf(m, 'paid');
    final inst = numOf(m, 'inst');
    final day = intOf(m, 'day', 0);
    final rem = total - paid;
    final done = rem <= 0;
    final ratio = total <= 0 ? 0.0 : (paid / total).clamp(0.0, 1.0).toDouble();
    final lines = <String>[];
    if (!done && inst > 0) lines.add('কিস্তি ${tk(inst)} • আরও ${nbn((rem / inst).ceil())} টি বাকি');
    if (!done && day > 0) lines.add('পরের কিস্তি: ${dOnly(nextDueDate(day))}');
    if (str(m, 'note').isNotEmpty) lines.add(str(m, 'note'));
    final col = done ? Colors.green : (given ? Colors.blue : Theme.of(c).colorScheme.primary);
    return card(Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 8, 12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(given ? Icons.call_made : Icons.call_received, size: 18, color: col),
            const SizedBox(width: 6),
            Expanded(child: Text('${done ? '✅ ' : ''}$name', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
            PopupMenuButton<int>(
                onSelected: (v) async {
                  if (v == 0) {
                    loanForm(c, edit: d);
                  } else {
                    final ok = await confirmDel(c, 'এটি মুছবেন?');
                    if (ok) fire(d.reference.delete());
                  }
                },
                itemBuilder: (_) => const [PopupMenuItem(value: 0, child: Text('এডিট')), PopupMenuItem(value: 1, child: Text('মুছুন'))]),
          ]),
          Padding(padding: const EdgeInsets.only(right: 8), child: LinearProgressIndicator(value: ratio, minHeight: 10, borderRadius: BorderRadius.circular(9), color: col)),
          const SizedBox(height: 8),
          Text('${given ? 'আদায় হয়েছে' : 'শোধ হয়েছে'} ${tk(paid)} / মোট ${tk(total)}${done ? ' — সম্পূর্ণ' : ' • বাকি ${tk(rem)}'}', style: const TextStyle(fontSize: 13)),
          for (final l in lines) Text(l, style: const TextStyle(fontSize: 12.5, color: Colors.black54)),
          if (!done)
            Padding(
                padding: const EdgeInsets.only(top: 8),
                child: OutlinedButton.icon(
                    onPressed: () => amountDialog(c,
                        title: given ? '$name — আদায়' : '$name — কিস্তি / শোধ',
                        label: given ? 'কত টাকা ফেরত পেলেন' : 'কত টাকা দিলেন',
                        initial: inst > 0 ? plain(inst > rem ? rem : inst) : '',
                        checkLabel: given ? 'খাতায় আয় হিসেবে যোগ করুন' : 'খাতায় ব্যয় (কিস্তি) হিসেবে যোগ করুন',
                        validate: (v) => v > rem ? 'বাকি আছে মাত্র ${tk(rem)}' : null,
                        onOk: (v, ck) {
                          fire(d.reference.update({'paid': FieldValue.increment(v)}));
                          if (ck) postCash(isIn: given, amt: v, cat: given ? 'বাকি আদায়' : 'কিস্তি / ঋণ শোধ', note: name);
                        }),
                    icon: Icon(given ? Icons.download_done : Icons.payments_outlined),
                    label: Text(given ? 'আদায় হলো' : 'কিস্তি দিলাম'))),
        ])));
  }
}

void loanForm(BuildContext c, {Doc? edit}) {
  final m = edit?.data() ?? <String, dynamic>{};
  var given = str(m, 'kind') == 'given';
  final name = TextEditingController(text: str(m, 'name'));
  final total = TextEditingController(text: edit == null ? '' : plain(numOf(m, 'total')));
  final paid = TextEditingController(text: edit == null ? '' : plain(numOf(m, 'paid')));
  final inst = TextEditingController(text: numOf(m, 'inst') > 0 ? plain(numOf(m, 'inst')) : '');
  final day = TextEditingController(text: intOf(m, 'day', 0) > 0 ? '${intOf(m, 'day', 0)}' : '');
  final note = TextEditingController(text: str(m, 'note'));
  String? err;
  sheet(c, (ctx, setS) => [
        sheetTitle(edit == null ? 'নতুন ঋণ / কিস্তি' : 'এডিট'),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: ChoiceChip(label: const SizedBox(width: double.infinity, child: Text('আমি শোধ করছি', textAlign: TextAlign.center)), selected: !given, onSelected: (_) => setS(() => given = false))),
          const SizedBox(width: 8),
          Expanded(child: ChoiceChip(label: const SizedBox(width: double.infinity, child: Text('আমি ধার দিয়েছি', textAlign: TextAlign.center)), selected: given, onSelected: (_) => setS(() => given = true))),
        ]),
        const SizedBox(height: 12),
        TextField(controller: name, autofocus: edit == null, decoration: deco(label: given ? 'কাকে ধার দিয়েছেন' : 'নাম (যেমন: ব্যাংক লোন, ফোনের কিস্তি)', prefix: const Icon(Icons.account_balance_outlined))),
        const SizedBox(height: 10),
        TextField(controller: total, keyboardType: numKb, inputFormatters: amtFmt, decoration: deco(label: 'মোট টাকা', err: err, prefix: const Icon(Icons.currency_exchange))),
        const SizedBox(height: 10),
        TextField(controller: paid, keyboardType: numKb, inputFormatters: amtFmt, decoration: deco(label: given ? 'এ পর্যন্ত ফেরত পেয়েছেন (ঐচ্ছিক)' : 'এ পর্যন্ত শোধ করেছেন (ঐচ্ছিক)')),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: TextField(controller: inst, keyboardType: numKb, inputFormatters: amtFmt, decoration: deco(label: 'কিস্তির পরিমাণ (ঐচ্ছিক)'))),
          const SizedBox(width: 10),
          Expanded(child: TextField(controller: day, keyboardType: TextInputType.number, decoration: deco(label: 'প্রতি মাসের তারিখ'))),
        ]),
        const SizedBox(height: 10),
        TextField(controller: note, decoration: deco(label: 'নোট (ঐচ্ছিক)')),
        const SizedBox(height: 14),
        SizedBox(
            width: double.infinity,
            height: 50,
            child: FilledButton(
                onPressed: () {
                  final t = parseAmt(total.text);
                  final dv = day.text.trim().isEmpty ? 0 : (int.tryParse(toEn(day.text).trim()) ?? -1);
                  if (name.text.trim().isEmpty) {
                    setS(() => err = 'নাম লিখুন');
                    return;
                  }
                  if (t == null || t <= 0) {
                    setS(() => err = 'সঠিক টাকার পরিমাণ লিখুন');
                    return;
                  }
                  if (dv < 0 || dv > 31) {
                    setS(() => err = 'তারিখ ১ থেকে ৩১ এর মধ্যে দিন');
                    return;
                  }
                  final data = <String, dynamic>{
                    'kind': given ? 'given' : 'taken',
                    'name': name.text.trim(),
                    'total': t,
                    'paid': parseAmt(paid.text) ?? 0,
                    'inst': parseAmt(inst.text) ?? 0,
                    'day': dv,
                    'note': note.text.trim(),
                  };
                  if (edit != null) {
                    fire(edit.reference.update(data));
                  } else {
                    fire(loanCol.add({...data, 'createdAt': Timestamp.now()}).then((_) {}));
                  }
                  Navigator.pop(ctx);
                },
                child: const Text('সংরক্ষণ'))),
      ]);
}

// ═════════════════ ৬) মাসভিত্তিক আয়-ব্যয় চার্ট ═════════════════
class ChartPage extends StatefulWidget {
  const ChartPage({super.key});
  @override
  State<ChartPage> createState() => _ChartState();
}

class _ChartState extends State<ChartPage> {
  late final List<DateTime> months = () {
    final n = DateTime.now();
    return [for (var i = 5; i >= 0; i--) DateTime(n.year, n.month - i)];
  }();
  late Future<QuerySnapshot<Map<String, dynamic>>> f = cashbook.where('date', isGreaterThanOrEqualTo: Timestamp.fromDate(months.first)).get();

  Widget bar(double h, Color col) => Container(width: 12, height: h, decoration: BoxDecoration(color: col, borderRadius: const BorderRadius.vertical(top: Radius.circular(4))));

  @override
  Widget build(BuildContext c) => Scaffold(
      appBar: AppBar(title: const Text('মাসিক আয়-ব্যয় চার্ট')),
      body: FutureBuilder<QuerySnapshot<Map<String, dynamic>>>(
          future: f,
          builder: (c, s) {
            if (s.hasError) return const Center(child: Text('লোড করা যায়নি'));
            if (!s.hasData) return const LogoLoader(size: 120);
            final inc = List<num>.filled(6, 0);
            final exp = List<num>.filled(6, 0);
            for (final d in s.data!.docs) {
              final m = d.data();
              final w = dtOf(m, 'date');
              if (w == null) continue;
              final i = (w.year - months.first.year) * 12 + w.month - months.first.month;
              if (i < 0 || i > 5) continue;
              if (str(m, 'type') == 'out') {
                exp[i] += numOf(m, 'amount');
              } else {
                inc[i] += numOf(m, 'amount');
              }
            }
            num maxV = 0;
            for (var i = 0; i < 6; i++) {
              if (inc[i] > maxV) maxV = inc[i];
              if (exp[i] > maxV) maxV = exp[i];
            }
            double hOf(num v) => maxV <= 0 ? 2.0 : (v / maxV * 140).clamp(2.0, 140.0).toDouble();
            final active = [for (var i = 0; i < 6; i++) if (exp[i] > 0) exp[i]];
            final avg = active.isEmpty ? 0 : active.fold<num>(0, (a, b) => a + b) / active.length;
            return ListView(padding: const EdgeInsets.only(bottom: 30), children: [
              card(Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      const Text('শেষ ৬ মাস', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                      const Spacer(),
                      Container(width: 10, height: 10, color: Colors.green),
                      const Text(' আয়   ', style: TextStyle(fontSize: 12.5)),
                      Container(width: 10, height: 10, color: Colors.red),
                      const Text(' ব্যয়', style: TextStyle(fontSize: 12.5)),
                    ]),
                    const SizedBox(height: 16),
                    Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                      for (var i = 0; i < 6; i++)
                        Expanded(
                            child: Column(children: [
                          SizedBox(height: 142, child: Row(crossAxisAlignment: CrossAxisAlignment.end, mainAxisAlignment: MainAxisAlignment.center, children: [bar(hOf(inc[i]), Colors.green), const SizedBox(width: 4), bar(hOf(exp[i]), Colors.red)])),
                          const SizedBox(height: 6),
                          Text(DateFormat('MMM', 'bn').format(months[i]), style: const TextStyle(fontSize: 11.5)),
                        ])),
                    ]),
                  ]))),
              card(Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(children: [
                    for (var i = 5; i >= 0; i--)
                      Padding(
                          padding: const EdgeInsets.symmetric(vertical: 5),
                          child: Row(children: [
                            Expanded(flex: 3, child: Text(monthName(months[i]), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13))),
                            Expanded(flex: 2, child: FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerRight, child: Text(tk(inc[i]), style: const TextStyle(color: Colors.green, fontSize: 13)))),
                            Expanded(flex: 2, child: FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerRight, child: Text(tk(exp[i]), style: const TextStyle(color: Colors.red, fontSize: 13)))),
                            Expanded(flex: 2, child: FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerRight, child: Text(tk(inc[i] - exp[i]), style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13, color: inc[i] - exp[i] < 0 ? Colors.red : Colors.green)))),
                          ])),
                    const Divider(),
                    Text(avg > 0 ? 'গড় মাসিক খরচ: ${tk(avg)}' : 'এখনো কোনো খরচের এন্ট্রি নেই', style: const TextStyle(color: Colors.black54)),
                    const Text('ডানে: আয় • ব্যয় • সঞ্চয় (আয় − ব্যয়)', style: TextStyle(color: Colors.black45, fontSize: 11.5)),
                  ]))),
            ]);
          }));
}

// ═════════════════ ৭) অ্যাপ সাজান (কোন কোন সুবিধা চালু থাকবে) ═════════════════
const modInfo = <String, List<Object>>{
  'cust': ['কাস্টমার বাকি ও তাগাদা', 'কাকে কত টাকা বাকি দিয়েছেন, তাগাদা, WhatsApp/SMS', Icons.people_alt],
  'cash': ['আয়-ব্যয় খাতা ও বাজেট', 'প্রতিদিনের আয়-খরচ, মাসিক বাজেট, PDF রিপোর্ট', Icons.menu_book],
  'stock': ['পণ্য ও স্টক', 'পণ্য, মজুদ, ক্রয়-বিক্রয়, কম স্টক সতর্কতা', Icons.inventory_2],
  'bazar': ['বাজার তালিকা', 'বাজারের তালিকা বানান ও শেয়ার করুন', Icons.shopping_cart],
  'accts': ['অ্যাকাউন্ট ব্যালেন্স', 'নগদ, বিকাশ, ব্যাংক — কোথায় কত টাকা', Icons.account_balance_wallet],
  'loans': ['ঋণ ও কিস্তি', 'লোন, কিস্তি, ধার — কত শোধ হলো, কত বাকি', Icons.account_balance],
  'goals': ['সঞ্চয় লক্ষ্য', 'টার্গেট ঠিক করে ধাপে ধাপে জমান', Icons.flag],
  'recur': ['নিয়মিত এন্ট্রি', 'বাসা ভাড়া, বেতন, বিল — প্রতি মাসে নিজে যোগ হবে', Icons.event_repeat],
  'chart': ['মাসিক চার্ট', 'শেষ ৬ মাসের আয়-ব্যয় তুলনা', Icons.bar_chart],
};

const modPresets = <String, List<String>>{
  'ব্যবসায়ী': ['cust', 'cash', 'stock', 'accts', 'loans', 'recur', 'chart'],
  'ব্যক্তিগত': ['cash', 'bazar', 'accts', 'goals', 'loans', 'recur', 'chart'],
  'সব চালু': allMods,
};

void setMods(Set<String> s) {
  mods.value = s;
  savePrefs({'mods': s.toList()});
}

class ModulesPage extends StatelessWidget {
  final bool first;
  const ModulesPage({super.key, this.first = false});

  @override
  Widget build(BuildContext c) => Scaffold(
      appBar: AppBar(title: Text(first ? 'আপনি কীভাবে ব্যবহার করবেন?' : 'অ্যাপ সাজান'), automaticallyImplyLeading: !first),
      bottomNavigationBar: first
          ? SafeArea(
              child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: SizedBox(height: 50, child: FilledButton(onPressed: () => Navigator.pop(c), child: const Text('শুরু করুন')))))
          : null,
      body: ValueListenableBuilder<Set<String>>(
          valueListenable: mods,
          builder: (c, md, _) => ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 30), children: [
                Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Text('আপনার কাজ অনুযায়ী বেছে নিন। যেকোনো সময় "আরও → অ্যাপ সাজান" থেকে বদলাতে পারবেন। আপনার ডাটা মুছবে না।', style: TextStyle(color: Colors.black54))),
                Wrap(spacing: 8, runSpacing: 0, children: [
                  for (final e in modPresets.entries) ActionChip(avatar: const Icon(Icons.auto_awesome, size: 16), label: Text(e.key), onPressed: () => setMods(Set<String>.of(e.value))),
                ]),
                const SizedBox(height: 6),
                for (final k in allMods)
                  SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      secondary: Icon(modInfo[k]![2] as IconData),
                      title: Text(modInfo[k]![0] as String, style: const TextStyle(fontWeight: FontWeight.w700)),
                      subtitle: Text(modInfo[k]![1] as String, style: const TextStyle(fontSize: 12.5)),
                      value: md.contains(k),
                      onChanged: (v) {
                        final n = Set<String>.of(md);
                        if (v) {
                          n.add(k);
                        } else {
                          n.remove(k);
                        }
                        setMods(n);
                      }),
              ])));
}
