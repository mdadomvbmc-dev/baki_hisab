import 'dart:convert';
import 'dart:typed_data';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import 'main.dart';
import 'notify.dart';
import 'prompts.dart';
import 'report.dart';

int pinHashOf(String pin) => stableHash('dhardena|$pin');

Widget shopAvatar({double r = 22}) => ValueListenableBuilder<Uint8List?>(
    valueListenable: shopLogo,
    builder: (_, b, __) => ValueListenableBuilder<String>(
        valueListenable: shop,
        builder: (c, n, ___) => CircleAvatar(
            radius: r,
            backgroundColor: Theme.of(c).colorScheme.primaryContainer,
            backgroundImage: b == null ? null : MemoryImage(b),
            child: b == null ? Text(n.trim().isEmpty ? '৳' : n.trim().characters.first, style: TextStyle(fontWeight: FontWeight.w800, fontSize: r * 0.9)) : null)));

// ───────── "আরও" ট্যাব ─────────
class MorePage extends StatelessWidget {
  const MorePage({super.key});

  Widget tileBtn(BuildContext c, IconData i, String t, Widget Function() page) => card(
      InkWell(
          onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => page())),
          child: Padding(
              padding: const EdgeInsets.all(10),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(i, size: 32, color: Theme.of(c).colorScheme.primary),
                const SizedBox(height: 8),
                Text(t, maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
              ]))),
      margin: const EdgeInsets.all(6));

  @override
  Widget build(BuildContext c) => ListView(padding: const EdgeInsets.only(bottom: 30), children: [
        card(InkWell(
            onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const ProfilePage())),
            child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(children: [
                  shopAvatar(r: 30),
                  const SizedBox(width: 14),
                  Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    ValueListenableBuilder<String>(valueListenable: shop, builder: (_, s, __) => Text(s, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17))),
                    ValueListenableBuilder<String>(
                        valueListenable: owner,
                        builder: (_, o, __) => Text(o.isEmpty ? 'প্রোফাইল সম্পাদনা করতে চাপুন' : o, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.black54))),
                  ])),
                  const Icon(Icons.chevron_right),
                ])))),
        LayoutBuilder(builder: (c, bc) {
          final cols = bc.maxWidth > 560 ? 3 : 2;
          return GridView.count(
              crossAxisCount: cols,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              childAspectRatio: 1.2,
              padding: const EdgeInsets.all(8),
              children: [
                tileBtn(c, Icons.assessment, 'রিপোর্ট কেন্দ্র\n(PDF)', () => const ReportCenter()),
                tileBtn(c, Icons.checklist, 'দৈনিক কাজ', () => Scaffold(appBar: AppBar(title: const Text('দৈনিক কাজ')), body: const TasksPage())),
                tileBtn(c, Icons.auto_awesome, 'প্রম্পট স্টোর', () => const PromptStore()),
                tileBtn(c, Icons.storefront, 'প্রোফাইল', () => const ProfilePage()),
                tileBtn(c, Icons.settings, 'সেটিংস', () => const SettingsPage()),
              ]);
        }),
      ]);
}

// ───────── প্রোফাইল (নাম, লোগো, যোগাযোগ) ─────────
class ProfilePage extends StatefulWidget {
  final bool first;
  const ProfilePage({super.key, this.first = false});
  @override
  State<ProfilePage> createState() => _PPState();
}

class _PPState extends State<ProfilePage> {
  late final shopC = TextEditingController(text: shop.value == defShop ? '' : shop.value);
  late final ownerC = TextEditingController(text: owner.value);
  late final phoneC = TextEditingController(text: shopPhone.value);
  late final addrC = TextEditingController(text: shopAddr.value);
  Uint8List? logo = shopLogo.value;
  bool changed = false;
  String? err;

  @override
  void dispose() {
    shopC.dispose();
    ownerC.dispose();
    phoneC.dispose();
    addrC.dispose();
    super.dispose();
  }

  Future<void> pick() async {
    try {
      final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 320, maxHeight: 320, imageQuality: 85);
      if (x == null) return;
      final b = await x.readAsBytes();
      if (b.length > 450000) {
        if (mounted) toast(context, 'ছবিটি অনেক বড়, ছোট ছবি বেছে নিন');
        return;
      }
      if (mounted) {
        setState(() {
          logo = b;
          changed = true;
        });
      }
    } catch (_) {
      if (mounted) toast(context, 'ছবি নেওয়া যায়নি');
    }
  }

  void save() {
    final name = shopC.text.trim();
    if (name.isEmpty) {
      setState(() => err = 'দোকান / ব্যবসার নাম দিন');
      return;
    }
    final m = <String, dynamic>{'shop': name, 'owner': ownerC.text.trim(), 'phone': phoneC.text.trim(), 'address': addrC.text.trim()};
    shop.value = name;
    owner.value = ownerC.text.trim();
    shopPhone.value = phoneC.text.trim();
    shopAddr.value = addrC.text.trim();
    if (changed) {
      m['logo'] = logo == null ? '' : base64Encode(logo!);
      shopLogo.value = logo;
    }
    savePrefs(m);
    Navigator.pop(context);
    toast(context, 'প্রোফাইল সংরক্ষণ হয়েছে ✅');
  }

  @override
  Widget build(BuildContext c) => Scaffold(
      appBar: AppBar(title: Text(widget.first ? 'স্বাগতম! আপনার দোকান সেট করুন' : 'প্রোফাইল', maxLines: 1, overflow: TextOverflow.ellipsis)),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        if (widget.first)
          const Padding(padding: EdgeInsets.only(bottom: 14), child: Text('আপনার নাম ও লোগো রিপোর্ট, মেসেজ ও অ্যাপে দেখানো হবে। পরে যেকোনো সময় বদলানো যাবে।', style: TextStyle(color: Colors.black54))),
        Center(
            child: Column(children: [
          CircleAvatar(
              radius: 52,
              backgroundColor: Theme.of(c).colorScheme.primaryContainer,
              backgroundImage: logo == null ? null : MemoryImage(logo!),
              child: logo == null ? Text(shopC.text.trim().isEmpty ? '৳' : shopC.text.trim().characters.first, style: const TextStyle(fontSize: 38, fontWeight: FontWeight.w800)) : null),
          const SizedBox(height: 10),
          Wrap(spacing: 8, children: [
            OutlinedButton.icon(onPressed: pick, icon: const Icon(Icons.photo_library_outlined), label: Text(logo == null ? 'লোগো / ছবি দিন' : 'ছবি বদলান')),
            if (logo != null)
              TextButton.icon(
                  onPressed: () => setState(() {
                        logo = null;
                        changed = true;
                      }),
                  icon: const Icon(Icons.close),
                  label: const Text('সরান')),
          ]),
        ])),
        const SizedBox(height: 18),
        TextField(controller: shopC, onChanged: (_) => setState(() {}), decoration: deco(label: 'দোকান / ব্যবসার নাম *', prefix: const Icon(Icons.storefront_outlined), err: err)),
        const SizedBox(height: 12),
        TextField(controller: ownerC, decoration: deco(label: 'মালিকের নাম', prefix: const Icon(Icons.person_outline))),
        const SizedBox(height: 12),
        TextField(controller: phoneC, keyboardType: TextInputType.phone, decoration: deco(label: 'মোবাইল নম্বর', prefix: const Icon(Icons.phone_outlined))),
        const SizedBox(height: 12),
        TextField(controller: addrC, maxLines: 2, decoration: deco(label: 'ঠিকানা', prefix: const Icon(Icons.place_outlined))),
        const SizedBox(height: 22),
        SizedBox(height: 52, child: FilledButton(onPressed: save, child: const Text('সংরক্ষণ করুন', style: TextStyle(fontSize: 16)))),
        if (widget.first) TextButton(onPressed: () => Navigator.pop(c), child: const Text('পরে করব')),
      ]));
}

// ───────── সেটিংস ─────────
class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SPState();
}

class _SPState extends State<SettingsPage> {
  String ver = '';
  @override
  void initState() {
    super.initState();
    PackageInfo.fromPlatform().then((p) {
      if (mounted) setState(() => ver = p.version);
    }).catchError((_) {});
  }

  Widget head(String t) => Padding(padding: const EdgeInsets.fromLTRB(4, 18, 4, 6), child: Text(t, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14, color: Theme.of(context).colorScheme.primary)));

  Future<void> pinSetup() async {
    final a = TextEditingController(), b = TextEditingController();
    String? err;
    final ok = await showDialog<bool>(
        context: context,
        builder: (x) => StatefulBuilder(
            builder: (x, setS) => AlertDialog(
                    title: const Text('৪ সংখ্যার PIN দিন'),
                    content: SingleChildScrollView(
                        child: Column(mainAxisSize: MainAxisSize.min, children: [
                      TextField(controller: a, obscureText: true, keyboardType: TextInputType.number, maxLength: 4, inputFormatters: [FilteringTextInputFormatter.digitsOnly], decoration: deco(label: 'নতুন PIN')),
                      TextField(controller: b, obscureText: true, keyboardType: TextInputType.number, maxLength: 4, inputFormatters: [FilteringTextInputFormatter.digitsOnly], decoration: deco(label: 'আবার লিখুন', err: err)),
                    ])),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(x, false), child: const Text('বাতিল')),
                      FilledButton(
                          onPressed: () {
                            if (a.text.length != 4) {
                              setS(() => err = '৪ সংখ্যার PIN দিন');
                              return;
                            }
                            if (a.text != b.text) {
                              setS(() => err = 'দুটি PIN মিলছে না');
                              return;
                            }
                            Navigator.pop(x, true);
                          },
                          child: const Text('সেট করুন')),
                    ])));
    if (ok == true) {
      final h = pinHashOf(a.text);
      pinHash.value = h;
      savePrefs({'pin': h});
      if (mounted) toast(context, 'অ্যাপ লক চালু হয়েছে 🔒');
    }
  }

  void pinOff() {
    pinHash.value = null;
    savePrefs({'pin': FieldValue.delete()});
    toast(context, 'অ্যাপ লক বন্ধ হয়েছে');
  }

  @override
  Widget build(BuildContext c) {
    final email = FirebaseAuth.instance.currentUser?.email ?? '';
    return Scaffold(
        appBar: AppBar(title: const Text('সেটিংস')),
        body: ListView(padding: const EdgeInsets.fromLTRB(16, 0, 16, 30), children: [
          head('থিম ও ডিজাইন'),
          const Text('মূল রঙ', style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 10),
          ValueListenableBuilder<int>(
              valueListenable: seed,
              builder: (_, cur, __) => Wrap(spacing: 12, runSpacing: 12, children: [
                    for (final k in themeSeeds)
                      GestureDetector(
                          onTap: () {
                            seed.value = k;
                            savePrefs({'seed': k});
                          },
                          child: CircleAvatar(radius: 21, backgroundColor: Color(k), child: cur == k ? const Icon(Icons.check, color: Colors.white) : null))
                  ])),
          const SizedBox(height: 16),
          const Text('ব্যাকগ্রাউন্ড', style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          ValueListenableBuilder<int>(
              valueListenable: bgIdx,
              builder: (_, cur, __) => Wrap(spacing: 8, children: [
                    for (var i = 0; i < bgColors.length; i++)
                      ChoiceChip(
                          avatar: CircleAvatar(backgroundColor: bgColors[i], radius: 9),
                          label: Text(bgNames[i]),
                          selected: cur == i,
                          onSelected: (_) {
                            bgIdx.value = i;
                            savePrefs({'bg': i});
                          })
                  ])),
          if (mobile) ...[
            head('অ্যালার্ম ও নোটিফিকেশন'),
            ValueListenableBuilder<bool>(
                valueListenable: loopAlarm,
                builder: (_, v, __) => SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('বন্ধ না করা পর্যন্ত অ্যালার্ম বাজবে'),
                    subtitle: const Text('চালু থাকলে "বন্ধ করুন" চাপার আগে পর্যন্ত বাজতেই থাকবে'),
                    value: v,
                    onChanged: (x) {
                      loopAlarm.value = x;
                      savePrefs({'loop': x});
                      reschedule(force: true);
                    })),
            ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.alarm_on),
                title: const Text('টেস্ট অ্যালার্ম'),
                subtitle: const Text('১০ সেকেন্ড পরে বাজবে — অ্যাপ ব্যাকগ্রাউন্ডে নিয়ে দেখুন'),
                onTap: () async {
                  await testAlarm();
                  if (c.mounted) toast(c, '১০ সেকেন্ড পরে অ্যালার্ম বাজবে ⏰');
                }),
            ValueListenableBuilder<bool>(
                valueListenable: dailyOn,
                builder: (_, v, __) => SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('দৈনিক হিসাব রিমাইন্ডার'),
                    subtitle: ValueListenableBuilder<int>(valueListenable: dailyH, builder: (_, h, __) => ValueListenableBuilder<int>(valueListenable: dailyM, builder: (_, m, ___) => Text('প্রতিদিন ${timeOnly(DateTime(2000, 1, 1, h, m))} এ মনে করাবে'))),
                    value: v,
                    onChanged: (x) {
                      dailyOn.value = x;
                      savePrefs({'daily': x, 'dh': dailyH.value, 'dm': dailyM.value});
                      reschedule(force: true);
                    })),
            ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.schedule),
                title: const Text('রিমাইন্ডারের সময় বদলান'),
                onTap: () async {
                  final t = await showTimePicker(context: c, initialTime: TimeOfDay(hour: dailyH.value, minute: dailyM.value));
                  if (t == null) return;
                  dailyH.value = t.hour;
                  dailyM.value = t.minute;
                  savePrefs({'dh': t.hour, 'dm': t.minute});
                  reschedule(force: true);
                }),
          ],
          if (isAndroid) ...[
            ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.notifications_active_outlined),
                title: const Text('নোটিফিকেশনের অনুমতি'),
                onTap: () async {
                  try {
                    await Permission.notification.request();
                  } catch (_) {}
                  reschedule(force: true);
                }),
            ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.alarm_add),
                title: const Text('সঠিক সময়ের অ্যালার্ম ও ব্যাটারি ছাড়'),
                subtitle: const Text('সেটিংস পেজ খুলবে, অনুমতি দিয়ে ব্যাক করুন'),
                onTap: () async {
                  await askAlarmPerms();
                  reschedule(force: true);
                }),
          ],
          head('নিরাপত্তা'),
          ValueListenableBuilder<int?>(
              valueListenable: pinHash,
              builder: (_, h, __) => h == null
                  ? ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.lock_outline), title: const Text('অ্যাপ লক (PIN) চালু করুন'), subtitle: const Text('অ্যাপ খুলতে ৪ সংখ্যার PIN লাগবে'), onTap: pinSetup)
                  : Column(children: [
                      ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.lock), title: const Text('PIN বদলান'), onTap: pinSetup),
                      ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.lock_open), title: const Text('অ্যাপ লক বন্ধ করুন'), onTap: pinOff),
                    ])),
          head('একাউন্ট'),
          if (email.isNotEmpty) ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.account_circle_outlined), title: const Text('লগইন একাউন্ট'), subtitle: Text(email, maxLines: 1, overflow: TextOverflow.ellipsis)),
          if (email.isNotEmpty)
            ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.password),
                title: const Text('পাসওয়ার্ড বদলান'),
                subtitle: const Text('ইমেইলে রিসেট লিংক যাবে'),
                onTap: () async {
                  try {
                    await FirebaseAuth.instance.sendPasswordResetEmail(email: email);
                    if (c.mounted) toast(c, 'রিসেট লিংক ইমেইলে পাঠানো হয়েছে');
                  } catch (_) {
                    if (c.mounted) toast(c, 'পাঠানো যায়নি, ইন্টারনেট দেখুন');
                  }
                }),
          ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.logout, color: Colors.red), title: const Text('লগআউট'), onTap: () => doLogout(c)),
          head('অ্যাপ'),
          if (!kIsWeb) ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.system_update_alt), title: const Text('নতুন আপডেট খুঁজুন'), subtitle: Text(ver.isEmpty ? '' : 'বর্তমান সংস্করণ $ver'), onTap: () => checkUpdate(c)),
          ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.bug_report_outlined), title: const Text('ত্রুটির লগ'), subtitle: const Text('অ্যাপে সমস্যা হলে এখান থেকে কপি করে পাঠান'), onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const CrashLogPage()))),
          ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.info_outline),
              title: const Text('Dhar Dena সম্পর্কে'),
              onTap: () => showAboutDialog(
                  context: c,
                  applicationName: 'Dhar Dena (ধার দেনা)',
                  applicationVersion: ver,
                  applicationIcon: Image.asset('assets/logo.png', width: 56),
                  children: const [Padding(padding: EdgeInsets.only(top: 10), child: Text('বাকি-দেনা, আয়-ব্যয় খাতা, বাজার তালিকা ও প্রম্পট স্টোরসহ ব্যবসার দৈনন্দিন হিসাবের সহজ অ্যাপ।'))])),
        ]));
  }
}

// ───────── PIN লক স্ক্রিন ─────────
class PinScreen extends StatefulWidget {
  final int hash;
  final VoidCallback onOk;
  const PinScreen({super.key, required this.hash, required this.onOk});
  @override
  State<PinScreen> createState() => _PinState();
}

class _PinState extends State<PinScreen> {
  String pin = '';
  String? err;

  void tap(String d) {
    if (pin.length >= 4) return;
    setState(() {
      pin += d;
      err = null;
    });
    if (pin.length == 4) {
      if (pinHashOf(pin) == widget.hash) {
        widget.onOk();
      } else {
        HapticFeedback.heavyImpact();
        setState(() {
          pin = '';
          err = 'ভুল PIN, আবার চেষ্টা করুন';
        });
      }
    }
  }

  void back() {
    if (pin.isEmpty) return;
    setState(() => pin = pin.substring(0, pin.length - 1));
  }

  Future<void> forgot() async {
    final pc = TextEditingController();
    final ok = await showDialog<bool>(
        context: context,
        builder: (x) => AlertDialog(
                title: const Text('PIN ভুলে গেছেন?'),
                content: TextField(controller: pc, obscureText: true, decoration: deco(label: 'একাউন্টের পাসওয়ার্ড দিন')),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(x, false), child: const Text('বাতিল')),
                  FilledButton(onPressed: () => Navigator.pop(x, true), child: const Text('যাচাই করুন')),
                ]));
    if (ok != true) return;
    try {
      final u = FirebaseAuth.instance.currentUser!;
      await u.reauthenticateWithCredential(EmailAuthProvider.credential(email: u.email ?? '', password: pc.text));
      pinHash.value = null;
      savePrefs({'pin': FieldValue.delete()});
      widget.onOk();
    } catch (_) {
      if (mounted) setState(() => err = 'পাসওয়ার্ড ভুল');
    }
  }

  Widget key(String k) {
    if (k.isEmpty) return const SizedBox(width: 88, height: 72);
    return Padding(
        padding: const EdgeInsets.all(6),
        child: SizedBox(
            width: 76,
            height: 60,
            child: FilledButton.tonal(
                onPressed: () => k == '⌫' ? back() : tap(k),
                child: Text(k, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w700)))));
  }

  @override
  Widget build(BuildContext c) => Scaffold(
      body: SafeArea(
          child: Center(
              child: SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    shopAvatar(r: 38),
                    const SizedBox(height: 12),
                    ValueListenableBuilder<String>(valueListenable: shop, builder: (_, s, __) => Text(s, textAlign: TextAlign.center, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800))),
                    const SizedBox(height: 6),
                    const Text('PIN দিন', style: TextStyle(color: Colors.black54)),
                    const SizedBox(height: 16),
                    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      for (var i = 0; i < 4; i++)
                        Container(
                            margin: const EdgeInsets.symmetric(horizontal: 8),
                            width: 16,
                            height: 16,
                            decoration: BoxDecoration(shape: BoxShape.circle, color: i < pin.length ? Theme.of(c).colorScheme.primary : Colors.transparent, border: Border.all(color: Theme.of(c).colorScheme.primary, width: 2))),
                    ]),
                    SizedBox(height: 28, child: err == null ? null : Center(child: Text(err!, style: const TextStyle(color: Colors.red)))),
                    for (final row in const [
                      ['1', '2', '3'],
                      ['4', '5', '6'],
                      ['7', '8', '9'],
                      ['', '0', '⌫']
                    ])
                      Row(mainAxisAlignment: MainAxisAlignment.center, children: [for (final k in row) key(k)]),
                    TextButton(onPressed: forgot, child: const Text('PIN ভুলে গেছি')),
                  ])))));
}
