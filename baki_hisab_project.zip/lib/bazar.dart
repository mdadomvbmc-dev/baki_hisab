import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'main.dart';

const quickItems = ['চাল', 'ডাল', 'তেল', 'চিনি', 'লবণ', 'আটা', 'পেঁয়াজ', 'আলু', 'ডিম', 'দুধ', 'সাবান', 'চা পাতা', 'মসলা', 'সবজি', 'মাছ', 'মাংস'];

List<Map<String, dynamic>> itemsOf(Map<String, dynamic> m) {
  final raw = m['items'];
  if (raw is! List) return <Map<String, dynamic>>[];
  return raw.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
}

// ───────── বাজার তালিকার লিস্ট ─────────
class BazarPage extends StatelessWidget {
  const BazarPage({super.key});

  Future<void> newList(BuildContext c) async {
    final t = TextEditingController(text: 'বাজার — ${dOnly(DateTime.now())}');
    final ok = await showDialog<bool>(
        context: c,
        builder: (x) => AlertDialog(
                title: const Text('নতুন বাজার তালিকা'),
                content: TextField(controller: t, autofocus: true, decoration: deco(label: 'তালিকার নাম')),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(x, false), child: const Text('বাতিল')),
                  FilledButton(onPressed: () => Navigator.pop(x, true), child: const Text('তৈরি করুন')),
                ]));
    if (ok != true) return;
    final title = t.text.trim().isEmpty ? 'বাজার তালিকা' : t.text.trim();
    final r = bazar.doc();
    fire(r.set({'title': title, 'items': <Map<String, dynamic>>[], 'remind': null, 'createdAt': Timestamp.now()}));
    if (c.mounted) Navigator.push(c, MaterialPageRoute(builder: (_) => BazarDetail(r.id)));
  }

  Widget cardFor(BuildContext c, Doc d) {
    final m = d.data();
    final items = itemsOf(m);
    final done = items.where((e) => e['d'] == true).length;
    final total = items.fold<num>(0, (a, e) => a + numOf(e, 'p'));
    final remind = dtOf(m, 'remind');
    final over = remind != null && remind.isBefore(DateTime.now()) && done < items.length;
    return card(InkWell(
        onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => BazarDetail(d.id))),
        child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Text(str(m, 'title'), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
                if (items.isNotEmpty && done == items.length) const Icon(Icons.check_circle, color: Colors.green),
              ]),
              const SizedBox(height: 6),
              Text('${items.length} টি জিনিস • $done টি কেনা হয়েছে', style: const TextStyle(color: Colors.black54)),
              if (total > 0) Text('আনুমানিক মোট: ${tk(total)}', style: const TextStyle(color: Colors.black54)),
              if (remind != null) Text('⏰ ${dt(remind)}', style: TextStyle(color: over ? Colors.red : Colors.black87, fontWeight: FontWeight.w600)),
              const SizedBox(height: 10),
              LinearProgressIndicator(value: items.isEmpty ? 0 : done / items.length, minHeight: 6, borderRadius: BorderRadius.circular(8)),
            ]))));
  }

  @override
  Widget build(BuildContext c) => Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(onPressed: () => newList(c), icon: const Icon(Icons.add_shopping_cart), label: const Text('নতুন তালিকা')),
      body: ValueListenableBuilder<List<Doc>>(
          valueListenable: bazarDocs,
          builder: (c, docs, _) {
            if (docs.isEmpty) {
              return const Center(
                  child: Padding(
                      padding: EdgeInsets.all(32),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.shopping_basket_outlined, size: 72, color: Colors.black26),
                        SizedBox(height: 12),
                        Text('কোনো বাজার তালিকা নেই', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
                        SizedBox(height: 6),
                        Text('নিচের বাটনে চেপে তালিকা বানান, সময় দিলে নোটিফিকেশনে মনে করিয়ে দেবে।', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
                      ])));
            }
            return ListView.builder(padding: const EdgeInsets.only(top: 8, bottom: 96), itemCount: docs.length, itemBuilder: (c, i) => cardFor(c, docs[i]));
          }));
}

// ───────── একটি তালিকার বিস্তারিত ─────────
class BazarDetail extends StatefulWidget {
  final String id;
  const BazarDetail(this.id, {super.key});
  @override
  State<BazarDetail> createState() => _BDState();
}

class _BDState extends State<BazarDetail> {
  late final Stream<DocumentSnapshot<Map<String, dynamic>>> st = bazar.doc(widget.id).snapshots();
  final nameC = TextEditingController(), qtyC = TextEditingController(), priceC = TextEditingController();
  final nameF = FocusNode();
  List<Map<String, dynamic>> cur = <Map<String, dynamic>>[];
  String title = '';
  DocumentReference<Map<String, dynamic>> get ref => bazar.doc(widget.id);

  @override
  void dispose() {
    nameC.dispose();
    qtyC.dispose();
    priceC.dispose();
    nameF.dispose();
    super.dispose();
  }

  void save(List<Map<String, dynamic>> items) => fire(ref.update({'items': items}));

  void addItem(String name, {String qty = '', num? price}) {
    final n = name.trim();
    if (n.isEmpty) return;
    save([
      ...cur,
      {'n': n, 'q': qty.trim(), 'p': price ?? 0, 'd': false}
    ]);
  }

  void addFromFields() {
    if (nameC.text.trim().isEmpty) return;
    addItem(nameC.text, qty: qtyC.text, price: parseAmt(priceC.text));
    nameC.clear();
    qtyC.clear();
    priceC.clear();
    nameF.requestFocus();
  }

  void toggle(int i) {
    final l = [...cur];
    l[i] = {...l[i], 'd': !(l[i]['d'] == true)};
    save(l);
  }

  void removeAt(int i) {
    final l = [...cur];
    l.removeAt(i);
    save(l);
  }

  String shareText() {
    final b = StringBuffer('🛒 $title\n');
    var k = 1;
    num total = 0;
    for (final e in cur) {
      final q = '${e['q'] ?? ''}'.trim();
      final p = numOf(e, 'p');
      total += p;
      final mark = e['d'] == true ? '✅ ' : '';
      final qs = q.isEmpty ? '' : ' — $q';
      final ps = p > 0 ? ' (${tk(p)})' : '';
      b.writeln('$k. $mark${e['n']}$qs$ps');
      k++;
    }
    if (total > 0) b.writeln('\nআনুমানিক মোট: ${tk(total)}');
    b.write('— ${shop.value}');
    return b.toString();
  }

  Future<void> setRemind(DateTime? curAt) async {
    final now = DateTime.now();
    final init = (curAt != null && curAt.isAfter(now)) ? curAt : now;
    final d = await showDatePicker(context: context, firstDate: DateTime(now.year, now.month, now.day), lastDate: now.add(const Duration(days: 730)), initialDate: init);
    if (d == null || !mounted) return;
    final t = await showTimePicker(context: context, initialTime: TimeOfDay(hour: curAt?.hour ?? 8, minute: curAt?.minute ?? 0));
    if (t == null || !mounted) return;
    final at = DateTime(d.year, d.month, d.day, t.hour, t.minute);
    if (at.isBefore(DateTime.now())) {
      toast(context, 'এই সময় পার হয়ে গেছে, ভবিষ্যতের সময় দিন');
      return;
    }
    fire(ref.update({'remind': Timestamp.fromDate(at)}));
    if (mounted) toast(context, 'নোটিফিকেশন সেট হয়েছে ⏰');
  }

  Future<void> deleteList() async {
    final ok = await showDialog<bool>(
        context: context,
        builder: (x) => AlertDialog(title: const Text('তালিকা মুছবেন?'), content: Text('"$title" তালিকাটি মুছে যাবে।'), actions: [
              TextButton(onPressed: () => Navigator.pop(x, false), child: const Text('না')),
              FilledButton(style: FilledButton.styleFrom(backgroundColor: Colors.red), onPressed: () => Navigator.pop(x, true), child: const Text('মুছুন')),
            ]));
    if (ok == true && mounted) {
      final nav = Navigator.of(context);
      fire(ref.delete());
      nav.pop();
    }
  }

  Widget stat(String l, String v) => Expanded(
      child: Column(children: [
        Text(l, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.black54, fontSize: 12)),
        FittedBox(fit: BoxFit.scaleDown, child: Text(v, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
      ]));

  @override
  Widget build(BuildContext c) => StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: st,
      builder: (c, s) {
        final m = s.data?.data();
        if (m == null) {
          return Scaffold(appBar: AppBar(), body: Center(child: s.connectionState == ConnectionState.waiting ? const CircularProgressIndicator() : const Text('তালিকা পাওয়া যায়নি')));
        }
        title = str(m, 'title');
        cur = itemsOf(m);
        final remind = dtOf(m, 'remind');
        final done = cur.where((e) => e['d'] == true).length;
        final total = cur.fold<num>(0, (a, e) => a + numOf(e, 'p'));
        final left = cur.where((e) => e['d'] != true).fold<num>(0, (a, e) => a + numOf(e, 'p'));
        final idx = List<int>.generate(cur.length, (i) => i)
          ..sort((a, b) {
            final x = cur[a]['d'] == true, y = cur[b]['d'] == true;
            return x == y ? a.compareTo(b) : (x ? 1 : -1);
          });
        final have = cur.map((e) => '${e['n']}').toSet();
        return Scaffold(
          appBar: AppBar(title: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis), actions: [
            IconButton(
                icon: const Icon(Icons.copy),
                tooltip: 'তালিকা কপি',
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: shareText()));
                  toast(c, 'তালিকা কপি হয়েছে');
                }),
            IconButton(icon: const Icon(Icons.chat), tooltip: 'WhatsApp এ পাঠান', onPressed: () => openUrl(c, 'https://wa.me/?text=${Uri.encodeComponent(shareText())}')),
            PopupMenuButton<int>(
                onSelected: (v) {
                  if (v == 0) save(cur.where((e) => e['d'] != true).toList());
                  if (v == 1) deleteList();
                },
                itemBuilder: (_) => const [
                      PopupMenuItem(value: 0, child: Text('কেনা জিনিস মুছুন')),
                      PopupMenuItem(value: 1, child: Text('তালিকা মুছুন')),
                    ]),
          ]),
          body: ListView(padding: const EdgeInsets.only(bottom: 40), children: [
            card(Padding(
                padding: const EdgeInsets.all(16),
                child: Row(children: [
                  stat('কেনা হয়েছে', '$done / ${cur.length}'),
                  stat('আনুমানিক মোট', tk(total)),
                  stat('বাকি খরচ', tk(left)),
                ]))),
            card(Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(remind == null ? '⏰ নোটিফিকেশন রিমাইন্ডার সেট নেই' : '⏰ ${dt(remind)}', style: const TextStyle(fontWeight: FontWeight.w600)),
                  Wrap(spacing: 8, children: [
                    TextButton.icon(onPressed: () => setRemind(remind), icon: const Icon(Icons.alarm_add), label: Text(remind == null ? 'সময় সেট করুন' : 'সময় বদলান')),
                    if (remind != null) TextButton.icon(onPressed: () => fire(ref.update({'remind': null})), icon: const Icon(Icons.close), label: const Text('মুছুন')),
                  ]),
                ]))),
            card(Padding(
                padding: const EdgeInsets.all(14),
                child: Column(children: [
                  TextField(controller: nameC, focusNode: nameF, textInputAction: TextInputAction.next, decoration: deco(label: 'জিনিসের নাম', prefix: const Icon(Icons.add_shopping_cart))),
                  const SizedBox(height: 10),
                  Row(children: [
                    Expanded(flex: 3, child: TextField(controller: qtyC, decoration: deco(label: 'পরিমাণ', hint: '২ কেজি'))),
                    const SizedBox(width: 8),
                    Expanded(flex: 3, child: TextField(controller: priceC, keyboardType: numKb, inputFormatters: amtFmt, onSubmitted: (_) => addFromFields(), decoration: deco(label: 'দাম ৳'))),
                    const SizedBox(width: 8),
                    IconButton.filled(onPressed: addFromFields, icon: const Icon(Icons.add)),
                  ]),
                ]))),
            Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Wrap(spacing: 8, runSpacing: 0, children: [
                  for (final q in quickItems)
                    if (!have.contains(q)) ActionChip(label: Text(q), onPressed: () => addItem(q)),
                ])),
            if (cur.isEmpty) const Padding(padding: EdgeInsets.all(32), child: Center(child: Text('তালিকা খালি — জিনিস যোগ করুন', style: TextStyle(color: Colors.black54)))),
            for (final i in idx)
              Dismissible(
                  key: ValueKey('${i}_${cur[i]['n']}_${cur[i]['d']}'),
                  onDismissed: (_) => removeAt(i),
                  background: Container(color: Colors.red.shade100, alignment: Alignment.centerLeft, padding: const EdgeInsets.only(left: 20), child: const Icon(Icons.delete_outline)),
                  secondaryBackground: Container(color: Colors.red.shade100, alignment: Alignment.centerRight, padding: const EdgeInsets.only(right: 20), child: const Icon(Icons.delete_outline)),
                  child: itemTile(i)),
          ]),
        );
      });

  Widget itemTile(int i) {
    final e = cur[i];
    final done = e['d'] == true;
    final q = '${e['q'] ?? ''}'.trim();
    final p = numOf(e, 'p');
    return card(ListTile(
      onTap: () => toggle(i),
      leading: Checkbox(value: done, onChanged: (_) => toggle(i)),
      title: Text('${e['n']}', maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: FontWeight.w700, decoration: done ? TextDecoration.lineThrough : null, color: done ? Colors.black45 : null)),
      subtitle: q.isEmpty ? null : Text(q, maxLines: 1, overflow: TextOverflow.ellipsis),
      trailing: p > 0 ? ConstrainedBox(constraints: const BoxConstraints(maxWidth: 90), child: FittedBox(fit: BoxFit.scaleDown, child: Text(tk(p), style: const TextStyle(fontWeight: FontWeight.w800)))) : null,
    ));
  }
}
