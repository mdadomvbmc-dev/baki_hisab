// ওয়েব বিল্ডের জন্য ফাঁকা ফাংশন (ডেস্কটপ-অনলি প্লাগিন এখানে লোড হয় না)
Future<void> deskInit() async {}
Future<void> deskShow() async {}
Future<void> deskSize(double w, double h) async {}
Future<void> deskOnTop(bool v) async {}
Future<void> openLocalFile(String path) async {}
