import 'dart:ui' show Size;
import 'package:open_filex/open_filex.dart';
import 'package:window_manager/window_manager.dart';

Future<void> deskInit() async {
  await windowManager.ensureInitialized();
  await windowManager.setTitle('বাকি হিসাব');
}

Future<void> deskShow() async {
  await windowManager.show();
  await windowManager.focus();
}

Future<void> deskSize(double w, double h) => windowManager.setSize(Size(w, h));
Future<void> deskOnTop(bool v) => windowManager.setAlwaysOnTop(v);
Future<void> openLocalFile(String path) async {
  await OpenFilex.open(path);
}
