import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'main.dart';

class PromptItem {
  final String id, cat, title, text;
  final bool custom;
  const PromptItem(this.id, this.cat, this.title, this.text, {this.custom = false});
}

const promptCats = <String, String>{
  'all': 'সব',
  'fav': '⭐ প্রিয়',
  'shop': '🏪 দোকান ও ব্যবসা',
  'msg': '💬 কাস্টমার মেসেজ',
  'mkt': '📣 মার্কেটিং',
  'write': '✍️ লেখালেখি',
  'study': '📚 পড়াশোনা',
  'trans': '🌐 অনুবাদ',
  'code': '💻 কোডিং/শিট',
  'design': '🎨 ছবি/ডিজাইন',
  'daily': '🏠 দৈনন্দিন',
  'mine': '📝 আমার প্রম্পট',
};

// ফাঁকা জায়গা: {{এভাবে}} লেখা থাকলে কপির আগে পূরণ করা যায়
const kPrompts = <PromptItem>[
  // ───── দোকান ও ব্যবসা ─────
  PromptItem(
      'p01', 'shop', 'পণ্যের আকর্ষণীয় বিবরণ',
      'তুমি একজন অভিজ্ঞ বিক্রয় কপিরাইটার। নিচের পণ্যের জন্য আকর্ষণীয় বাংলা বিবরণ লেখো (৪–৬ লাইন) এবং ৩টি মূল সুবিধা বুলেট আকারে দাও।\n'
      'পণ্য: {{পণ্যের নাম}}\nদাম: {{দাম}}\nবৈশিষ্ট্য: {{বৈশিষ্ট্য}}'),
  PromptItem(
      'p02', 'shop', 'দামের তালিকা সাজিয়ে দাও',
      'নিচের পণ্য ও দামগুলো পরিষ্কার একটি টেবিলে সাজিয়ে দাও (ক্রম, পণ্যের নাম, দাম)। বানান ঠিক করো এবং ক্যাটাগরি অনুযায়ী ভাগ করো।\n{{এখানে তালিকা পেস্ট করুন}}'),
  PromptItem(
      'p03', 'shop', 'বিক্রি বাড়ানোর অফার আইডিয়া',
      'আমার দোকান: {{দোকানের ধরন}}। বিক্রি বাড়াতে কম খরচে করা যায় এমন ১০টি অফার/ডিসকাউন্ট আইডিয়া দাও। প্রতিটির পাশে এক লাইনে লেখো কেন কাজ করবে।'),
  PromptItem(
      'p04', 'shop', 'আয়-ব্যয়ের হিসাব বিশ্লেষণ',
      'নিচে আমার এক মাসের আয়-ব্যয়ের হিসাব দিলাম। বিশ্লেষণ করে বলো কোন খাতে বেশি খরচ হচ্ছে, কোথায় সাশ্রয় সম্ভব এবং আগামী মাসের জন্য ৫টি পরামর্শ দাও।\n{{আয়-ব্যয়ের তালিকা}}'),
  PromptItem(
      'p05', 'shop', 'সাপ্তাহিক মাল অর্ডার চেকলিস্ট',
      'আমি {{দোকানের ধরন}} চালাই। সাপ্তাহিক মাল অর্ডারের জন্য একটি চেকলিস্ট বানিয়ে দাও। কোন জিনিস কত কমে এলে নতুন অর্ডার দিতে হবে তা বোঝার সহজ নিয়মও লেখো।'),
  PromptItem(
      'p06', 'shop', 'দোকানের নাম ও স্লোগান',
      'আমার ব্যবসা: {{ব্যবসার ধরন}}, এলাকা: {{এলাকা}}। ১০টি সুন্দর বাংলা/ইংরেজি দোকানের নাম এবং ৫টি ছোট স্লোগান দাও।'),
  PromptItem(
      'p07', 'shop', 'সাপ্লায়ারকে অর্ডারের মেসেজ',
      'সাপ্লায়ারের কাছে পাঠানোর জন্য ভদ্র ও সংক্ষিপ্ত একটি অর্ডার মেসেজ লেখো।\nমালের তালিকা: {{মালের তালিকা}}\nডেলিভারি দরকার: {{তারিখ}}'),
  PromptItem(
      'p08', 'shop', 'ক্যাশমেমো / ইনভয়েসের ফরম্যাট',
      'আমার {{দোকানের ধরন}} এর জন্য একটি সহজ বাংলা ক্যাশমেমো/ইনভয়েসের ফরম্যাট বানিয়ে দাও (দোকানের নাম, তারিখ, পণ্য, পরিমাণ, দাম, মোট, বাকি, স্বাক্ষর) — প্রিন্ট করার উপযোগী টেবিল আকারে।'),

  // ───── কাস্টমার মেসেজ ─────
  PromptItem(
      'p10', 'msg', 'বাকি তাগাদার ভদ্র মেসেজ',
      '{{কাস্টমারের নাম}} এর কাছে আমার {{টাকা}} টাকা বাকি আছে। খুব ভদ্র ও সম্মানজনক ভাষায় ৩টি আলাদা তাগাদার মেসেজ লেখো (নরম, মাঝারি, একটু দৃঢ়)। প্রতিটি ২–৩ লাইনের, বাংলায়।'),
  PromptItem(
      'p11', 'msg', 'পেমেন্ট পেয়েছি — ধন্যবাদ মেসেজ',
      'কাস্টমার {{নাম}} {{টাকা}} টাকা পরিশোধ করেছে। একটি সংক্ষিপ্ত ধন্যবাদ মেসেজ লেখো যাতে আবার আসার আমন্ত্রণ থাকে।'),
  PromptItem(
      'p12', 'msg', 'কাস্টমারের অভিযোগের উত্তর',
      'একজন কাস্টমার অভিযোগ করেছে: "{{অভিযোগ}}"। বিনয়ী ভাষায় দুঃখপ্রকাশ করে সমাধান জানিয়ে একটি উত্তর লেখো (WhatsApp এর জন্য, ৪–৫ লাইন)।'),
  PromptItem(
      'p13', 'msg', 'নতুন পণ্য এসেছে — বার্তা',
      'আমার দোকানে নতুন এসেছে: {{পণ্য}}। কাস্টমারদের পাঠানোর জন্য ছোট ও আকর্ষণীয় WhatsApp বার্তা লেখো, কিছু ইমোজি সহ।'),
  PromptItem(
      'p14', 'msg', 'উৎসবের শুভেচ্ছা বার্তা',
      '{{উৎসবের নাম}} উপলক্ষে {{দোকানের নাম}} এর পক্ষ থেকে কাস্টমারদের জন্য আন্তরিক শুভেচ্ছা বার্তা লেখো (৩ লাইন) এবং ছোট অফারের ঘোষণা যোগ করো: {{অফার}}।'),
  PromptItem(
      'p15', 'msg', 'দাম নিয়ে দর-কষাকষির উত্তর',
      'কাস্টমার দাম কমাতে বলছে। ভদ্রভাবে "না" বলে পণ্যের মান ও সুবিধা তুলে ধরে এমন ৩টি উত্তর লেখো যাতে কাস্টমার বিরক্ত না হয়। পণ্য: {{পণ্য}}, দাম: {{দাম}}।'),

  // ───── মার্কেটিং ─────
  PromptItem(
      'p20', 'mkt', 'ফেসবুক পোস্ট',
      '{{পণ্য/সেবা}} নিয়ে আমার ফেসবুক পেজের জন্য একটি আকর্ষণীয় বাংলা পোস্ট লেখো। শুরুতে হুক, মাঝখানে সুবিধা, শেষে কল-টু-অ্যাকশন (ফোন: {{ফোন}})। ৫টি হ্যাশট্যাগ দাও।'),
  PromptItem(
      'p21', 'mkt', '৭ দিনের কনটেন্ট প্ল্যান',
      'আমার ব্যবসা {{ব্যবসার ধরন}}। সামনের ৭ দিনের জন্য প্রতিদিন একটি করে ফেসবুক/ইনস্টাগ্রাম পোস্টের আইডিয়া দাও (ছবি কী হবে ও ক্যাপশন সহ)।'),
  PromptItem(
      'p22', 'mkt', 'গুগল রিভিউ চাওয়ার মেসেজ',
      'সন্তুষ্ট কাস্টমারকে আমার দোকানের গুগল রিভিউ দিতে অনুরোধ করার জন্য একটি বিনয়ী ও ছোট মেসেজ লেখো।'),
  PromptItem(
      'p23', 'mkt', 'পোস্টার / ব্যানারের লেখা',
      '{{অফার/ইভেন্ট}} এর জন্য পোস্টারে বসানোর হেডলাইন, সাবহেডলাইন ও ৩টি বুলেট পয়েন্ট লেখো। ভাষা বাংলা, ছোট ও জোরালো।'),
  PromptItem(
      'p24', 'mkt', 'ভিডিও/রিলসের স্ক্রিপ্ট',
      '{{পণ্য/সেবা}} নিয়ে ৩০ সেকেন্ডের একটি রিলস/শর্ট ভিডিওর স্ক্রিপ্ট লেখো। প্রথম ৩ সেকেন্ডে দর্শক ধরার হুক, মাঝে দৃশ্য ও ডায়লগ, শেষে কল-টু-অ্যাকশন।'),

  // ───── লেখালেখি ─────
  PromptItem(
      'p30', 'write', 'আবেদনপত্র / দরখাস্ত',
      '{{প্রাপক}} বরাবর {{বিষয়}} বিষয়ে একটি আনুষ্ঠানিক বাংলা আবেদনপত্র লেখো।\nআমার নাম: {{নাম}}\nঠিকানা: {{ঠিকানা}}\nতারিখ: {{তারিখ}}'),
  PromptItem(
      'p31', 'write', 'ইমেইল পেশাদার করো',
      'নিচের লেখাটি পেশাদার, ভদ্র ও পরিষ্কার ইমেইলে রূপান্তর করো। ভাষা: {{বাংলা/English}}\n{{আপনার লেখা}}'),
  PromptItem(
      'p32', 'write', 'বানান ও ব্যাকরণ ঠিক করো',
      'নিচের লেখার বানান, যতিচিহ্ন ও ব্যাকরণ ঠিক করে দাও। অর্থ পরিবর্তন করবে না। কী কী বদলালে তা শেষে সংক্ষেপে জানাও।\n{{লেখা}}'),
  PromptItem(
      'p33', 'write', 'লেখা সংক্ষেপ করো',
      'নিচের লেখাটি ৫টি মূল পয়েন্টে সংক্ষেপ করো, তারপর ১ লাইনের সারকথা দাও।\n{{লেখা}}'),
  PromptItem(
      'p34', 'write', 'সিভি / জীবনবৃত্তান্ত',
      'আমার তথ্য দিয়ে একটি পরিষ্কার CV (বাংলা বা ইংরেজি) বানাও।\nনাম: {{নাম}}\nশিক্ষা: {{শিক্ষা}}\nঅভিজ্ঞতা: {{অভিজ্ঞতা}}\nদক্ষতা: {{দক্ষতা}}'),
  PromptItem(
      'p35', 'write', 'কভার লেটার',
      '{{পদ}} পদের জন্য {{কোম্পানি}} এ আবেদনের একটি কভার লেটার লেখো (১৫০ শব্দ)। আমার অভিজ্ঞতা: {{অভিজ্ঞতা}}।'),
  PromptItem(
      'p36', 'write', 'ছোট বক্তব্য / ভাষণ',
      '{{অনুষ্ঠান}} এ দেওয়ার জন্য ২ মিনিটের একটি সহজ ও আন্তরিক বাংলা বক্তব্য লেখো।'),

  // ───── পড়াশোনা ─────
  PromptItem(
      'p40', 'study', 'সহজ ভাষায় বুঝাও',
      '{{বিষয়}} টা আমাকে একদম সহজ বাংলায় বুঝাও, যেন ক্লাস ৮ এর শিক্ষার্থী বোঝে। বাস্তব জীবনের ২টি উদাহরণ দাও এবং শেষে ৩টি প্রশ্ন করো আমি বুঝেছি কিনা।'),
  PromptItem(
      'p41', 'study', 'পরীক্ষার প্রশ্ন বানাও',
      '{{বিষয়}} ({{শ্রেণি}}) থেকে ১০টি MCQ ও ৫টি সংক্ষিপ্ত প্রশ্ন বানাও। উত্তরসহ দাও।'),
  PromptItem(
      'p42', 'study', 'পড়ার রুটিন',
      'আমার পরীক্ষা {{তারিখ}} তারিখে। বিষয়: {{বিষয়সমূহ}}। প্রতিদিন {{ঘণ্টা}} ঘণ্টা পড়তে পারি। একটি বাস্তবসম্মত দৈনিক পড়ার রুটিন বানিয়ে দাও।'),
  PromptItem(
      'p43', 'study', 'অঙ্ক ধাপে ধাপে সমাধান',
      'নিচের সমস্যাটি ধাপে ধাপে সমাধান করো এবং প্রতিটি ধাপ কেন করছ তা ব্যাখ্যা করো।\n{{সমস্যা}}'),

  // ───── অনুবাদ ─────
  PromptItem(
      'p50', 'trans', 'ইংরেজি থেকে বাংলা',
      'নিচের লেখাটি স্বাভাবিক ও সহজ বাংলায় অনুবাদ করো (আক্ষরিক নয়, ভাব ঠিক রেখে)।\n{{লেখা}}'),
  PromptItem(
      'p51', 'trans', 'বাংলা থেকে ইংরেজি',
      'নিচের লেখাটি পেশাদার ও স্বাভাবিক ইংরেজিতে অনুবাদ করো। কোথায় ফরমাল/ইনফরমাল ব্যবহার করেছ তা জানিয়ে দাও।\n{{লেখা}}'),
  PromptItem(
      'p52', 'trans', 'ইংরেজি বলার অনুশীলন',
      'তুমি আমার ইংরেজি স্পোকেন পার্টনার। বিষয়: {{বিষয়}}। সহজ ইংরেজিতে কথা বলো; আমার ভুল হলে ভদ্রভাবে ঠিক করে বাংলায় কারণ বলো।'),

  // ───── কোডিং / শিট ─────
  PromptItem(
      'p60', 'code', 'কোড ব্যাখ্যা',
      'নিচের কোডটি লাইন ধরে ধরে সহজ বাংলায় ব্যাখ্যা করো এবং সম্ভাব্য ভুল/উন্নতির জায়গা বলো।\n{{কোড}}'),
  PromptItem(
      'p61', 'code', 'ছোট ওয়েবসাইট বানাও',
      '{{ব্যবসার ধরন}} এর জন্য একটি সিঙ্গেল-পেজ ওয়েবসাইটের পূর্ণ HTML+CSS কোড দাও (মোবাইল ফ্রেন্ডলি, বাংলা লেখা, WhatsApp বাটন সহ)। ফোন: {{ফোন}}।'),
  PromptItem(
      'p62', 'code', 'Excel / Sheet ফর্মুলা',
      'Excel/Google Sheet এ আমি {{কী করতে চাই}} করতে চাই। কলাম: {{কলামের বিবরণ}}। সঠিক ফর্মুলা এবং কীভাবে বসাব ধাপে ধাপে বলো।'),
  PromptItem(
      'p63', 'code', 'এরর ঠিক করো',
      'আমার এই কোডে এরর আসছে। কারণ ব্যাখ্যা করে ঠিক করা কোড দাও।\nএরর: {{এরর মেসেজ}}\nকোড:\n{{কোড}}'),

  // ───── ছবি / ডিজাইন ─────
  PromptItem(
      'p70', 'design', 'লোগো আইডিয়া (AI ইমেজ প্রম্পট)',
      'Create a clean modern logo for a {{business type}} named "{{name}}", flat vector style, {{color}} color palette, white background, simple icon with bold text, high quality.'),
  PromptItem(
      'p71', 'design', 'সোশ্যাল মিডিয়া পোস্টার (ইমেজ প্রম্পট)',
      'Design a professional social media poster for {{offer or event}}, {{color}} theme, space for a bold headline, clean layout, 1080x1080, modern typography, high contrast.'),
  PromptItem(
      'p72', 'design', 'পণ্যের ছবির স্টাইল',
      'Studio product photo of {{product}} on a clean {{background}} background, soft shadow, bright natural lighting, ultra detailed, e-commerce style.'),

  // ───── দৈনন্দিন ─────
  PromptItem(
      'p80', 'daily', 'আজকের কাজের প্ল্যান',
      'আমার আজকের কাজের তালিকা: {{কাজগুলো}}। অগ্রাধিকার অনুযায়ী সাজিয়ে সময় ভাগ করে একটি বাস্তবসম্মত প্ল্যান বানিয়ে দাও। দিনে আমি {{ঘণ্টা}} ঘণ্টা সময় পাব।'),
  PromptItem(
      'p81', 'daily', 'মাসিক বাজেট প্ল্যান',
      'আমার মাসিক আয় {{আয়}} টাকা। খরচ: {{খরচের তালিকা}}। সঞ্চয় বাড়ানোর জন্য ৫০/৩০/২০ নিয়মে একটি সহজ বাজেট বানিয়ে দাও এবং কোথায় কমানো যায় বলো।'),
  PromptItem(
      'p82', 'daily', 'ঘরে যা আছে তা দিয়ে রান্না',
      'আমার ঘরে আছে: {{উপকরণ}}। এগুলো দিয়ে ৩টি সহজ রান্নার রেসিপি বলো (২০ মিনিটের মধ্যে), ধাপ সহ।'),
  PromptItem(
      'p83', 'daily', 'সিদ্ধান্ত নিতে সাহায্য',
      'আমি {{বিষয়}} নিয়ে সিদ্ধান্ত নিতে পারছি না। উভয় দিকের সুবিধা-অসুবিধা টেবিলে দাও, তারপর আমার পরিস্থিতি ({{পরিস্থিতি}}) অনুযায়ী তোমার পরামর্শ দাও।'),
  PromptItem(
      'p84', 'daily', 'ঘরে ব্যায়ামের রুটিন',
      'আমার বয়স {{বয়স}}, দিনে {{মিনিট}} মিনিট সময় পাই। ঘরে করার মতো সহজ ব্যায়াম রুটিন দাও। (এটি সাধারণ পরামর্শ; জটিল সমস্যায় ডাক্তারের কাছে যাব।)'),
  PromptItem(
      'p85', 'daily', '৩০ দিনে নতুন কিছু শেখা',
      'তুমি আমার অভিজ্ঞ মেন্টর। আমি {{বিষয়}} শিখতে চাই। আমার বর্তমান জ্ঞান: {{স্তর}}। ৩০ দিনের একটি শেখার পরিকল্পনা দাও, প্রতিদিনের ছোট কাজ সহ।'),
];

final _phRe = RegExp(r'\{\{(.+?)\}\}');

List<String> placeholdersOf(String t) {
  final s = <String>[];
  for (final m in _phRe.allMatches(t)) {
    final k = m.group(1) ?? '';
    if (k.isNotEmpty && !s.contains(k)) s.add(k);
  }
  return s;
}

String fillText(String t, Map<String, String> v) => t.replaceAllMapped(_phRe, (m) {
      final k = m.group(1) ?? '';
      final x = (v[k] ?? '').trim();
      return x.isEmpty ? '[$k]' : x;
    });

void toggleFav(String id) {
  final l = [...favs.value];
  if (l.contains(id)) {
    l.remove(id);
  } else {
    l.add(id);
  }
  favs.value = l;
  savePrefs({'favs': l});
}

Future<void> copyPrompt(BuildContext c, String text) async {
  await Clipboard.setData(ClipboardData(text: text));
  if (c.mounted) toast(c, 'কপি হয়েছে ✅ এখন AI চ্যাটে পেস্ট করুন');
}

Widget aiLinks(BuildContext c) => Wrap(spacing: 8, runSpacing: 0, children: [
      ActionChip(avatar: const Icon(Icons.open_in_new, size: 16), label: const Text('Claude'), onPressed: () => openUrl(c, 'https://claude.ai')),
      ActionChip(avatar: const Icon(Icons.open_in_new, size: 16), label: const Text('ChatGPT'), onPressed: () => openUrl(c, 'https://chatgpt.com')),
      ActionChip(avatar: const Icon(Icons.open_in_new, size: 16), label: const Text('Gemini'), onPressed: () => openUrl(c, 'https://gemini.google.com')),
    ]);

// ───────── প্রম্পট স্টোর পেজ ─────────
class PromptStore extends StatefulWidget {
  const PromptStore({super.key});
  @override
  State<PromptStore> createState() => _PSState();
}

class _PSState extends State<PromptStore> {
  String cat = 'all', q = '';
  late final Stream<QuerySnapshot<Map<String, dynamic>>> st = promptsCol.orderBy('createdAt', descending: true).snapshots();

  Widget pcard(BuildContext c, PromptItem p, bool fav) {
    final has = placeholdersOf(p.text).isNotEmpty;
    final tag = promptCats[p.custom ? 'mine' : p.cat] ?? '';
    return card(InkWell(
        onTap: () => promptSheet(c, p),
        child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 10, 8, 12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Text(p.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15))),
                IconButton(icon: Icon(fav ? Icons.star : Icons.star_border, color: fav ? Colors.amber.shade700 : Colors.black45), tooltip: 'প্রিয়', onPressed: () => toggleFav(p.id)),
              ]),
              Padding(padding: const EdgeInsets.only(right: 8), child: Text(p.text.replaceAll('\n', ' '), maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.black54, fontSize: 13))),
              const SizedBox(height: 10),
              Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: Row(children: [
                    Expanded(child: Text(has ? '$tag  •  ✍️ ফাঁকা পূরণ' : tag, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, color: Colors.black45))),
                    const SizedBox(width: 8),
                    FilledButton.tonalIcon(onPressed: () => has ? promptSheet(c, p) : copyPrompt(c, p.text), icon: const Icon(Icons.copy, size: 16), label: Text(has ? 'পূরণ ও কপি' : 'কপি')),
                  ])),
            ]))));
  }

  @override
  Widget build(BuildContext c) => Scaffold(
      appBar: AppBar(title: const Text('প্রম্পট স্টোর')),
      floatingActionButton: FloatingActionButton.extended(onPressed: () => promptForm(c), icon: const Icon(Icons.add), label: const Text('নতুন প্রম্পট')),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: st,
          builder: (c, s) {
            final custom = (s.data?.docs ?? <QueryDocumentSnapshot<Map<String, dynamic>>>[])
                .map((d) => PromptItem(d.id, str(d.data(), 'cat').isEmpty ? 'daily' : str(d.data(), 'cat'), str(d.data(), 'title'), str(d.data(), 'text'), custom: true))
                .toList();
            final all = <PromptItem>[...custom, ...kPrompts];
            return ValueListenableBuilder<List<String>>(
                valueListenable: favs,
                builder: (c, fv, _) {
                  final key = q.toLowerCase().trim();
                  final list = all.where((p) {
                    if (cat == 'fav' && !fv.contains(p.id)) return false;
                    if (cat == 'mine' && !p.custom) return false;
                    if (cat != 'all' && cat != 'fav' && cat != 'mine' && p.cat != cat) return false;
                    if (key.isEmpty) return true;
                    return p.title.toLowerCase().contains(key) || p.text.toLowerCase().contains(key);
                  }).toList();
                  return ListView(padding: const EdgeInsets.only(bottom: 96), children: [
                    card(Padding(
                        padding: const EdgeInsets.all(14),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          const Text('দৈনন্দিন কাজের রেডি প্রম্পট', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                          const SizedBox(height: 4),
                          const Text('কার্ডে ট্যাপ করে "কপি" চাপুন, তারপর নিচের যেকোনো AI তে পেস্ট করুন।', style: TextStyle(color: Colors.black54)),
                          const SizedBox(height: 8),
                          aiLinks(c),
                        ]))),
                    Padding(
                        padding: const EdgeInsets.fromLTRB(14, 4, 14, 0),
                        child: TextField(onChanged: (v) => setState(() => q = v), decoration: deco(hint: 'প্রম্পট খুঁজুন...', prefix: const Icon(Icons.search), filled: true))),
                    SizedBox(
                        height: 52,
                        child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12), children: [
                          for (final e in promptCats.entries)
                            Padding(padding: const EdgeInsets.only(right: 8, top: 8, bottom: 6), child: ChoiceChip(label: Text(e.value), selected: cat == e.key, onSelected: (_) => setState(() => cat = e.key))),
                        ])),
                    if (list.isEmpty) const Padding(padding: EdgeInsets.all(40), child: Center(child: Text('কিছু পাওয়া যায়নি', style: TextStyle(color: Colors.black54)))),
                    for (final p in list) pcard(c, p, fv.contains(p.id)),
                  ]);
                });
          }));
}

// ───────── প্রম্পট বিস্তারিত / ফাঁকা পূরণ / কপি ─────────
void promptSheet(BuildContext c, PromptItem p) {
  final keys = placeholdersOf(p.text);
  final vals = <String, String>{};
  showModalBottomSheet(
      context: c,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setS) {
            final out = fillText(p.text, vals);
            return Padding(
                padding: EdgeInsets.fromLTRB(20, 16, 20, MediaQuery.of(ctx).viewInsets.bottom + 16),
                child: SingleChildScrollView(
                    child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Expanded(child: Text(p.title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
                    if (p.custom) IconButton(icon: const Icon(Icons.edit_outlined), tooltip: 'এডিট', onPressed: () {
                      Navigator.pop(ctx);
                      promptForm(c, edit: p);
                    }),
                    if (p.custom)
                      IconButton(
                          icon: const Icon(Icons.delete_outline, color: Colors.red),
                          tooltip: 'মুছুন',
                          onPressed: () async {
                            final ok = await showDialog<bool>(
                                context: ctx,
                                builder: (x) => AlertDialog(title: const Text('প্রম্পট মুছবেন?'), actions: [
                                      TextButton(onPressed: () => Navigator.pop(x, false), child: const Text('না')),
                                      FilledButton(onPressed: () => Navigator.pop(x, true), child: const Text('মুছুন')),
                                    ]));
                            if (ok == true) {
                              fire(promptsCol.doc(p.id).delete());
                              if (ctx.mounted) Navigator.pop(ctx);
                            }
                          }),
                  ]),
                  if (keys.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    const Text('ফাঁকা জায়গাগুলো পূরণ করুন (না করলেও কপি করা যাবে):', style: TextStyle(color: Colors.black54)),
                    const SizedBox(height: 8),
                    for (final k in keys)
                      Padding(padding: const EdgeInsets.only(bottom: 8), child: TextField(onChanged: (v) => setS(() => vals[k] = v), decoration: deco(label: k))),
                  ],
                  const SizedBox(height: 6),
                  Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(color: Theme.of(ctx).colorScheme.surfaceContainerHighest.withAlpha(110), borderRadius: BorderRadius.circular(12)),
                      child: SelectableText(out, style: const TextStyle(fontSize: 14, height: 1.5))),
                  const SizedBox(height: 12),
                  SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: FilledButton.icon(
                          onPressed: () {
                            Navigator.pop(ctx);
                            copyPrompt(c, out);
                          },
                          icon: const Icon(Icons.copy),
                          label: const Text('কপি করুন'))),
                  const SizedBox(height: 8),
                  aiLinks(c),
                ])));
          }));
}

// ───────── নিজের প্রম্পট যোগ / এডিট ─────────
void promptForm(BuildContext c, {PromptItem? edit}) {
  final t = TextEditingController(text: edit?.title ?? '');
  final x = TextEditingController(text: edit?.text ?? '');
  var cat = edit == null ? 'daily' : edit.cat;
  String? err;
  final cats = promptCats.entries.where((e) => e.key != 'all' && e.key != 'fav' && e.key != 'mine').toList();
  showModalBottomSheet(
      context: c,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setS) {
            return Padding(
                padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 20),
                child: SingleChildScrollView(
                    child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(edit == null ? 'নতুন প্রম্পট' : 'প্রম্পট এডিট', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 12),
                  TextField(controller: t, decoration: deco(label: 'শিরোনাম *')),
                  const SizedBox(height: 10),
                  TextField(controller: x, minLines: 4, maxLines: 9, decoration: deco(label: 'প্রম্পটের লেখা *', helper: 'ফাঁকা জায়গার জন্য {{নাম}} এভাবে লিখুন — কপির সময় পূরণ করা যাবে')),
                  const SizedBox(height: 10),
                  Wrap(spacing: 8, runSpacing: 0, children: [
                    for (final e in cats) ChoiceChip(label: Text(e.value), selected: cat == e.key, onSelected: (_) => setS(() => cat = e.key)),
                  ]),
                  if (err != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(err!, style: const TextStyle(color: Colors.red))),
                  const SizedBox(height: 14),
                  SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: FilledButton(
                          onPressed: () {
                            if (t.text.trim().isEmpty || x.text.trim().isEmpty) {
                              setS(() => err = 'শিরোনাম ও লেখা দুটোই দিন');
                              return;
                            }
                            final data = <String, dynamic>{'title': t.text.trim(), 'text': x.text.trim(), 'cat': cat};
                            if (edit != null) {
                              fire(promptsCol.doc(edit.id).update(data));
                            } else {
                              fire(promptsCol.add({...data, 'createdAt': Timestamp.now()}).then((_) {}));
                            }
                            Navigator.pop(ctx);
                          },
                          child: const Text('সংরক্ষণ'))),
                ])));
          }));
}
